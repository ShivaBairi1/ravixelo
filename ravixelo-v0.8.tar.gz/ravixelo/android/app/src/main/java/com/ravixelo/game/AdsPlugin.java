package com.ravixelo.game;

import android.app.Activity;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import androidx.annotation.NonNull;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;
import com.google.android.ump.ConsentInformation;
import com.google.android.ump.ConsentRequestParameters;
import com.google.android.ump.UserMessagingPlatform;

import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Google AdMob for the Capacitor app (JS side: src/ads.ts, plugin name "RavixeloAds").
 * Flow: initialize() -> Google's consent form (UMP, needed in the EEA/UK) -> MobileAds.initialize -> JS preloads rewarded/interstitial.
 * Ads are only shown when JS asks (menu / result screens). Rewarded ads always need a player tap.
 * Also: exitApp() for the back button.
 */
@CapacitorPlugin(name = "RavixeloAds")
public class AdsPlugin extends Plugin {
    private String bannerId = "", interstitialId = "", rewardedId = "";
    private final AtomicBoolean sdkStarted = new AtomicBoolean(false);
    private AdView banner;
    private InterstitialAd interstitial;
    private RewardedAd rewarded;

    private boolean canRequestAds() {
        return sdkStarted.get() && UserMessagingPlatform.getConsentInformation(getContext()).canRequestAds();
    }

    @PluginMethod
    public void initialize(final PluginCall call) {
        bannerId = call.getString("banner", "");
        interstitialId = call.getString("interstitial", "");
        rewardedId = call.getString("rewarded", "");
        final Activity activity = getActivity();
        if (activity == null) { call.reject("no activity"); return; }
        activity.runOnUiThread(() -> {
            final ConsentInformation info = UserMessagingPlatform.getConsentInformation(activity);
            ConsentRequestParameters params = new ConsentRequestParameters.Builder().build();
            info.requestConsentInfoUpdate(activity, params,
                () -> UserMessagingPlatform.loadAndShowConsentFormIfRequired(activity, formError -> finishInit(call, info)),
                requestError -> finishInit(call, info)); // consent info unavailable (offline): still allowed to continue if previously granted
        });
    }

    private void finishInit(PluginCall call, ConsentInformation info) {
        final boolean can = info.canRequestAds();
        if (can && sdkStarted.compareAndSet(false, true)) {
            new Thread(() -> MobileAds.initialize(getContext(), status -> { })).start();
        }
        JSObject r = new JSObject();
        r.put("canRequestAds", can);
        r.put("privacyOptions", info.getPrivacyOptionsRequirementStatus() == ConsentInformation.PrivacyOptionsRequirementStatus.REQUIRED);
        call.resolve(r);
    }

    @PluginMethod
    public void showPrivacyOptions(final PluginCall call) {
        final Activity activity = getActivity();
        if (activity == null) { call.reject("no activity"); return; }
        activity.runOnUiThread(() -> UserMessagingPlatform.showPrivacyOptionsForm(activity, formError -> call.resolve()));
    }

    // ---- banner (anchored adaptive, bottom of the screen)
    @PluginMethod
    public void showBanner(final PluginCall call) {
        final Activity activity = getActivity();
        if (activity == null || bannerId.isEmpty() || !canRequestAds()) { call.reject("banner unavailable"); return; }
        activity.runOnUiThread(() -> {
            try {
                if (banner == null) {
                    ViewGroup root = activity.findViewById(android.R.id.content);
                    int widthDp = (int) (root.getWidth() / activity.getResources().getDisplayMetrics().density);
                    if (widthDp <= 0) widthDp = 360;
                    banner = new AdView(activity);
                    banner.setAdUnitId(bannerId);
                    banner.setAdSize(AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(activity, widthDp));
                    FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
                    root.addView(banner, lp);
                    banner.loadAd(new AdRequest.Builder().build());
                } else {
                    banner.setVisibility(View.VISIBLE);
                    banner.resume();
                }
                call.resolve();
            } catch (Exception e) {
                call.reject("banner failed");
            }
        });
    }

    @PluginMethod
    public void hideBanner(final PluginCall call) {
        final Activity activity = getActivity();
        if (activity == null) { call.resolve(); return; }
        activity.runOnUiThread(() -> {
            if (banner != null) { banner.pause(); banner.setVisibility(View.GONE); }
            call.resolve();
        });
    }

    // ---- interstitial
    @PluginMethod
    public void loadInterstitial(final PluginCall call) {
        final Activity activity = getActivity();
        if (activity == null || interstitialId.isEmpty() || !canRequestAds()) { call.reject("interstitial unavailable"); return; }
        activity.runOnUiThread(() -> InterstitialAd.load(activity, interstitialId, new AdRequest.Builder().build(), new InterstitialAdLoadCallback() {
            @Override public void onAdLoaded(@NonNull InterstitialAd ad) { interstitial = ad; call.resolve(); }
            @Override public void onAdFailedToLoad(@NonNull LoadAdError error) { interstitial = null; call.reject("load failed: " + error.getCode()); }
        }));
    }

    @PluginMethod
    public void showInterstitial(final PluginCall call) {
        final Activity activity = getActivity();
        final InterstitialAd ad = interstitial;
        if (activity == null || ad == null) { JSObject r = new JSObject(); r.put("shown", false); call.resolve(r); return; }
        interstitial = null;
        activity.runOnUiThread(() -> {
            ad.setFullScreenContentCallback(new FullScreenContentCallback() {
                @Override public void onAdDismissedFullScreenContent() { JSObject r = new JSObject(); r.put("shown", true); call.resolve(r); }
                @Override public void onAdFailedToShowFullScreenContent(@NonNull AdError error) { JSObject r = new JSObject(); r.put("shown", false); call.resolve(r); }
            });
            ad.show(activity);
        });
    }

    // ---- rewarded
    @PluginMethod
    public void loadRewarded(final PluginCall call) {
        final Activity activity = getActivity();
        if (activity == null || rewardedId.isEmpty() || !canRequestAds()) { call.reject("rewarded unavailable"); return; }
        activity.runOnUiThread(() -> RewardedAd.load(activity, rewardedId, new AdRequest.Builder().build(), new RewardedAdLoadCallback() {
            @Override public void onAdLoaded(@NonNull RewardedAd ad) { rewarded = ad; call.resolve(); }
            @Override public void onAdFailedToLoad(@NonNull LoadAdError error) { rewarded = null; call.reject("load failed: " + error.getCode()); }
        }));
    }

    @PluginMethod
    public void showRewarded(final PluginCall call) {
        final Activity activity = getActivity();
        final RewardedAd ad = rewarded;
        if (activity == null || ad == null) { call.reject("not ready"); return; }
        rewarded = null;
        final AtomicBoolean earned = new AtomicBoolean(false);
        activity.runOnUiThread(() -> {
            ad.setFullScreenContentCallback(new FullScreenContentCallback() {
                @Override public void onAdDismissedFullScreenContent() { JSObject r = new JSObject(); r.put("rewarded", earned.get()); call.resolve(r); }
                @Override public void onAdFailedToShowFullScreenContent(@NonNull AdError error) { call.reject("show failed"); }
            });
            ad.show(activity, rewardItem -> earned.set(true));
        });
    }

    @PluginMethod
    public void exitApp(final PluginCall call) {
        final Activity activity = getActivity();
        if (activity != null) activity.runOnUiThread(activity::finish);
        call.resolve();
    }

    @Override
    protected void handleOnDestroy() {
        if (banner != null) { banner.destroy(); banner = null; }
        super.handleOnDestroy();
    }
}
