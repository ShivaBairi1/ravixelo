import { describe, it, expect } from 'vitest';
import { interstitialDue, newPace, PACE } from './adPolicy';
describe('interstitial pacing', () => {
  const t0 = 1_000_000;
  it('never in the first runs', () => { expect(interstitialDue({ lastAt: 0, runsSince: 5 }, t0, PACE.graceRuns)).toBe(false); expect(interstitialDue({ lastAt: 0, runsSince: 5 }, t0, PACE.graceRuns + 1)).toBe(true); });
  it('needs enough finished runs since the last ad', () => { expect(interstitialDue({ lastAt: 0, runsSince: 1 }, t0, 10)).toBe(false); expect(interstitialDue({ lastAt: 0, runsSince: 2 }, t0, 10)).toBe(true); });
  it('respects the minimum gap', () => { expect(interstitialDue({ lastAt: t0, runsSince: 9 }, t0 + 60_000, 10)).toBe(false); expect(interstitialDue({ lastAt: t0, runsSince: 9 }, t0 + PACE.minGapMs, 10)).toBe(true); });
  it('starts clean', () => { expect(newPace()).toEqual({ lastAt: 0, runsSince: 0 }); });
});
