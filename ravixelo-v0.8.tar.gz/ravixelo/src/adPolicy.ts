// Pure ad-pacing rules (no SDK, unit-tested).
/** Interstitial pacing: never during the first runs, at most every `minGapMs`, and only every `everyRuns` finished runs. */
export interface Pace { lastAt: number; runsSince: number }
export const PACE = { graceRuns: 2, minGapMs: 120_000, everyRuns: 2 };
export const newPace = (): Pace => ({ lastAt: 0, runsSince: 0 });
export function interstitialDue(p: Pace, now: number, totalRuns: number, cfg = PACE): boolean {
  return totalRuns > cfg.graceRuns && p.runsSince >= cfg.everyRuns && (p.lastAt === 0 || now - p.lastAt >= cfg.minGapMs);
}

