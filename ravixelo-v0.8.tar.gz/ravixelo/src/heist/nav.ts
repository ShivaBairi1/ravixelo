export interface Rect { x: number; z: number; w: number; d: number } // centre + full size
export class NavGrid {
  readonly cell = .5; w: number; h: number; blocked: Uint8Array;
  constructor(public minX: number, public minZ: number, public maxX: number, public maxZ: number, rects: Rect[], inflate = .45) {
    this.w = Math.ceil((maxX - minX) / this.cell); this.h = Math.ceil((maxZ - minZ) / this.cell); this.blocked = new Uint8Array(this.w * this.h);
    for (const r of rects) {
      const x0 = this.cx(r.x - r.w / 2 - inflate), x1 = this.cx(r.x + r.w / 2 + inflate), z0 = this.cz(r.z - r.d / 2 - inflate), z1 = this.cz(r.z + r.d / 2 + inflate);
      for (let j = z0; j <= z1; j++) for (let i = x0; i <= x1; i++) if (i >= 0 && j >= 0 && i < this.w && j < this.h) this.blocked[j * this.w + i] = 1;
    }
  }
  cx(x: number) { return Math.floor((x - this.minX) / this.cell); } cz(z: number) { return Math.floor((z - this.minZ) / this.cell); }
  isBlocked(i: number, j: number) { return i < 0 || j < 0 || i >= this.w || j >= this.h || this.blocked[j * this.w + i] === 1; }
  free(x: number, z: number) { return !this.isBlocked(this.cx(x), this.cz(z)); }
  private nearestFree(i: number, j: number): [number, number] | null {
    if (!this.isBlocked(i, j)) return [i, j];
    for (let r = 1; r < 8; r++) for (let dj = -r; dj <= r; dj++) for (let di = -r; di <= r; di++) if (Math.max(Math.abs(di), Math.abs(dj)) === r && !this.isBlocked(i + di, j + dj)) return [i + di, j + dj];
    return null;
  }
  /** A* over the grid, 8-neighbour without corner cutting. Returns world-space waypoints, or [] if unreachable. */
  findPath(ax: number, az: number, bx: number, bz: number): [number, number][] {
    const s = this.nearestFree(this.cx(ax), this.cz(az)), e = this.nearestFree(this.cx(bx), this.cz(bz)); if (!s || !e) return [];
    const W = this.w, N = W * this.h, g = new Float32Array(N).fill(Infinity), from = new Int32Array(N).fill(-1), closed = new Uint8Array(N);
    const open: [number, number][] = [], push = (f: number, n: number) => { open.push([f, n]); let k = open.length - 1; while (k > 0) { const p = (k - 1) >> 1; if (open[p][0] <= open[k][0]) break; [open[p], open[k]] = [open[k], open[p]]; k = p; } };
    const pop = () => { const t = open[0], l = open.pop()!; if (open.length) { open[0] = l; let k = 0; for (;;) { let m = k; const a = 2 * k + 1, b = a + 1; if (a < open.length && open[a][0] < open[m][0]) m = a; if (b < open.length && open[b][0] < open[m][0]) m = b; if (m === k) break; [open[m], open[k]] = [open[k], open[m]]; k = m; } } return t; };
    const si = s[1] * W + s[0], ei = e[1] * W + e[0], hf = (n: number) => Math.hypot((n % W) - e[0], Math.floor(n / W) - e[1]); g[si] = 0; push(hf(si), si);
    let it = 0;
    while (open.length && it++ < 30000) {
      const [, n] = pop(); if (closed[n]) continue; closed[n] = 1; if (n === ei) break; const ci = n % W, cj = (n / W) | 0;
      for (let dj = -1; dj <= 1; dj++) for (let di = -1; di <= 1; di++) {
        if (!di && !dj) continue; const ni = ci + di, nj = cj + dj; if (this.isBlocked(ni, nj)) continue;
        if (di && dj && (this.isBlocked(ci + di, cj) || this.isBlocked(ci, cj + dj))) continue;
        const m = nj * W + ni, c = g[n] + (di && dj ? 1.414 : 1); if (c < g[m]) { g[m] = c; from[m] = n; push(c + hf(m), m); }
      }
    }
    if (from[ei] < 0 && si !== ei) return [];
    const cells: number[] = []; for (let n = ei; n !== -1; n = from[n]) cells.push(n); cells.reverse();
    const pts = cells.map(n => [this.minX + ((n % W) + .5) * this.cell, this.minZ + (((n / W) | 0) + .5) * this.cell] as [number, number]);
    return this.smooth(pts);
  }
  lineClear(x0: number, z0: number, x1: number, z1: number) {
    const n = Math.ceil(Math.hypot(x1 - x0, z1 - z0) / (this.cell * .5)); for (let k = 0; k <= n; k++) { const t = n ? k / n : 0; if (!this.free(x0 + (x1 - x0) * t, z0 + (z1 - z0) * t)) return false; } return true;
  }
  private smooth(p: [number, number][]) { if (p.length < 3) return p; const out = [p[0]]; let a = 0; for (let b = 2; b < p.length; b++) if (!this.lineClear(p[a][0], p[a][1], p[b][0], p[b][1])) { out.push(p[b - 1]); a = b - 1; } out.push(p[p.length - 1]); return out; }
}
