import * as THREE from 'three';
import RAPIER from '@dimforge/rapier3d-compat';
import { EffectComposer } from 'three/examples/jsm/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/examples/jsm/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/examples/jsm/postprocessing/UnrealBloomPass.js';
import { OutputPass } from 'three/examples/jsm/postprocessing/OutputPass.js';
import { BANK, BOUNDS, CIVS, COP_SPAWNS, COVER, DOORS, EXTRACT, GUARDS, LIGHTS, MANAGER, PLAYER_SPAWN, WALLS, insideBank, navRects } from './level';
import { NavGrid } from './nav';
import * as RL from './rules';
import { makeMaterials, makeSky, Mats } from './assets';
import { animate, buildRig, disposeChars, gunModel, Rig } from './chars';
import { Sfx } from './audio';
import { buildWorld, Door, WorldRefs } from './world';

export type HState = 'ready' | 'playing' | 'paused' | 'over';
export interface HeistHud { hp: number; weapon: string; mag: number; reserve: number; reloading: boolean; stance: RL.Stance; obj: string; objDist: number; prompt: string; progress: number; bags: number; alarm: boolean; eta: number; cops: number; hit: number; aim: boolean; msg: string; mission: RL.MissionState; fps: number; maxHp: number; hm: number }
export interface HeistResult { win: boolean; why: string; bags: number; payout: number; time: number; kills: number; shots: number; hits: number; civHits: number; alarmed: boolean; stars: number; canRevive: boolean }
export interface HeistHooks { onHud(h: HeistHud): void; onState(s: HState): void; onResult(r: HeistResult): void }
interface Actor { id: number; kind: 'guard' | 'cop' | 'civ' | 'manager'; rig: Rig; pos: THREE.Vector3; yaw: number; hp: number; dead: boolean; body?: RAPIER.RigidBody; col?: RAPIER.Collider; state: 'idle' | 'patrol' | 'investigate' | 'combat' | 'chase' | 'cower'; patrol: [number, number][]; pi: number; path: [number, number][]; pathI: number; repath: number; look: number; canSee: boolean; cool: number; last: THREE.Vector3; hasLast: boolean; speed: number; t: number; susp: number; walking: boolean; weapon: 'pistol' | 'rifle' | 'none'; pause: number }
const FOOT = 1.02, PR = .3;
const rand = (a: number, b: number) => a + Math.random() * (b - a);

export class HeistGame {
  state: HState = 'ready'; sfx = new Sfx(); sens = .0022; quality: 'high' | 'low';
  private r: THREE.WebGLRenderer; private scene = new THREE.Scene(); private cam = new THREE.PerspectiveCamera(72, 1, .05, 400); private composer?: EffectComposer;
  private world!: RAPIER.World; private kcc!: RAPIER.KinematicCharacterController; private pBody!: RAPIER.RigidBody; private pCol!: RAPIER.Collider; private M: Mats; private W!: WorldRefs; private nav!: NavGrid; private navOpen!: NavGrid; private navLocked!: NavGrid;
  private sun!: THREE.DirectionalLight; private flashLight = new THREE.PointLight(0xffc880, 0, 9, 2); private raf = 0; private ro: ResizeObserver; private last = 0; private clock = 0;
  private actors: Actor[] = []; private colMap = new Map<number, Actor>(); private nextId = 1;
  private px = 0; private pz = 0; private feetY = 0; private vy = 0; private yaw = 0; private pitch = 0; private grounded = false; private stance: RL.Stance = 'stand'; private eyeH = 1.62; private vel = new THREE.Vector2();
  private mx = 0; private mz = 0; private sprint = false; private jumpReq = false; private fire = false; private latched = false; private aim = false; private aimT = 0; private tp = false; private interact = false; private interactEdge = false; private stepT = 0;
  private hp = 100; private hurtT = 0; private lastHurt = -99; private hitT = 0; private hitHead = false; private bloom = 0; private recoilT = 0;
  private diff: RL.DifficultyDef = RL.DIFFICULTY.pro; private loadout: RL.Loadout = RL.noUpgrades(); private maxHp = 100; private drillSec = RL.DRILL_TIME; private invuln = 0; private revivesUsed = 0; private won = false; haptics = true;
  private wid: RL.WeaponId = 'rifle'; private ammo: Record<RL.WeaponId, { mag: number; reserve: number }> = { pistol: { mag: 12, reserve: 48 }, rifle: { mag: 30, reserve: 120 } }; private reload = 0; private cool = 0;
  private m = RL.newMission(); private alarm = false; private alarmAt = 0; private copsSpawned = 0; private copTimer = 0; private msg = ''; private msgT = 0; private prompt = ''; private progress = 0; private manProg = 0;
  private kills = 0; private shots = 0; private hits = 0; private civHits = 0; private startT = 0; private lastHud = 0; private lastMini = 0; private fpsAcc = 0; private fpsN = 0; private fps = 60;
  private rig!: Rig; private rigGuns!: Record<RL.WeaponId, ReturnType<typeof gunModel>>; private vm = new THREE.Group(); private vmGuns!: Record<RL.WeaponId, ReturnType<typeof gunModel>>; private flashT = 0; private keycardItem: THREE.Mesh | null = null; private keycardTaken = false; private drilling = false;
  private tracers: { l: THREE.Line; t: number }[] = []; private decals: THREE.Mesh[] = []; private decalI = 0; private pv = new Float32Array(120 * 3); private pl = new Float32Array(120); private pp = new Float32Array(120 * 3); private pc = new Float32Array(120 * 3); private pi = 0;
  private pGeo = new THREE.BufferGeometry(); private pMat = new THREE.PointsMaterial({ size: .09, vertexColors: true, transparent: true, depthWrite: false }); private decalGeo = new THREE.CircleGeometry(.07, 8); private decalMat = new THREE.MeshBasicMaterial({ color: 0x0a0a0a, transparent: true, opacity: .75, polygonOffset: true, polygonOffsetFactor: -4, depthWrite: false });
  private mini: HTMLCanvasElement | null = null; private miniWalls: ReturnType<typeof navRects> = navRects(); private touch = false; private reduced = matchMedia('(prefers-reduced-motion: reduce)').matches;

  static async create(canvas: HTMLCanvasElement, hooks: HeistHooks, quality?: 'high' | 'low') { await RAPIER.init(); return new HeistGame(canvas, hooks, quality); }
  private constructor(private canvas: HTMLCanvasElement, private hooks: HeistHooks, quality?: 'high' | 'low') {
    const weak = (navigator.hardwareConcurrency || 4) <= 4 || ((navigator as unknown as { deviceMemory?: number }).deviceMemory ?? 8) <= 4 || matchMedia('(pointer:coarse)').matches; this.touch = matchMedia('(pointer:coarse)').matches;
    this.quality = quality ?? (weak ? 'low' : 'high'); const hi = this.quality === 'high';
    this.r = new THREE.WebGLRenderer({ canvas, antialias: !hi, powerPreference: 'high-performance' }); this.r.toneMapping = THREE.ACESFilmicToneMapping; this.r.toneMappingExposure = .95; this.r.shadowMap.enabled = hi; this.r.shadowMap.type = THREE.PCFSoftShadowMap;
    this.scene.fog = new THREE.Fog(0xaec6dc, 60, 240); this.M = makeMaterials(); const sunDir = makeSky(this.r, this.scene);
    this.scene.add(new THREE.HemisphereLight(0xbcd4ff, 0x384030, .45));
    this.sun = new THREE.DirectionalLight(0xfff0dc, 3); this.sun.position.copy(sunDir).multiplyScalar(80); this.sun.castShadow = hi; this.sun.shadow.mapSize.set(2048, 2048); const sc = this.sun.shadow.camera; sc.left = -45; sc.right = 45; sc.top = 45; sc.bottom = -45; sc.near = 10; sc.far = 220; this.sun.shadow.bias = -.0004; this.sun.shadow.normalBias = .04; this.scene.add(this.sun, this.sun.target);
    this.scene.add(this.flashLight, this.cam); this.cam.add(this.vm);
    this.pp.fill(-100); this.pGeo.setAttribute('position', new THREE.BufferAttribute(this.pp, 3)); this.pGeo.setAttribute('color', new THREE.BufferAttribute(this.pc, 3)); const pts = new THREE.Points(this.pGeo, this.pMat); pts.frustumCulled = false; this.scene.add(pts);
    for (let i = 0; i < 40; i++) { const d = new THREE.Mesh(this.decalGeo, this.decalMat); d.visible = false; this.scene.add(d); this.decals.push(d); }
    for (let i = 0; i < 14; i++) { const l = new THREE.Line(new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(), new THREE.Vector3(0, 0, -1)]), new THREE.LineBasicMaterial({ color: 0xffe2a0, transparent: true, opacity: .8 })); l.visible = false; l.frustumCulled = false; this.scene.add(l); this.tracers.push({ l, t: 0 }); }
    if (hi) { this.composer = new EffectComposer(this.r, new THREE.WebGLRenderTarget(2, 2, { type: THREE.HalfFloatType, samples: 4 })); this.composer.addPass(new RenderPass(this.scene, this.cam)); this.composer.addPass(new UnrealBloomPass(new THREE.Vector2(256, 256), .22, .5, .92)); this.composer.addPass(new OutputPass()); }
    this.ro = new ResizeObserver(() => this.resize()); this.ro.observe(canvas.parentElement!); this.build(); this.resize(); this.raf = requestAnimationFrame(this.frame);
  }
  setMinimap(c: HTMLCanvasElement | null) { this.mini = c; }
  private resize() { const p = this.canvas.parentElement!, w = Math.max(2, p.clientWidth), h = Math.max(2, p.clientHeight), pr = Math.min(devicePixelRatio, this.quality === 'high' ? 1.75 : 1.25); this.r.setPixelRatio(pr); this.r.setSize(w, h, false); this.composer?.setPixelRatio(pr); this.composer?.setSize(w, h); this.cam.aspect = w / h; this.cam.updateProjectionMatrix(); }
  private teardownWorld() { this.actors.forEach(a => this.scene.remove(a.rig.g)); this.actors = []; this.colMap.clear(); if (this.W) { this.scene.remove(this.W.group); this.W.geos.forEach(g => g.dispose()); } if (this.rig) this.scene.remove(this.rig.g); if (this.keycardItem) { this.scene.remove(this.keycardItem); this.keycardItem = null; } this.world?.free(); }
  private build() {
    this.teardownWorld(); const hi = this.quality === 'high';
    this.world = new RAPIER.World({ x: 0, y: -22, z: 0 }); this.world.timestep = 1 / 60; this.W = buildWorld(this.scene, this.world, this.M, hi);
    this.navOpen = new NavGrid(BOUNDS.minX, BOUNDS.minZ, BOUNDS.maxX, BOUNDS.maxZ, navRects()); const v = DOORS.find(d => d.id === 'vault')!; this.navLocked = new NavGrid(BOUNDS.minX, BOUNDS.minZ, BOUNDS.maxX, BOUNDS.maxZ, [...navRects(), { x: v.x, z: v.z, w: v.w, d: .4 }]); this.nav = this.navLocked;
    this.scene.children.filter(o => (o as THREE.PointLight).isPointLight && o !== this.flashLight && (o as THREE.PointLight).userData.bank).forEach(o => this.scene.remove(o));
    for (const [x, z] of LIGHTS) { const l = new THREE.PointLight(0xfff0d8, 14, 13, 1.6); l.position.set(x, BANK.h - .4, z); l.userData.bank = true; this.scene.add(l); }
    this.kcc = this.world.createCharacterController(.02); this.kcc.setUp({ x: 0, y: 1, z: 0 }); this.kcc.enableAutostep(.35, .2, false); this.kcc.enableSnapToGround(.25);
    this.stance = 'stand'; this.px = PLAYER_SPAWN.x; this.pz = PLAYER_SPAWN.z; this.feetY = 0; this.vy = 0; this.yaw = PLAYER_SPAWN.yaw; this.pitch = 0; this.vel.set(0, 0);
    this.pBody = this.world.createRigidBody(RAPIER.RigidBodyDesc.kinematicPositionBased().setTranslation(this.px, .9, this.pz)); this.makePlayerCol();
    this.rig = buildRig({ shirt: 0x2a2f3a, pants: 0x20242c, vest: 0x39424d, mask: true, hat: 0x111111, weapon: 'none' }); this.rig.g.userData.base = FOOT; this.scene.add(this.rig.g);
    this.rigGuns = { pistol: gunModel('pistol'), rifle: gunModel('rifle') }; for (const k of ['pistol', 'rifle'] as const) { this.rigGuns[k].g.position.set(.1, .3, -.32); this.rig.torso.add(this.rigGuns[k].g); }
    this.vm.clear(); this.vmGuns = { pistol: gunModel('pistol'), rifle: gunModel('rifle') }; const glove = new THREE.MeshStandardMaterial({ color: 0x15171a, roughness: .8 });
    for (const k of ['pistol', 'rifle'] as const) { const g = this.vmGuns[k].g; for (const [x, y, z, sx, sy, sz] of [[0, -.08, -.1, .09, .09, .14], [.0, -.04, -.45, .09, .08, .14]] as const) { const h = new THREE.Mesh(new THREE.BoxGeometry(1, 1, 1), glove); h.scale.set(sx, sy, sz); h.position.set(x, y, k === 'pistol' && z < -.3 ? -.12 : z); g.add(h); } this.vm.add(g); }
    this.setWeapon('rifle', true); this.m = RL.newMission(); this.alarm = false; this.copsSpawned = 0; this.copTimer = 0; this.kills = this.shots = this.hits = this.civHits = 0; this.reload = 0; this.applyLoadout(); this.invuln = 0; this.revivesUsed = 0; this.won = false; this.hitT = 0; this.resetFx();
    this.W.copCars.forEach(c => { c.g.visible = false; }); this.sfx.alarm(false); this.sfx.drill(false); this.keycardTaken = false; this.manProg = 0; this.progress = 0; this.msg = ''; this.fire = this.aim = false;
    for (const g of GUARDS) this.spawnActor('guard', g.x, g.z, g.patrol); for (const c of CIVS) this.spawnActor('civ', c.x, c.z, []); this.spawnActor('manager', MANAGER.x, MANAGER.z, []);
    this.sun.target.position.set(this.px, 0, this.pz); this.state = 'ready'; this.emitHud(true);
  }
  /** Clears bullet holes, tracers and particles left over from a previous run. */
  private resetFx() { this.decals.forEach(d => { d.visible = false; }); this.decalI = 0; this.tracers.forEach(t => { t.t = 0; t.l.visible = false; }); this.pp.fill(-100); this.pl.fill(0); this.flashT = 0; }
  private applyLoadout() { const l = this.loadout; this.maxHp = RL.maxHp(l); this.hp = this.maxHp; this.drillSec = RL.drillSeconds(l); this.ammo = { pistol: { mag: RL.WEAPONS.pistol.mag, reserve: RL.reserveFor(RL.WEAPONS.pistol, l) }, rifle: { mag: RL.WEAPONS.rifle.mag, reserve: RL.reserveFor(RL.WEAPONS.rifle, l) } }; }
  /** Upgrades bought in the shop. Applies immediately unless a heist is running (then from the next heist). */
  setLoadout(l: RL.Loadout) { this.loadout = { ...l }; if (this.state !== 'playing' && this.state !== 'paused') { this.applyLoadout(); this.emitHud(true); } }
  setDifficulty(d: RL.Difficulty) { this.diff = RL.DIFFICULTY[d]; }
  private buzz(ms: number) { if (!this.haptics || this.reduced) return; try { navigator.vibrate?.(ms); } catch { /* unsupported */ } }
  private makePlayerCol() { const h = RL.STANCE[this.stance].h; if (this.pCol) this.world.removeCollider(this.pCol, true); this.pCol = this.world.createCollider(RAPIER.ColliderDesc.capsule(Math.max(.02, (h - 2 * PR) / 2), PR).setFriction(0), this.pBody); }
  start() { this.sfx.init(); if (this.state === 'over') this.build(); this.state = 'playing'; this.startT = this.clock; this.last = 0; this.hooks.onState('playing'); this.say('Get inside the bank. Stay low, stay quiet.', 5); }
  pause() { if (this.state !== 'playing') return; this.state = 'paused'; this.fire = false; this.aim = false; this.interact = false; this.sfx.drill(false); this.sfx.alarm(false); this.sfx.suspend(); this.hooks.onState('paused'); }
  resume() { if (this.state !== 'paused') return; this.state = 'playing'; this.last = 0; this.sfx.wake(); if (this.alarm) this.sfx.alarm(true); this.hooks.onState('playing'); }
  restart() { this.build(); this.start(); }
  /** Back to the main menu with a fresh, untouched level. */
  toMenu() { this.build(); this.sfx.wake(); this.hooks.onState('ready'); }
  /** One-time continue after being taken down (offered after a rewarded ad). */
  revive(): boolean {
    if (this.state !== 'over' || this.won || this.revivesUsed >= 1) return false;
    this.revivesUsed++; this.state = 'playing'; this.hp = Math.round(this.maxHp * .7); this.invuln = 4; this.lastHurt = this.clock; this.last = 0; this.fire = false; this.hurtT = 0;
    for (const a of this.actors) a.cool = Math.max(a.cool, 1.5); this.sfx.wake(); if (this.alarm) this.sfx.alarm(true); this.hooks.onState('playing'); this.say('Back in the fight!', 3); return true;
  }
  // ---- input API
  setMove(x: number, z: number) { this.mx = x; this.mz = z; } look(dx: number, dy: number) { if (this.state !== 'playing') return; const k = this.sens * (this.aim ? .6 : 1); this.yaw -= dx * k; this.pitch = Math.max(-1.45, Math.min(1.45, this.pitch - dy * k)); }
  setFire(b: boolean) { this.fire = b; } setAim(b: boolean) { this.aim = b; } setSprint(b: boolean) { this.sprint = b; } setInteract(b: boolean) { if (b && !this.interact) this.interactEdge = true; this.interact = b; }
  press(a: 'jump' | 'crouch' | 'prone' | 'cycle' | 'reload' | 'swap' | 'view' | 'sprint' | 'rifle' | 'pistol') {
    if (this.state !== 'playing') return;
    if (a === 'jump') this.jumpReq = true; else if (a === 'crouch') this.setStance(this.stance === 'crouch' ? 'stand' : 'crouch'); else if (a === 'prone') this.setStance(this.stance === 'prone' ? 'stand' : 'prone'); else if (a === 'cycle') this.setStance(RL.nextStance(this.stance));
    else if (a === 'reload') this.startReload(); else if (a === 'rifle' || a === 'pistol') this.setWeapon(a); else if (a === 'swap') this.setWeapon(this.wid === 'rifle' ? 'pistol' : 'rifle'); else if (a === 'view') this.tp = !this.tp; else this.sprint = !this.sprint;
  }
  private setWeapon(id: RL.WeaponId, force = false) { if (!force && id === this.wid) return; this.wid = id; this.reload = 0; for (const k of ['pistol', 'rifle'] as const) { this.vmGuns[k].g.visible = k === id; this.rigGuns[k].g.visible = k === id; } this.rig.gun = this.rigGuns[id].g; this.rig.muzzle = this.rigGuns[id].muzzle; this.rig.flash = this.rigGuns[id].flash; }
  private setStance(s: RL.Stance) {
    if (s === this.stance) return; const nh = RL.STANCE[s].h, oh = RL.STANCE[this.stance].h;
    if (nh > oh) { const hit = this.world.castRay(new RAPIER.Ray({ x: this.px, y: this.feetY + .1, z: this.pz }, { x: 0, y: 1, z: 0 }), nh, true, undefined, undefined, this.pCol); if (hit && hit.timeOfImpact < nh - .15) { this.say('Not enough room to stand', 1.2); return; } }
    this.stance = s; this.makePlayerCol(); this.pBody.setTranslation({ x: this.px, y: this.feetY + nh / 2 + .02, z: this.pz }, true);
  }
  private say(t: string, s = 3) { this.msg = t; this.msgT = s; }
  // ---- helpers
  private eyePos(out = new THREE.Vector3()) { return out.set(this.px, this.feetY + this.eyeH, this.pz); }
  private fwd2() { return new THREE.Vector2(-Math.sin(this.yaw), -Math.cos(this.yaw)); }
  private spawnActor(kind: Actor['kind'], x: number, z: number, patrol: [number, number][]) {
    const cop = kind === 'cop'; const rig = cop ? buildRig({ shirt: 0x1d3f9a, pants: 0x17264a, vest: 0x111a33, helmet: 0x0f1a3a, weapon: 'rifle' }) : kind === 'guard' ? buildRig({ shirt: 0x6a6f78, pants: 0x2a2f38, vest: 0x2a2a2a, hat: 0x2a2f38, weapon: 'pistol' }) : kind === 'manager' ? buildRig({ shirt: 0xe8e8ea, pants: 0x2a2a3a, weapon: 'none' }) : buildRig({ shirt: [0x8a4a4a, 0x4a7a8a, 0x7a8a4a, 0x8a6a9a][this.nextId % 4], pants: 0x3a3a4a, weapon: 'none', skin: [0xe0b08a, 0xc08a60, 0x8a5a3a][this.nextId % 3] });
    rig.g.userData.base = FOOT; rig.g.position.set(x, FOOT, z); this.scene.add(rig.g);
    const a: Actor = { id: this.nextId++, kind, rig, pos: new THREE.Vector3(x, 0, z), yaw: kind === 'civ' ? rand(0, 6.28) : Math.PI, hp: kind === 'cop' ? 100 : 80, dead: false, state: patrol.length > 1 ? 'patrol' : 'idle', patrol, pi: 0, path: [], pathI: 0, repath: 0, look: Math.random() * .2, canSee: false, cool: 1, last: new THREE.Vector3(), hasLast: false, speed: cop ? 4 : 3.2, t: Math.random() * 5, susp: 0, walking: false, weapon: cop ? 'rifle' : kind === 'guard' ? 'pistol' : 'none', pause: 0 };
    a.body = this.world.createRigidBody(RAPIER.RigidBodyDesc.kinematicPositionBased().setTranslation(x, .9, z)); a.col = this.world.createCollider(RAPIER.ColliderDesc.capsule(.6, PR), a.body); this.colMap.set(a.col.handle, a); this.actors.push(a); return a;
  }
  private los(a: Actor) {
    const o = { x: a.pos.x, y: 1.5, z: a.pos.z }, t = { x: this.px, y: this.feetY + RL.STANCE[this.stance].h * .6, z: this.pz }; const dx = t.x - o.x, dy = t.y - o.y, dz = t.z - o.z, d = Math.hypot(dx, dy, dz); if (d > 60) return false;
    const hit = this.world.castRay(new RAPIER.Ray(o, { x: dx / d, y: dy / d, z: dz / d }), d + .5, true, undefined, undefined, a.col); return !!hit && hit.collider.handle === this.pCol.handle;
  }
  private raiseAlarm(why: string) {
    if (this.alarm) return; this.alarm = true; this.alarmAt = this.clock; this.sfx.alarm(true); this.say(`ALARM! ${why} Police are coming.`, 4); this.W.copCars.forEach(c => { c.g.visible = true; });
    for (const a of this.actors) if (!a.dead) { if (a.kind === 'civ' || a.kind === 'manager') a.state = 'cower'; else if (a.kind === 'guard') { a.state = 'chase'; a.hasLast = true; a.last.set(this.px, 0, this.pz); a.repath = 0; } }
  }
  private noise(radius: number, loud: boolean) {
    for (const a of this.actors) if (!a.dead && a.kind === 'guard' && Math.hypot(a.pos.x - this.px, a.pos.z - this.pz) < radius && (a.state === 'idle' || a.state === 'patrol' || a.state === 'investigate')) { a.state = 'investigate'; a.hasLast = true; a.last.set(this.px, 0, this.pz); a.repath = 0; if (loud) this.raiseAlarm('Gunshots!'); }
  }
  private hurt(d: number) { if (this.state !== 'playing' || this.invuln > 0) return; this.hp -= d; this.hurtT = 1; this.lastHurt = this.clock; this.sfx.pain(); this.buzz(35); if (this.hp <= 0) this.finish(false, 'You were taken down.'); }
  // ---- weapons
  private startReload() { const w = RL.WEAPONS[this.wid], a = this.ammo[this.wid]; if (this.reload > 0 || a.mag >= w.mag || a.reserve <= 0) return; this.reload = w.reload; this.sfx.reload(); }
  private tryShoot() {
    const w = RL.WEAPONS[this.wid], a = this.ammo[this.wid]; if (this.reload > 0 || this.cool > 0) return; if (a.mag <= 0) { this.sfx.empty(); this.cool = .3; this.startReload(); return; }
    a.mag--; this.cool = w.rate; this.shots++; const moving = this.vel.length() > .5, sp = RL.spreadFor(w, this.stance, moving, this.aim, this.bloom);
    const o = this.cam.getWorldPosition(new THREE.Vector3()), d = this.cam.getWorldDirection(new THREE.Vector3()), right = new THREE.Vector3().crossVectors(d, this.cam.up).normalize(), up = new THREE.Vector3().crossVectors(right, d).normalize();
    d.addScaledVector(right, (Math.random() - .5) * 2 * sp).addScaledVector(up, (Math.random() - .5) * 2 * sp).normalize();
    const hit = this.world.castRayAndGetNormal(new RAPIER.Ray(o, d), 150, true, undefined, undefined, this.pCol); const dist = hit ? hit.timeOfImpact : 150, pt = o.clone().addScaledVector(d, dist);
    const mz = (this.tp ? this.rig.muzzle : this.vmGuns[this.wid].muzzle)!.getWorldPosition(new THREE.Vector3()); this.addTracer(mz, pt); this.flashT = .05; this.sfx.shot(w.noise >= 30); this.noise(w.noise, w.noise >= 30);
    this.bloom = Math.min(.05, this.bloom + .004); this.pitch = Math.min(1.45, this.pitch + w.recoil * rand(.7, 1.3)); this.yaw += rand(-.004, .004) * (w.recoil * 60); this.recoilT = 1;
    if (hit) {
      const actor = this.colMap.get(hit.collider.handle);
      if (actor && !actor.dead) {
        const head = pt.y > actor.pos.y + 1.5; const unaware = actor.kind === 'guard' && (actor.state === 'idle' || actor.state === 'patrol' || actor.state === 'investigate');
        this.hits++; this.hitT = .22; this.hitHead = head; this.sfx.hit(); this.burst(pt, 0xaa1010, 8);
        if (RL.stealthKill(w, unaware)) { actor.hp = 0; this.kill(actor); this.say('Silent takedown', 1.6); } // suppressed shot on an unaware guard: no alarm
        else { actor.hp -= RL.hitDamage(w, dist, head); if (actor.kind === 'guard' || actor.kind === 'cop') { actor.state = 'combat'; this.raiseAlarm('Shots fired!'); } if (actor.hp <= 0) this.kill(actor); }
      }
      else if (!actor) { this.burst(pt, 0xffd9a0, 5); const n = hit.normal; const dc = this.decals[this.decalI++ % this.decals.length]; dc.visible = true; dc.position.copy(pt).addScaledVector(new THREE.Vector3(n.x, n.y, n.z), .012); dc.lookAt(pt.x + n.x, pt.y + n.y, pt.z + n.z); }
    }
    if (a.mag === 0 && a.reserve > 0) this.startReload();
  }
  private kill(a: Actor) {
    a.dead = true; a.hp = 0; if (a.col) { this.colMap.delete(a.col.handle); this.world.removeCollider(a.col, false); a.col = undefined; } if (a.body) { this.world.removeRigidBody(a.body); a.body = undefined; }
    if (a.kind === 'guard' || a.kind === 'cop') this.kills++; else { this.civHits++; this.say('Civilian down! -$25,000 from your cut', 3); }
    if (a.kind === 'manager' && !this.m.keycard && !this.keycardItem) { const k = new THREE.Mesh(new THREE.BoxGeometry(.18, .02, .11), new THREE.MeshStandardMaterial({ color: 0xffffff, emissive: 0x88aaff, emissiveIntensity: .8 })); k.position.set(a.pos.x, .3, a.pos.z); this.scene.add(k); this.keycardItem = k; this.say('The manager dropped a keycard', 3); }
    animate(a.rig, { t: 0, speed: 0, stance: 'stand', armed: false, dead: true, hands: false });
  }
  private addTracer(from: THREE.Vector3, to: THREE.Vector3) { const t = this.tracers.find(x => x.t <= 0) ?? this.tracers[0]; t.t = .07; t.l.visible = true; const p = t.l.geometry.attributes.position as THREE.BufferAttribute; p.setXYZ(0, from.x, from.y, from.z); p.setXYZ(1, to.x, to.y, to.z); p.needsUpdate = true; }
  private burst(at: THREE.Vector3, hex: number, n: number) { if (this.reduced) return; const c = new THREE.Color(hex); for (let k = 0; k < n; k++) { const i = this.pi++ % 120; this.pp.set([at.x, at.y, at.z], i * 3); this.pv.set([rand(-2, 2), rand(.5, 3), rand(-2, 2)], i * 3); this.pl[i] = rand(.25, .55); this.pc.set([c.r, c.g, c.b], i * 3); } }
  // ---- doors
  private setDoor(d: Door, open: boolean) { if (d.target === (open ? 1 : 0)) return; d.target = open ? 1 : 0; this.sfx.door(); if (d.def.id === 'staff' && open) this.m.staffOpen = true; if (d.def.id === 'vault' && open) { this.nav = this.navOpen; } }
  private updateDoors(dt: number) {
    for (const d of this.W.doors) {
      const dx = this.px - d.def.x, dz = this.pz - d.def.z, dp = Math.hypot(dx, dz); let near = false;
      for (const a of this.actors) if (!a.dead && a.kind !== 'civ' && Math.hypot(a.pos.x - d.def.x, a.pos.z - d.def.z) < 2) near = true;
      if (d.def.kind === 'auto') this.setDoor(d, dp < 3.6 || near || this.actors.some(a => !a.dead && Math.hypot(a.pos.x - d.def.x, a.pos.z - d.def.z) < 3));
      else if (d.def.id !== 'vault' && near && d.def.kind !== 'locked') this.setDoor(d, true); else if (d.def.id === 'staff' && near && this.alarm) { d.locked = false; this.setDoor(d, true); }
      d.open += Math.sign(d.target - d.open) * Math.min(Math.abs(d.target - d.open), dt * (d.def.kind === 'vault' ? .25 : 2.2)); const e = d.open, horiz = d.def.along === 'x', w = d.def.w;
      if (d.def.kind === 'auto') d.panels.forEach((p, k) => { const s = k ? 1 : -1, base = (k - .5) * (w / 2); const o = base + s * -0 + (k ? 1 : -1) * e * (w / 2 - .05); if (horiz) p.position.x = o; else p.position.z = o; });
      else if (d.def.kind === 'vault') { if (horiz) d.panels[0].position.x = e * (w + .4); else d.panels[0].position.z = e * (w + .4); }
      else d.group.rotation.y = (horiz ? -1 : 1) * e * 1.6;
      d.body.setEnabled(e < .45);
    }
  }
  // ---- interaction
  private updateInteract(dt: number) {
    this.prompt = ''; this.prog(0); const f = this.fwd2(); type Cand = { score: number; act: () => void; text: string; hold?: boolean; tick?: (dt: number) => void }; const pickR: { cur: Cand | null } = { cur: null };
    const consider = (x: number, z: number, text: string, reach: number, act: () => void, hold = false, tick?: (dt: number) => void, facing = .25) => { const dx = x - this.px, dz = z - this.pz, dist = Math.hypot(dx, dz); if (dist > reach) return; const dot = (dx * f.x + dz * f.y) / Math.max(dist, .01); if (dist > 1.1 && dot < facing) return; const score = dist - dot; if (!pickR.cur || score < pickR.cur.score) pickR.cur = { score, act, text, hold, tick }; };
    for (const d of this.W.doors) {
      const id = d.def.id; if (d.def.kind === 'auto') continue;
      if (id === 'vault') { if (!this.m.vaultOpen) consider(d.def.x, d.def.z + 1.2, this.m.staffOpen ? 'Hold E: drill the vault door' : 'Vault door', 3.2, () => {}, true, dt2 => { if (!this.m.staffOpen) return; this.drilling = true; this.m.drill = Math.min(1, this.m.drill + dt2 / this.drillSec); if (this.m.drill >= 1) { this.m.vaultOpen = true; d.locked = false; this.setDoor(d, true); this.say('Vault open!', 3); } }); }
      else if (id === 'staff' && d.locked) consider(d.def.x, d.def.z + .8, this.m.keycard ? 'E: swipe keycard' : 'STAFF ONLY: needs keycard', 2.4, () => { if (this.m.keycard) { d.locked = false; this.setDoor(d, true); this.say('Door unlocked', 2); } else this.say('Locked. Get the manager\'s keycard.', 2); });
      else consider(d.def.x, d.def.z, d.target ? 'E: close door' : 'E: open door', 2.3, () => this.setDoor(d, !d.target));
    }
    for (const l of this.W.loot) if (!l.taken && this.m.vaultOpen) consider(l.x, l.z, this.m.bags >= RL.MAX_BAGS ? 'Bag is full' : 'E: grab cash', 2, () => { if (this.m.bags >= RL.MAX_BAGS) { this.say('You cannot carry more', 2); return; } l.taken = true; l.mesh.visible = false; this.m.bags++; this.sfx.pick(); this.say(`+${RL.fmtMoney(RL.BAG_VALUE)} (${this.m.bags}/${RL.MAX_BAGS} bags)`, 2); });
    const man = this.actors.find(a => a.kind === 'manager'); if (man && !man.dead && !this.m.keycard) consider(man.pos.x, man.pos.z, 'Hold E: demand the keycard', 3.5, () => {}, true, dt2 => { this.manProg = Math.min(1, this.manProg + dt2 / 1.6); if (this.manProg >= 1) { this.m.keycard = true; this.sfx.pick(); this.say('Keycard obtained', 3); } }, .6);
    if (this.keycardItem && !this.m.keycard) consider(this.keycardItem.position.x, this.keycardItem.position.z, 'E: take keycard', 2, () => { this.m.keycard = true; if (this.keycardItem) { this.scene.remove(this.keycardItem); this.keycardItem = null; } this.sfx.pick(); this.say('Keycard obtained', 2); });
    const b = pickR.cur; this.drilling = false;
    if (b) { this.prompt = b.text; if (b.hold) { if (this.interact) { b.tick?.(dt); } } else if (this.interactEdge) b.act(); this.prog(b.text.includes('drill') ? this.m.drill : b.text.includes('demand') ? this.manProg : 0); }
    if (!(b && b.hold && this.interact)) this.manProg = Math.max(0, this.manProg - dt * .5); this.interactEdge = false; this.sfx.drill(this.drilling && !this.muted()); if (this.drilling && this.m.drill > .02) { this.noise(26, false); } // the drill is loud: guards come to investigate (they raise the alarm only if they spot you)
  }
  private muted() { return this.sfx.muted; } private prog(v: number) { this.progress = v; }
  // ---- AI
  private moveAlong(a: Actor, tx: number, tz: number, speed: number, dt: number) {
    a.repath -= dt; if (a.repath <= 0 || !a.path.length) { a.path = this.nav.findPath(a.pos.x, a.pos.z, tx, tz); a.pathI = a.path.length > 1 ? 1 : 0; a.repath = .6 + Math.random() * .3; }
    const wp = a.path[a.pathI]; if (!wp) { a.walking = false; return true; } const dx = wp[0] - a.pos.x, dz = wp[1] - a.pos.z, d = Math.hypot(dx, dz);
    if (d < .35) { a.pathI++; if (a.pathI >= a.path.length) { a.walking = false; return true; } return false; }
    const s = Math.min(d, speed * dt); a.pos.x += dx / d * s; a.pos.z += dz / d * s; a.walking = true; a.yaw = this.turn(a.yaw, Math.atan2(-dx, -dz), dt * 8); return false;
  }
  private turn(cur: number, tgt: number, k: number) { let d = ((tgt - cur + Math.PI) % (Math.PI * 2) + Math.PI * 2) % (Math.PI * 2) - Math.PI; return cur + d * Math.min(1, k); }
  private enemyFire(a: Actor, dist: number) {
    const moving = this.vel.length() > .5; const chance = RL.hitChance(dist, this.stance, moving); const from = a.rig.muzzle?.getWorldPosition(new THREE.Vector3()) ?? new THREE.Vector3(a.pos.x, 1.3, a.pos.z);
    const to = new THREE.Vector3(this.px, this.feetY + RL.STANCE[this.stance].h * .55, this.pz); const hitP = Math.random() < chance; if (!hitP) to.add(new THREE.Vector3(rand(-1.2, 1.2), rand(-.5, .8), rand(-1.2, 1.2)));
    this.addTracer(from, to); this.sfx.enemyShot(); if (a.rig.flash) { a.rig.flash.visible = true; a.t = Math.min(a.t, 0); } if (hitP) this.hurt(Math.max(1, Math.round((a.kind === 'cop' ? 7 : 9) * this.diff.enemyDmg)));
  }
  private updateActor(a: Actor, dt: number) {
    if (a.dead) return; a.t += dt; a.cool -= dt; const dx = this.px - a.pos.x, dz = this.pz - a.pos.z, dist = Math.hypot(dx, dz);
    if (a.rig.flash && a.rig.flash.visible && a.cool < (a.kind === 'cop' ? .45 : .8)) a.rig.flash.visible = false;
    if (a.kind === 'civ' || a.kind === 'manager') { a.walking = false; if (this.alarm) a.state = 'cower'; }
    else {
      a.look -= dt; if (a.look <= 0) { a.look = .22; a.canSee = this.los(a); }
      const fx = -Math.sin(a.yaw), fz = -Math.cos(a.yaw), dot = dist > .01 ? (dx * fx + dz * fz) / dist : 1;
      if (a.state === 'idle' || a.state === 'patrol' || a.state === 'investigate') {
        const rng = RL.detectRange(this.stance, this.vel.length() > .5, this.diff.detect * RL.stealthMul(this.loadout));
        if (a.canSee && ((dist < rng && dot > .45) || dist < 4)) a.susp += dt * (dist < 8 ? 2 : 1); else a.susp = Math.max(0, a.susp - dt * .5);
        if (a.susp > .8) { a.state = 'combat'; this.raiseAlarm('A guard spotted you!'); }
        else if (a.state === 'investigate') { if (this.moveAlong(a, a.last.x, a.last.z, 2.6, dt)) { a.state = a.patrol.length > 1 ? 'patrol' : 'idle'; } }
        else if (a.state === 'patrol') { const p = a.patrol[a.pi]; if (a.pause > 0) a.pause -= dt; else if (this.moveAlong(a, p[0], p[1], 1.5, dt)) { a.pi = (a.pi + 1) % a.patrol.length; a.pause = rand(.5, 2.5); a.repath = 0; } }
        else a.walking = false;
      } else {
        const known = a.kind === 'cop' || a.canSee; if (known) { a.last.set(this.px, 0, this.pz); a.hasLast = true; }
        if (a.canSee && dist < 28) {
          a.state = 'combat'; a.yaw = this.turn(a.yaw, Math.atan2(-dx, -dz), dt * 9); const hold = a.kind === 'cop' ? 9 : 7;
          if (dist > hold + 5) this.moveAlong(a, this.px, this.pz, a.speed, dt); else a.walking = false;
          if (a.cool <= 0 && this.state === 'playing') { a.cool = a.kind === 'cop' ? rand(.35, .8) : rand(.8, 1.5); this.enemyFire(a, dist); }
        } else { a.state = 'chase'; if (a.hasLast) this.moveAlong(a, a.last.x, a.last.z, a.speed, dt); }
      }
    }
    if (a.body) a.body.setNextKinematicTranslation({ x: a.pos.x, y: .9, z: a.pos.z });
    a.rig.g.position.x = a.pos.x; a.rig.g.position.z = a.pos.z; a.rig.g.rotation.y = a.yaw;
    const cow = a.state === 'cower'; animate(a.rig, { t: a.t, speed: a.walking ? (a.state === 'chase' || a.state === 'combat' ? 5 : 2) : 0, stance: cow ? 'crouch' : 'stand', armed: a.weapon !== 'none' && !cow, dead: false, hands: cow });
  }
  private spawnCop() { const [x, z] = COP_SPAWNS[Math.floor(Math.random() * COP_SPAWNS.length)]; const a = this.spawnActor('cop', x + rand(-2, 2), z + rand(-2, 2), []); a.state = 'chase'; a.hasLast = true; a.last.set(this.px, 0, this.pz); this.copsSpawned++; }
  // ---- main loop
  private updatePlayer(dt: number) {
    const st = RL.STANCE[this.stance], f = this.fwd2(), right = new THREE.Vector2(-f.y, f.x); // right = (cos yaw, -sin yaw)
    let ix = this.mx, iz = this.mz; const l = Math.hypot(ix, iz); if (l > 1) { ix /= l; iz /= l; }
    const spr = this.sprint && this.stance === 'stand' && iz > .3 && !this.aim && !this.fire; let spd = (spr ? st.sprint : st.speed) * RL.carrySlow(this.m.bags) * (this.aim ? .7 : 1);
    const tx = (f.x * iz + right.x * ix) * spd, tz = (f.y * iz + right.y * ix) * spd, k = Math.min(1, dt * 11); this.vel.x += (tx - this.vel.x) * k; this.vel.y += (tz - this.vel.y) * k;
    if (this.grounded) { this.vy = -1; if (this.jumpReq && this.stance === 'stand') { this.vy = 6.4; this.grounded = false; } } else this.vy -= 22 * dt; this.jumpReq = false;
    this.kcc.computeColliderMovement(this.pCol, { x: this.vel.x * dt, y: this.vy * dt, z: this.vel.y * dt }); const mv = this.kcc.computedMovement(), t = this.pBody.translation(); this.grounded = this.kcc.computedGrounded();
    this.pBody.setNextKinematicTranslation({ x: t.x + mv.x, y: t.y + mv.y, z: t.z + mv.z }); if (this.grounded && this.vy < 0) this.vy = -1;
    const nt = this.pBody.translation(); this.px = nt.x; this.pz = nt.z; this.feetY = nt.y - st.h / 2; const eye = st.eye; this.eyeH += (eye - this.eyeH) * Math.min(1, dt * 12);
    if (this.grounded && this.vel.length() > .8 && this.stance !== 'prone') { this.stepT += this.vel.length() * dt; if (this.stepT > (spr ? 2.2 : 1.7)) { this.stepT = 0; this.sfx.step(); } }
    if (this.feetY < -6) this.finish(false, 'You fell out of the world.');
  }
  private update(dt: number) {
    this.clock += dt; this.updatePlayer(dt); this.updateDoors(dt);
    const w = RL.WEAPONS[this.wid]; this.cool -= dt; this.bloom = Math.max(0, this.bloom - dt * .05); this.recoilT = Math.max(0, this.recoilT - dt * 8); this.hurtT = Math.max(0, this.hurtT - dt * 1.5); this.hitT = Math.max(0, this.hitT - dt); this.invuln = Math.max(0, this.invuln - dt);
    if (this.reload > 0) { this.reload -= dt; if (this.reload <= 0) { const a = this.ammo[this.wid], n = Math.min(w.mag - a.mag, a.reserve); a.mag += n; a.reserve -= n; } }
    if (this.fire && (w.auto || !this.latched)) this.tryShoot(); this.latched = this.fire;
    this.aimT += ((this.aim ? 1 : 0) - this.aimT) * Math.min(1, dt * 12); this.updateInteract(dt);
    for (const a of this.actors) this.updateActor(a, dt);
    if (this.alarm) { const el = this.clock - this.alarmAt; this.copTimer -= dt; const allowed = RL.copsAllowed(el, this.diff.copCap); if (this.copsSpawned < allowed && this.copTimer <= 0) { this.spawnCop(); this.copTimer = 2.5; } this.W.copCars.forEach(c => { const on = Math.sin(this.clock * 14) > 0; c.red.emissiveIntensity = on ? 3 : .1; c.blue.emissiveIntensity = on ? .1 : 3; }); }
    const cap = this.maxHp * .6; if (this.hp < cap && this.clock - this.lastHurt > 8) this.hp = Math.min(cap, this.hp + dt * 3);
    if (!this.m.inside && insideBank(this.px, this.pz)) { this.m.inside = true; this.say('You are in. Find the manager.', 3); }
    if (this.m.bags > 0 && Math.hypot(this.px - EXTRACT.x, this.pz - EXTRACT.z) < EXTRACT.r) { this.m.extracted = true; this.finish(true, 'You made it to the van!'); }
    this.msgT -= dt; if (this.msgT <= 0) this.msg = '';
  }
  private finish(win: boolean, why: string) {
    if (this.state !== 'playing') return; this.state = 'over'; this.fire = false; this.sfx.alarm(false); this.sfx.drill(false); win ? this.sfx.win() : this.sfx.lose(); if (document.pointerLockElement) document.exitPointerLock();
    this.won = win; const bags = this.m.bags, payout = win ? Math.round(RL.payout(bags, this.civHits, this.alarm) * this.diff.pay) : 0; this.hooks.onState('over');
    this.hooks.onResult({ win, why, bags, payout, time: this.clock - this.startT, kills: this.kills, shots: this.shots, hits: this.hits, civHits: this.civHits, alarmed: this.alarm, stars: win ? RL.stars(bags, this.alarm, this.hp) : 0, canRevive: !win && this.revivesUsed < 1 });
  }
  private objTarget(): [number, number] {
    const o = RL.objective(this.m), d = (id: string) => DOORS.find(x => x.id === id)!;
    if (o === 'enter') return [0, 7]; if (o === 'keycard') { const m = this.actors.find(a => a.kind === 'manager'); return this.keycardItem ? [this.keycardItem.position.x, this.keycardItem.position.z] : m ? [m.pos.x, m.pos.z] : [MANAGER.x, MANAGER.z]; }
    if (o === 'staff') return [d('staff').x, d('staff').z]; if (o === 'drill') return [d('vault').x, d('vault').z]; if (o === 'loot') { const l = this.W.loot.filter(x => !x.taken).sort((a, b) => Math.hypot(a.x - this.px, a.z - this.pz) - Math.hypot(b.x - this.px, b.z - this.pz))[0]; return l ? [l.x, l.z] : [0, -20]; } return [EXTRACT.x, EXTRACT.z];
  }
  private emitHud(force = false) {
    if (!force && this.clock - this.lastHud < .08) return; this.lastHud = this.clock; const w = RL.WEAPONS[this.wid], a = this.ammo[this.wid], o = RL.objective(this.m), t = this.objTarget();
    this.hooks.onHud({ hp: Math.max(0, Math.round(this.hp)), weapon: w.name, mag: a.mag, reserve: a.reserve, reloading: this.reload > 0, stance: this.stance, obj: RL.OBJ_TEXT[o], objDist: Math.round(Math.hypot(t[0] - this.px, t[1] - this.pz)), prompt: this.prompt, progress: this.progress, bags: this.m.bags, alarm: this.alarm, eta: this.alarm ? Math.max(0, Math.ceil(12 - (this.clock - this.alarmAt))) : -1, cops: this.actors.filter(x => x.kind === 'cop' && !x.dead).length, hit: Math.max(this.hurtT, 0), aim: this.aim, msg: this.msg, mission: { ...this.m }, fps: this.fps, maxHp: this.maxHp, hm: this.hitT > 0 ? (this.hitHead ? 2 : 1) : 0 });
  }
  private drawMini() {
    const c = this.mini; if (!c) return; const g = c.getContext('2d'); if (!g) return; const S = c.width, sc = S / 56, cx = S / 2; g.clearRect(0, 0, S, S); g.save(); g.beginPath(); g.arc(cx, cx, cx - 1, 0, 6.3); g.clip(); g.fillStyle = 'rgba(8,14,24,.8)'; g.fillRect(0, 0, S, S);
    g.translate(cx, cx); g.rotate(this.yaw); const P = (x: number, z: number) => [(x - this.px) * sc, (z - this.pz) * sc];
    g.fillStyle = '#5a6a80'; for (const r of this.miniWalls) { const [x, z] = P(r.x, r.z); g.fillRect(x - r.w * sc / 2, z - r.d * sc / 2, r.w * sc, r.d * sc); }
    for (const d of this.W.doors) { const [x, z] = P(d.def.x, d.def.z); g.fillStyle = d.locked ? '#ffb347' : '#6bd36b'; g.fillRect(x - 3, z - 3, 6, 6); }
    for (const l of this.W.loot) if (!l.taken && this.m.vaultOpen) { const [x, z] = P(l.x, l.z); g.fillStyle = '#7dff6b'; g.fillRect(x - 2, z - 2, 4, 4); }
    for (const a of this.actors) if (!a.dead && (a.kind === 'guard' || a.kind === 'cop') && Math.hypot(a.pos.x - this.px, a.pos.z - this.pz) < 26) { const [x, z] = P(a.pos.x, a.pos.z); g.fillStyle = a.kind === 'cop' ? '#4aa0ff' : '#ff4a4a'; g.beginPath(); g.arc(x, z, 3.5, 0, 6.3); g.fill(); }
    const t = this.objTarget(), [tx, tz] = P(t[0], t[1]), ang = Math.atan2(tz, tx), dd = Math.min(Math.hypot(tx, tz), cx - 8); g.fillStyle = '#ffd23f'; g.beginPath(); g.arc(Math.cos(ang) * dd, Math.sin(ang) * dd, 5, 0, 6.3); g.fill(); g.restore();
    g.fillStyle = '#ffffff'; g.beginPath(); g.moveTo(cx, cx - 7); g.lineTo(cx - 5, cx + 5); g.lineTo(cx + 5, cx + 5); g.closePath(); g.fill();
  }
  private frame = (now: number) => {
    this.raf = requestAnimationFrame(this.frame); const dt = this.last ? Math.min((now - this.last) / 1000, .05) : 0; this.last = now; this.fpsAcc += dt; this.fpsN++; if (this.fpsAcc > 1) { this.fps = Math.round(this.fpsN / this.fpsAcc); this.fpsAcc = 0; this.fpsN = 0; }
    if (this.state === 'playing' && dt > 0) { this.update(dt); this.world.step(); this.emitHud(); if (this.mini && this.clock - this.lastMini > .12) { this.lastMini = this.clock; this.drawMini(); } }
    this.updateVisuals(dt); this.r.info.reset(); if (this.composer) this.composer.render(); else this.r.render(this.scene, this.cam);
  };
  private updateVisuals(dt: number) {
    const st = RL.STANCE[this.stance], now = this.clock; const spd = this.vel.length();
    // player third-person model
    this.rig.g.visible = this.tp; this.rig.g.position.x = this.px; this.rig.g.position.z = this.pz; this.rig.g.rotation.y = this.yaw; this.rig.g.userData.base = this.feetY + FOOT;
    animate(this.rig, { t: now, speed: this.grounded ? spd : 0, stance: this.stance, armed: true, dead: false, hands: false }); if (this.stance === 'prone') this.rig.g.position.y = this.feetY + .3; this.rig.torso.rotation.x += (this.pitch * .3);
    // camera
    const ey = this.feetY + this.eyeH, e = new THREE.Euler(this.pitch, this.yaw, 0, 'YXZ'); this.cam.fov += ((this.aim ? 48 : this.touch ? 80 : 72) - this.cam.fov) * Math.min(1, dt * 12); this.cam.updateProjectionMatrix();
    if (this.tp) {
      const pivot = new THREE.Vector3(this.px, ey * .95, this.pz), off = new THREE.Vector3(this.aim ? .35 : .65, .25, this.aim ? 1.6 : 2.7).applyEuler(e), len = off.length(); const hit = this.world.castRay(new RAPIER.Ray(pivot, { x: off.x / len, y: off.y / len, z: off.z / len }), len, true, undefined, undefined, this.pCol);
      const k = hit ? Math.max(.25, (hit.timeOfImpact - .2) / len) : 1; this.cam.position.copy(pivot).addScaledVector(off, k); this.cam.quaternion.setFromEuler(e);
    } else { this.cam.position.set(this.px, ey + (spd > 1 && this.grounded ? Math.sin(now * 9) * .015 : 0), this.pz); this.cam.quaternion.setFromEuler(e); }
    this.sun.position.set(this.px + 55, 70, this.pz + 35); this.sun.target.position.set(this.px, 0, this.pz); this.sun.target.updateMatrixWorld();
    // viewmodel
    this.vm.visible = !this.tp; const g = this.vmGuns[this.wid].g, hip = new THREE.Vector3(.17, -.18, -.4), ads = new THREE.Vector3(0, -.12, -.3), p = hip.lerp(ads, this.aimT); g.position.set(p.x + Math.sin(now * 6) * .004 * Math.min(spd, 4) / 4, p.y + Math.abs(Math.sin(now * 6)) * .006 * Math.min(spd, 4) / 4 - (this.reload > 0 ? .08 : 0), p.z + this.recoilT * .05); g.rotation.set(this.recoilT * .06 + (this.reload > 0 ? -.4 : 0), 0, 0);
    const mz = this.tp ? this.rig.flash : this.vmGuns[this.wid].flash; this.flashT -= dt; for (const gg of [this.vmGuns.rifle.flash, this.vmGuns.pistol.flash, this.rigGuns.rifle.flash, this.rigGuns.pistol.flash]) gg.visible = false; if (this.flashT > 0 && mz) { mz.visible = true; mz.scale.setScalar(.1 + Math.random() * .1); this.flashLight.intensity = 8; (this.tp ? this.rig.muzzle : this.vmGuns[this.wid].muzzle)?.getWorldPosition(this.flashLight.position); } else this.flashLight.intensity = 0;
    // tracers + particles
    for (const t of this.tracers) if (t.t > 0) { t.t -= dt; if (t.t <= 0) t.l.visible = false; else (t.l.material as THREE.LineBasicMaterial).opacity = t.t * 12; }
    for (let i = 0; i < 120; i++) { if (this.pl[i] > 0) { this.pl[i] -= dt; for (let a = 0; a < 3; a++) this.pp[i * 3 + a] += this.pv[i * 3 + a] * dt; this.pv[i * 3 + 1] -= 9 * dt; } else this.pp[i * 3 + 1] = -100; } (this.pGeo.attributes.position as THREE.BufferAttribute).needsUpdate = true; (this.pGeo.attributes.color as THREE.BufferAttribute).needsUpdate = true;
    this.W.loot.forEach(l => { l.mesh.rotation.y += dt * 1.2; }); if (this.keycardItem) { this.keycardItem.rotation.y += dt * 2; this.keycardItem.position.y = .5 + Math.sin(now * 3) * .05; }
    void st;
  }
  dispose() {
    cancelAnimationFrame(this.raf); this.ro.disconnect(); this.sfx.alarm(false); this.sfx.drill(false); this.teardownWorld(); disposeChars(); this.composer?.dispose(); this.r.dispose(); this.pGeo.dispose(); this.pMat.dispose(); this.decalGeo.dispose(); this.decalMat.dispose();
    void WALLS; void COVER; void Math;
  }
}
