import { describe, it, expect } from 'vitest';
import * as R from './rules';
import * as V from './level';
import { NavGrid } from './nav';
describe('rules', () => {
  it('stance and weapon maths', () => {
    expect(R.nextStance('stand')).toBe('crouch'); expect(R.nextStance('prone')).toBe('stand');
    expect(R.STANCE.prone.speed).toBeLessThan(R.STANCE.crouch.speed); expect(R.STANCE.crouch.speed).toBeLessThan(R.STANCE.stand.speed);
    const w = R.WEAPONS.rifle; expect(R.hitDamage(w, 0, true)).toBeGreaterThan(R.hitDamage(w, 0, false)); expect(R.hitDamage(w, 200, false)).toBeGreaterThan(0); expect(R.hitDamage(w, 10, false)).toBeGreaterThan(R.hitDamage(w, 60, false));
    expect(R.spreadFor(w, 'prone', false, true, 0)).toBeLessThan(R.spreadFor(w, 'stand', true, false, 0));
    expect(R.WEAPONS.pistol.noise).toBeLessThan(R.WEAPONS.rifle.noise); expect(R.carrySlow(6)).toBeLessThan(R.carrySlow(0)); expect(R.carrySlow(99)).toBe(R.carrySlow(6));
    expect(R.detectRange('prone', false)).toBeLessThan(R.detectRange('stand', true)); expect(R.hitChance(5, 'prone', true)).toBeLessThan(R.hitChance(5, 'stand', false)); expect(R.hitChance(500, 'stand', false)).toBeGreaterThan(0);
  });
  it('objective chain', () => {
    const m = R.newMission(); expect(R.objective(m)).toBe('enter'); m.inside = true; expect(R.objective(m)).toBe('keycard'); m.keycard = true; expect(R.objective(m)).toBe('staff'); m.staffOpen = true; expect(R.objective(m)).toBe('drill');
    m.vaultOpen = true; expect(R.objective(m)).toBe('loot'); m.bags = 2; expect(R.objective(m)).toBe('escape'); m.extracted = true; expect(R.objective(m)).toBe('done');
  });
  it('payout, stars, police escalation', () => {
    expect(R.payout(3, 0, true)).toBe(120000); expect(R.payout(3, 0, false)).toBe(150000); expect(R.payout(0, 5, true)).toBe(0); expect(R.stars(6, false, 100)).toBe(3); expect(R.stars(1, true, 20)).toBe(1);
    expect(R.copsAllowed(5)).toBe(0); expect(R.copsAllowed(12)).toBe(2); expect(R.copsAllowed(40)).toBe(4); expect(R.copsAllowed(9999)).toBe(10); expect(R.fmtMoney(40000)).toBe('$40,000');
  });
});
describe('level and navigation', () => {
  const nav = V.buildNav(); const ok = (a: number[], b: number[]) => nav.findPath(a[0], a[1], b[0], b[1]).length > 0;
  it('every objective location is reachable on foot', () => {
    const S = [V.PLAYER_SPAWN.x, V.PLAYER_SPAWN.z];
    for (const [name, p] of [['front lobby', [0, 3]], ['manager', [V.MANAGER.x, V.MANAGER.z]], ['staff corridor', [0, -12]], ['vault', [0, -20]], ['security room', [10, -10]], ['van', [V.EXTRACT.x, V.EXTRACT.z]], ['alley west', [-22, -30]]] as const) expect(ok(S, [...p]), name).toBe(true);
    for (const l of V.LOOT) expect(ok(S, [l[0], l[1]]), `loot ${l}`).toBe(true);
    for (const g of V.GUARDS) { expect(nav.free(g.x, g.z), 'guard spawn free').toBe(true); for (const p of g.patrol) expect(nav.free(p[0], p[1])).toBe(true); }
    for (const c of V.COP_SPAWNS) expect(ok(S, [c[0], c[1]])).toBe(true);
  });
  it('walls really block and doors are in wall gaps', () => {
    expect(nav.free(0, 3)).toBe(true); expect(nav.free(-14, -10)).toBe(false); expect(nav.free(7, -8)).toBe(false); expect(nav.free(0.0, -8)).toBe(true);
    const direct = Math.hypot(V.EXTRACT.x - V.PLAYER_SPAWN.x, V.EXTRACT.z - V.PLAYER_SPAWN.z);
    const len = (p: [number, number][]) => p.slice(1).reduce((s, q, i) => s + Math.hypot(q[0] - p[i][0], q[1] - p[i][1]), 0);
    expect(len(nav.findPath(V.PLAYER_SPAWN.x, V.PLAYER_SPAWN.z, V.EXTRACT.x, V.EXTRACT.z))).toBeGreaterThan(direct);
    for (const d of V.DOORS) expect(nav.free(d.x, d.z), `door ${d.id} gap walkable`).toBe(true);
    expect(V.insideBank(0, 0)).toBe(true); expect(V.insideBank(0, 10)).toBe(false);
  });
  it('unreachable target returns empty path', () => { const g = new NavGrid(0, 0, 10, 10, [{ x: 5, z: 5, w: 20, d: .4 }], 0); expect(g.findPath(1, 1, 9, 9)).toEqual([]); });
});
