import * as THREE from 'three';
import { Stance } from './rules';
export interface Rig { g: THREE.Group; torso: THREE.Group; aU: THREE.Object3D[]; aL: THREE.Object3D[]; tU: THREE.Object3D[]; tL: THREE.Object3D[]; gun: THREE.Group | null; muzzle: THREE.Object3D | null; flash: THREE.Mesh | null }
export interface RigOpts { shirt: number; pants: number; vest?: number; helmet?: number; mask?: boolean; weapon: 'pistol' | 'rifle' | 'none'; skin?: number; hat?: number }
const mats = new Map<string, THREE.MeshStandardMaterial>(); const geos = new Map<string, THREE.BufferGeometry>();
const mat = (c: number, rough = .7, metal = 0) => { const k = `${c}:${rough}:${metal}`; let m = mats.get(k); if (!m) { m = new THREE.MeshStandardMaterial({ color: c, roughness: rough, metalness: metal }); mats.set(k, m); } return m; };
const cap = (r: number, l: number) => { const k = `c${r}:${l}`; let g = geos.get(k); if (!g) { g = new THREE.CapsuleGeometry(r, l, 4, 10); geos.set(k, g); } return g; };
const box = (() => { const g = new THREE.BoxGeometry(1, 1, 1); geos.set('box', g); return g; })(); const sph = (() => { const g = new THREE.SphereGeometry(.5, 14, 14); geos.set('sph', g); return g; })();
export const disposeChars = () => { geos.forEach(g => g.dispose()); mats.forEach(m => m.dispose()); };
const P = (par: THREE.Object3D, geo: THREE.BufferGeometry, m: THREE.Material, x: number, y: number, z: number, sx = 1, sy = 1, sz = 1) => { const o = new THREE.Mesh(geo, m); o.position.set(x, y, z); o.scale.set(sx, sy, sz); o.castShadow = true; par.add(o); return o; };
export function gunModel(kind: 'pistol' | 'rifle') {
  const g = new THREE.Group(), d = mat(0x1a1c20, .4, .8), d2 = mat(0x2b2e34, .5, .6);
  if (kind === 'rifle') { P(g, box, d, 0, 0, -.25, .07, .1, .55); P(g, box, d2, 0, .01, -.7, .035, .035, .4); P(g, box, d2, 0, -.02, .08, .06, .12, .22); P(g, box, d, 0, -.13, -.2, .05, .18, .08); P(g, box, d2, 0, .075, -.2, .04, .04, .14); P(g, box, d, 0, -.09, -.05, .05, .13, .05); }
  else { P(g, box, d, 0, 0, -.1, .05, .07, .22); P(g, box, d2, 0, -.09, .0, .05, .13, .06); P(g, new THREE.CylinderGeometry(.5, .5, 1, 10).rotateX(Math.PI / 2), d2, 0, .005, -.33, .04, .2, .04); }
  const muzzle = new THREE.Object3D(); muzzle.position.set(0, .01, kind === 'rifle' ? -.92 : -.45); g.add(muzzle);
  const flash = new THREE.Mesh(sph, new THREE.MeshBasicMaterial({ color: 0xffd080, transparent: true, opacity: .95, depthWrite: false })); flash.scale.setScalar(.14); flash.visible = false; muzzle.add(flash);
  return { g, muzzle, flash };
}
/** Original stylized tactical character built from rounded primitives. Faces -z. */
export function buildRig(o: RigOpts): Rig {
  const g = new THREE.Group(), torso = new THREE.Group(); g.add(torso); g.scale.setScalar(.9);
  const sm = mat(o.shirt, .85), pm = mat(o.pants, .9), sk = mat(o.skin ?? 0xe0b08a, .6), dk = mat(0x111111, .6), vest = o.vest ? mat(o.vest, .7) : null;
  P(torso, cap(.25, .16), sm, 0, .22, 0, 1.05, 1, .78); P(torso, cap(.23, .06), pm, 0, -.14, 0, 1, 1, .8); P(torso, box, dk, 0, -.01, 0, .5, .06, .4);
  if (vest) { P(torso, box, vest, 0, .26, -.02, .56, .5, .36); P(torso, box, mat(0x2a2a2a), 0, .18, -.2, .4, .16, .06); }
  P(torso, cap(.07, .04), sk, 0, .56, 0); const head = P(torso, sph, o.mask ? mat(0x181818, .9) : sk, 0, .8, 0, .4, .44, .42);
  if (o.mask) { P(torso, box, sk, 0, .83, -.19, .22, .05, .03); } else for (const sx of [-1, 1]) { P(torso, sph, mat(0xffffff), sx * .075, .83, -.17, .07, .08, .04); P(torso, sph, dk, sx * .075, .83, -.19, .035, .045, .02); }
  if (o.helmet !== undefined) { P(torso, sph, mat(o.helmet, .5), 0, .9, .01, .46, .34, .48); P(torso, box, mat(o.helmet, .5), 0, .87, -.2, .32, .03, .22); }
  if (o.hat !== undefined) { P(torso, sph, mat(o.hat, .9), 0, .9, .02, .43, .3, .46); P(torso, box, mat(o.hat, .9), 0, .87, -.2, .3, .03, .24); }
  const mk = (par: THREE.Object3D, geo: THREE.BufferGeometry, m: THREE.Material, len: number, x: number, y: number) => { const p = new THREE.Group(); p.position.set(x, y, 0); P(p, geo, m, 0, -len / 2, 0); par.add(p); return p; };
  const aU: THREE.Object3D[] = [], aL: THREE.Object3D[] = [], tU: THREE.Object3D[] = [], tL: THREE.Object3D[] = [];
  for (const sx of [-1, 1]) {
    const u = mk(torso, cap(.075, .2), sm, .35, sx * .33, .46); aU.push(u); const l = mk(u, cap(.065, .18), sm, .31, 0, -.35); aL.push(l); P(l, sph, mat(0x1a1a1a), 0, -.33, 0, .15, .15, .15);
    const th = mk(g, cap(.1, .2), pm, .4, sx * .13, -.28); tU.push(th); const sh = mk(th, cap(.085, .18), pm, .35, 0, -.4); tL.push(sh); P(sh, sph, mat(0x1c1c1c), 0, -.36, -.06, .26, .16, .44); P(sh, box, dk, 0, -.43, -.06, .22, .04, .38);
  }
  let gun: THREE.Group | null = null, muzzle: THREE.Object3D | null = null, flash: THREE.Mesh | null = null;
  if (o.weapon !== 'none') { const m = gunModel(o.weapon); gun = m.g; muzzle = m.muzzle; flash = m.flash; gun.position.set(.1, .3, -.32); torso.add(gun); }
  return { g, torso, aU, aL, tU, tL, gun, muzzle, flash };
}
export interface Pose { t: number; speed: number; stance: Stance; armed: boolean; dead: boolean; hands: boolean }
/** Positive x-rotation swings a hanging limb forward (toward -z). */
export function animate(r: Rig, p: Pose) {
  const ph = p.t * (4 + p.speed * 1.6), amp = Math.min(1, p.speed / 4) * .9, crouch = p.stance === 'crouch', prone = p.stance === 'prone';
  const base = (r.g.userData.base as number) || 0; r.g.rotation.set(0, r.g.rotation.y, 0); r.g.position.y = base;
  if (p.dead) { r.g.rotation.x = Math.PI / 2; r.g.position.y = .22; return; }
  if (prone) { r.g.rotation.x = -Math.PI / 2; r.g.position.y = .3; for (let i = 0; i < 2; i++) { r.tU[i].rotation.x = 0; r.tL[i].rotation.x = 0; r.aU[i].rotation.x = p.armed ? Math.PI / 2 : 0; r.aL[i].rotation.x = 0; } r.torso.rotation.x = 0; return; }
  for (let i = 0; i < 2; i++) {
    const s = Math.sin(ph + i * Math.PI);
    r.tU[i].rotation.x = crouch ? 1.15 : s * amp; r.tL[i].rotation.x = crouch ? -1.9 : -Math.max(0, -Math.cos(ph + i * Math.PI)) * 1.1 * amp;
    if (p.hands) { r.aU[i].rotation.x = 2.9; r.aL[i].rotation.x = -.3; } else if (p.armed) { r.aU[i].rotation.x = i ? 1.2 : 1.35; r.aL[i].rotation.x = i ? .5 : .15; } else { r.aU[i].rotation.x = -s * amp; r.aL[i].rotation.x = .5; }
  }
  r.torso.rotation.x = crouch ? -.3 : -.06; if (crouch) r.g.position.y = base - .42;
}
