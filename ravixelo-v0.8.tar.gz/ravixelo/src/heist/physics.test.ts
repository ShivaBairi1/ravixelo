import { describe, it, expect, beforeAll } from 'vitest';
import RAPIER from '@dimforge/rapier3d-compat';
import { COVER, WALLS } from './level';
beforeAll(async () => { await RAPIER.init(); });
function make() {
  const w = new RAPIER.World({ x: 0, y: -22, z: 0 }); w.timestep = 1 / 60;
  const fx = (x: number, y: number, z: number, hx: number, hy: number, hz: number) => { const b = w.createRigidBody(RAPIER.RigidBodyDesc.fixed().setTranslation(x, y, z)); w.createCollider(RAPIER.ColliderDesc.cuboid(hx, hy, hz), b); };
  fx(0, -.5, -5, 80, .5, 60); for (const r of WALLS) fx(r.x, 1.8, r.z, r.w / 2, 1.8, r.d / 2); for (const c of COVER.filter(c => c.mat !== 'car' && c.mat !== 'van')) fx(c.x, c.h / 2, c.z, c.w / 2, c.h / 2, c.d / 2);
  const body = w.createRigidBody(RAPIER.RigidBodyDesc.kinematicPositionBased().setTranslation(0, .9, 14)); const col = w.createCollider(RAPIER.ColliderDesc.capsule(.6, .3), body);
  const kcc = w.createCharacterController(.02); kcc.setUp({ x: 0, y: 1, z: 0 }); kcc.enableAutostep(.35, .2, false); kcc.enableSnapToGround(.25);
  const walk = (x: number, z: number, vx: number, vz: number, secs: number) => {
    body.setTranslation({ x, y: .9, z }, true); let vy = 0, grounded = false;
    for (let i = 0; i < secs * 60; i++) { vy = grounded ? -1 : vy - 22 / 60; kcc.computeColliderMovement(col, { x: vx / 60, y: vy / 60, z: vz / 60 }); const m = kcc.computedMovement(), t = body.translation(); grounded = kcc.computedGrounded(); body.setNextKinematicTranslation({ x: t.x + m.x, y: t.y + m.y, z: t.z + m.z }); w.step(); }
    return body.translation();
  };
  return { w, col, walk };
}
describe('character controller in the bank level', () => {
  it('walks through the front door gap and is stopped by the counter', () => { const { walk } = make(); const p = walk(0, 14, 0, -3.6, 8); expect(p.z).toBeGreaterThan(-4.05 + .3 - .05); expect(p.z).toBeLessThan(-3.0); expect(p.y).toBeGreaterThan(.8); expect(p.y).toBeLessThan(1.0); });
  it('cannot walk through a solid wall', () => { const { walk } = make(); const p = walk(7, 14, 0, -3.6, 6); expect(p.z).toBeGreaterThan(6.3); });
  it('goes around the counter and reaches the staff door gap', () => { const { walk } = make(); const a = walk(12, 2, 0, -3.6, 4); expect(a.z).toBeLessThan(-6); });
  it('climbs a small step but not a 1.1 m counter; settles on the floor', () => { const { walk } = make(); const p = walk(0, 0, 0, 0, 2); expect(p.y).toBeGreaterThan(.85); expect(p.y).toBeLessThan(.95); });
  it('bullet rays hit the counter and walls', () => { const { w, col } = make(); w.step(); const hit = w.castRayAndGetNormal(new RAPIER.Ray({ x: 0, y: .5, z: 12 }, { x: 0, y: 0, z: -1 }), 100, true, undefined, undefined, col); expect(hit).not.toBeNull(); expect(hit!.timeOfImpact).toBeGreaterThan(12.5); expect(hit!.timeOfImpact).toBeLessThan(17); const hi = w.castRay(new RAPIER.Ray({ x: 0, y: 1.8, z: 12 }, { x: 0, y: 0, z: -1 }), 100, true, undefined, undefined, col); expect(hi!.timeOfImpact).toBeGreaterThan(30); });
});
