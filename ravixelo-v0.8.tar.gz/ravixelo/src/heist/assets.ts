import * as THREE from 'three';
import { Sky } from 'three/examples/jsm/objects/Sky.js';
const cv = (w: number, h = w) => { const c = document.createElement('canvas'); c.width = w; c.height = h; return c; };
const tex = (c: HTMLCanvasElement, rx = 1, ry = 1, srgb = true) => { const t = new THREE.CanvasTexture(c); t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(rx, ry); t.anisotropy = 4; if (srgb) t.colorSpace = THREE.SRGBColorSpace; return t; };
function grain(rgb: [number, number, number], amt: number, size = 256, draw?: (g: CanvasRenderingContext2D) => void) {
  const c = cv(size), g = c.getContext('2d')!, im = g.createImageData(size, size);
  for (let i = 0; i < size * size; i++) { const n = (Math.random() - .5) * amt; im.data[i * 4] = rgb[0] + n; im.data[i * 4 + 1] = rgb[1] + n; im.data[i * 4 + 2] = rgb[2] + n; im.data[i * 4 + 3] = 255; }
  g.putImageData(im, 0, 0); draw?.(g); return c;
}
export function makeMaterials() {
  const P = (c: HTMLCanvasElement, rx: number, ry: number, rough: number, metal = 0, bump = .6) => new THREE.MeshStandardMaterial({ map: tex(c, rx, ry), bumpMap: tex(c, rx, ry, false), bumpScale: bump, roughness: rough, metalness: metal });
  const asphalt = grain([58, 60, 66], 46, 256, g => { g.fillStyle = 'rgba(0,0,0,.25)'; for (let i = 0; i < 90; i++) g.fillRect(Math.random() * 256, Math.random() * 256, 1 + Math.random() * 2, 1); });
  const concrete = grain([150, 150, 148], 36), side = grain([170, 168, 160], 30, 256, g => { g.strokeStyle = 'rgba(0,0,0,.35)'; g.lineWidth = 2; g.strokeRect(0, 0, 256, 256); });
  const paint = grain([226, 218, 200], 10), wood = grain([110, 70, 40], 30, 256, g => { g.strokeStyle = 'rgba(40,20,10,.35)'; for (let y = 0; y < 256; y += 8) { g.beginPath(); g.moveTo(0, y + Math.random() * 3); g.lineTo(256, y + Math.random() * 3); g.stroke(); } });
  const tile = grain([210, 206, 196], 14, 256, g => { g.fillStyle = 'rgba(60,60,70,.55)'; g.fillRect(0, 0, 128, 128); g.fillRect(128, 128, 128, 128); g.strokeStyle = 'rgba(0,0,0,.4)'; g.lineWidth = 3; g.strokeRect(0, 0, 256, 256); g.beginPath(); g.moveTo(128, 0); g.lineTo(128, 256); g.moveTo(0, 128); g.lineTo(256, 128); g.stroke(); });
  const carpet = grain([70, 40, 48], 40), brick = grain([150, 70, 52], 40, 256, g => { g.strokeStyle = 'rgba(210,200,190,.6)'; g.lineWidth = 3; for (let y = 0; y < 256; y += 32) { g.beginPath(); g.moveTo(0, y); g.lineTo(256, y); g.stroke(); for (let x = (y / 32) % 2 ? 0 : 32; x < 256; x += 64) { g.beginPath(); g.moveTo(x, y); g.lineTo(x, y + 32); g.stroke(); } } });
  const steel = grain([120, 124, 130], 30, 256, g => { g.strokeStyle = 'rgba(0,0,0,.3)'; for (let y = 0; y < 256; y += 4) { g.beginPath(); g.moveTo(0, y); g.lineTo(256, y); g.stroke(); } });
  const win = (lit: number) => grain([14, 18, 30], 6, 128, g => { for (let y = 6; y < 128; y += 16) for (let x = 6; x < 128; x += 16) { g.fillStyle = Math.random() < lit ? 'rgb(255,214,140)' : 'rgb(30,44,70)'; g.fillRect(x, y, 9, 10); } });
  const M = {
    asphalt: P(asphalt, 14, 3, .95), sidewalk: P(side, 40, 4, .9), concrete: P(concrete, 4, 4, .9), wall: P(paint, 3, 1.5, .85, 0, .15), tile: P(tile, 12, 8, .25, 0, .1), carpet: P(carpet, 3, 3, 1, 0, .8),
    wood: P(wood, 1, 1, .5, 0, .4), brick: P(brick, 10, 2, .9), steel: P(steel, 2, 2, .35, .8, .3), grass: P(grain([60, 92, 52], 40), 60, 60, 1, 0, 1),
    glass: new THREE.MeshPhysicalMaterial({ color: 0x9fc4d6, roughness: .05, metalness: 0, transparent: true, opacity: .28, side: THREE.DoubleSide }),
    car: [0xb02020, 0x2b4a8a, 0xc8c8c8, 0x222222].map(c => new THREE.MeshPhysicalMaterial({ color: c, roughness: .3, metalness: .6, clearcoat: 1, clearcoatRoughness: .1 })),
    van: new THREE.MeshStandardMaterial({ color: 0xe8e8e8, roughness: .5, metalness: .3 }), crate: P(wood, 1, 1, .7, 0, .3), fabric: new THREE.MeshStandardMaterial({ color: 0x3a4a6a, roughness: 1 }),
    cash: new THREE.MeshStandardMaterial({ color: 0x3f8f4a, roughness: .8 }), band: new THREE.MeshStandardMaterial({ color: 0xf2e6b0, roughness: .7 }), dark: new THREE.MeshStandardMaterial({ color: 0x15171c, roughness: .6, metalness: .5 }),
    emis: new THREE.MeshStandardMaterial({ color: 0xffffff, emissive: 0xfff2d0, emissiveIntensity: 2 }), screen: new THREE.MeshStandardMaterial({ color: 0x112233, emissive: 0x2288ff, emissiveIntensity: 1.2 }),
    sky: [win(.25), win(.4), win(.15)].map((c, i) => { const t = tex(c, 1 + i, 4 + i * 2); return new THREE.MeshStandardMaterial({ map: t, emissiveMap: t, emissive: 0xffffff, emissiveIntensity: .5, roughness: .8 }); }),
    leaf: new THREE.MeshStandardMaterial({ color: 0x2f6a3a, roughness: 1 }), trunk: new THREE.MeshStandardMaterial({ color: 0x4a3524, roughness: 1 }),
  };
  return M;
}
export type Mats = ReturnType<typeof makeMaterials>;
export function makeSky(renderer: THREE.WebGLRenderer, scene: THREE.Scene) {
  const sky = new Sky(); sky.scale.setScalar(2000); const u = sky.material.uniforms; u.turbidity.value = 5; u.rayleigh.value = 1.4; u.mieCoefficient.value = .004; u.mieDirectionalG.value = .85;
  const sun = new THREE.Vector3().setFromSphericalCoords(1, THREE.MathUtils.degToRad(58), THREE.MathUtils.degToRad(150)); u.sunPosition.value.copy(sun);
  scene.add(sky);
  const pm = new THREE.PMREMGenerator(renderer), es = new THREE.Scene(); const s2 = new Sky(); s2.scale.setScalar(2000); Object.keys(u).forEach(k => { s2.material.uniforms[k].value = u[k].value; }); es.add(s2);
  scene.environment = pm.fromScene(es).texture; scene.environmentIntensity = .55; pm.dispose();
  return sun;
}
export function signTexture(text: string) {
  const c = cv(512, 96), g = c.getContext('2d')!; g.fillStyle = '#10243a'; g.fillRect(0, 0, 512, 96); g.fillStyle = '#d9b44a'; g.font = 'bold 46px Georgia, serif'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(text, 256, 50); g.strokeStyle = '#d9b44a'; g.lineWidth = 4; g.strokeRect(6, 6, 500, 84);
  return tex(c);
}
export function drawingTexture(lines: number) { const c = cv(256, 128), g = c.getContext('2d')!; g.fillStyle = '#556'; g.fillRect(0, 0, 256, 128); g.strokeStyle = '#223'; g.lineWidth = 2; for (let i = 0; i < lines; i++) { g.strokeRect(4 + (i % 8) * 31, 6 + Math.floor(i / 8) * 20, 28, 17); } return tex(c); }
