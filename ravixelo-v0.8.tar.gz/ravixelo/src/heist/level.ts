// Fictional bank "Meridian Trust" (original layout, not based on any real building). Units: metres. -z is "north/deeper into the bank".
import { NavGrid, Rect } from './nav';
export const BOUNDS = { minX: -40, maxX: 40, minZ: -36, maxZ: 26 };
export const BANK = { minX: -14, maxX: 14, minZ: -24, maxZ: 6, h: 3.6 };
const T = .3;
const seg = (x1: number, z1: number, x2: number, z2: number): Rect => (x1 === x2 ? { x: x1, z: (z1 + z2) / 2, w: T, d: Math.abs(z2 - z1) } : { x: (x1 + x2) / 2, z: z1, w: Math.abs(x2 - x1), d: T });
export const WALLS: Rect[] = [
  seg(-14, 6, -1.5, 6), seg(1.5, 6, 14, 6), seg(-14, -24, 11, -24), seg(13, -24, 14, -24), seg(-14, -24, -14, 6), seg(14, -24, 14, 6),
  seg(-14, -8, -12, -8), seg(-10.5, -8, -1, -8), seg(1, -8, 14, -8), seg(-6, -16, -6, -8), seg(-14, -16, -1.5, -16), seg(1.5, -16, 14, -16),
  seg(6, -16, 6, -14), seg(6, -12, 6, -8), seg(10, -24, 10, -20), seg(10, -18, 10, -16),
];
export interface DoorDef { id: string; x: number; z: number; w: number; along: 'x' | 'z'; kind: 'auto' | 'hinged' | 'locked' | 'vault' }
export const DOORS: DoorDef[] = [
  { id: 'front', x: 0, z: 6, w: 3, along: 'x', kind: 'auto' }, { id: 'office', x: -11.25, z: -8, w: 1.5, along: 'x', kind: 'hinged' },
  { id: 'staff', x: 0, z: -8, w: 2, along: 'x', kind: 'locked' }, { id: 'security', x: 6, z: -13, w: 2, along: 'z', kind: 'hinged' },
  { id: 'vault', x: 0, z: -16, w: 3, along: 'x', kind: 'vault' }, { id: 'loading', x: 10, z: -19, w: 2, along: 'z', kind: 'hinged' },
  { id: 'rear', x: 12, z: -24, w: 2, along: 'x', kind: 'hinged' },
];
export type Mat = 'wood' | 'metal' | 'fabric' | 'car' | 'crate' | 'concrete' | 'van';
export interface Solid extends Rect { h: number; mat: Mat; y?: number }
export const COVER: Solid[] = [
  { x: 0, z: -4.5, w: 18, d: .9, h: 1.1, mat: 'wood' }, { x: -10, z: 1, w: 2.2, d: 1, h: .8, mat: 'wood' }, { x: 10, z: 1, w: 2.2, d: 1, h: .8, mat: 'wood' },
  { x: -5, z: -1, w: .8, d: .8, h: 3.6, mat: 'concrete' }, { x: 5, z: -1, w: .8, d: .8, h: 3.6, mat: 'concrete' }, { x: -11, z: 3.6, w: 3, d: .9, h: .9, mat: 'fabric' }, { x: 11, z: 3.6, w: 3, d: .9, h: .9, mat: 'fabric' },
  { x: 10, z: -12, w: 3, d: 1, h: .9, mat: 'wood' }, { x: 13.4, z: -10, w: .8, d: 3, h: 2.2, mat: 'metal' }, { x: -10, z: -12, w: 2.4, d: 1.1, h: .9, mat: 'wood' },
  ...[-8, -5, -2, 1, 4, 7].map(x => ({ x, z: -22, w: 2, d: 1.2, h: .7, mat: 'crate' as Mat })),
  { x: -12, z: -19, w: 1.6, d: 1.6, h: .7, mat: 'crate' },
  { x: -4, z: -19, w: 1.5, d: 1.5, h: 1.2, mat: 'crate' }, { x: 4, z: -19, w: 1.5, d: 1.5, h: 1.2, mat: 'crate' },
  { x: -12, z: 17, w: 4.4, d: 1.9, h: 1.5, mat: 'car' }, { x: 14, z: 19, w: 4.4, d: 1.9, h: 1.5, mat: 'car' }, { x: -26, z: 14, w: 4.4, d: 1.9, h: 1.5, mat: 'car' }, { x: 24, z: 15, w: 4.4, d: 1.9, h: 1.5, mat: 'car' },
  { x: 10, z: -29.5, w: 5.4, d: 2.2, h: 2.3, mat: 'van' }, { x: -16, z: -30, w: 3, d: 2, h: 1.2, mat: 'crate' },
];
export const LOOT: [number, number][] = [[-8, -22], [-5, -22], [-2, -22], [1, -22], [4, -22], [7, -22], [-12, -19], [8.5, -17.5]];
export const LIGHTS: [number, number][] = [[-7, 0], [7, 0], [0, -6], [0, -12], [-10, -12], [10, -12], [0, -20]];
export const GUARDS = [
  { x: -6, z: 2, patrol: [[-6, 2], [6, 2], [6, -2], [-7, -2.5]] }, { x: 8, z: 4, patrol: [[8, 4], [-8, 4]] },
  { x: 9, z: -10, patrol: [[9, -10], [12, -11]] }, { x: 12, z: -14, patrol: [[12, -14], [8, -14]] },
] as { x: number; z: number; patrol: [number, number][] }[];
export const CIVS: { x: number; z: number; role: 'customer' | 'teller' }[] = [
  { x: -3, z: 1.5, role: 'customer' }, { x: 3, z: 3.5, role: 'customer' }, { x: -9, z: 3, role: 'customer' }, { x: 7, z: -2, role: 'customer' }, { x: -4, z: -6, role: 'teller' }, { x: 4, z: -6, role: 'teller' },
];
export const MANAGER = { x: -10, z: -10.5 };
export const PLAYER_SPAWN = { x: -6, z: 14, yaw: 0 };
export const EXTRACT = { x: 10, z: -26, r: 3.5 };
export const COP_SPAWNS: [number, number][] = [[-22, 18], [22, 18], [0, 24], [-22, -30], [22, -30]];
export const insideBank = (x: number, z: number) => x > BANK.minX && x < BANK.maxX && z > BANK.minZ && z < BANK.maxZ;
export const navRects = (): Rect[] => [...WALLS, ...COVER.filter(c => c.mat !== 'metal' || c.h > 2)];
export const buildNav = () => new NavGrid(BOUNDS.minX, BOUNDS.minZ, BOUNDS.maxX, BOUNDS.maxZ, navRects());
