/** Tiny procedural sound engine (no audio files). Created lazily after a user gesture. */
export class Sfx {
  private ctx?: AudioContext; private nb?: AudioBuffer; muted = false; private alarmId = 0; private drillOsc?: OscillatorNode; private drillG?: GainNode;
  init() { if (this.ctx) return; try { this.ctx = new AudioContext(); const n = this.ctx.sampleRate; this.nb = this.ctx.createBuffer(1, n, n); const d = this.nb.getChannelData(0); for (let i = 0; i < n; i++) d[i] = Math.random() * 2 - 1; } catch { /* no audio */ } }
  private noise(dur: number, vol: number, f: number, q = .7, delay = 0) { const c = this.ctx; if (!c || !this.nb || this.muted) return; const s = c.createBufferSource(), fl = c.createBiquadFilter(), g = c.createGain(); s.buffer = this.nb; fl.type = 'lowpass'; fl.frequency.value = f; fl.Q.value = q; const t = c.currentTime + delay; g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(.001, t + dur); s.connect(fl).connect(g).connect(c.destination); s.start(t, Math.random() * .5); s.stop(t + dur); }
  private tone(f: number, dur: number, vol: number, type: OscillatorType = 'sine', delay = 0, f2?: number) { const c = this.ctx; if (!c || this.muted) return; const o = c.createOscillator(), g = c.createGain(), t = c.currentTime + delay; o.type = type; o.frequency.setValueAtTime(f, t); if (f2) o.frequency.exponentialRampToValueAtTime(f2, t + dur); g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(.001, t + dur); o.connect(g).connect(c.destination); o.start(t); o.stop(t + dur); }
  shot(loud: boolean) { if (loud) { this.noise(.28, .5, 3500); this.tone(120, .2, .5, 'sine', 0, 40); } else { this.noise(.1, .16, 1800); this.tone(300, .06, .1, 'square', 0, 150); } }
  enemyShot() { this.noise(.2, .22, 2600); }
  reload() { this.tone(900, .04, .1, 'square'); this.tone(600, .05, .1, 'square', .45); this.tone(1100, .04, .12, 'square', 1.0); }
  hit() { this.tone(1400, .05, .12, 'triangle'); } pain() { this.noise(.15, .3, 500); this.tone(90, .2, .3, 'sawtooth', 0, 50); }
  pick() { this.tone(660, .08, .12, 'triangle'); this.tone(990, .1, .12, 'triangle', .08); } door() { this.noise(.25, .18, 700); } step() { this.noise(.06, .07, 500); } empty() { this.tone(500, .03, .1, 'square'); }
  alarm(on: boolean) { clearInterval(this.alarmId); if (!on) return; let k = 0; this.alarmId = window.setInterval(() => { this.tone(k++ % 2 ? 760 : 980, .38, .09, 'square'); }, 420); }
  drill(on: boolean) {
    const c = this.ctx; if (!c) return; if (on && !this.drillOsc && !this.muted) { this.drillOsc = c.createOscillator(); this.drillG = c.createGain(); this.drillOsc.type = 'sawtooth'; this.drillOsc.frequency.value = 62; this.drillG.gain.value = .07; this.drillOsc.connect(this.drillG).connect(c.destination); this.drillOsc.start(); }
    if (!on && this.drillOsc) { this.drillOsc.stop(); this.drillOsc = undefined; }
  }
  /** Freeze all sound (pause / app in background) and unfreeze it again. */
  suspend() { void this.ctx?.suspend().catch(() => undefined); } wake() { void this.ctx?.resume().catch(() => undefined); }
  win() { [523, 659, 784, 1046].forEach((f, i) => this.tone(f, .25, .15, 'triangle', i * .12)); } lose() { this.tone(220, .8, .2, 'sawtooth', 0, 55); }
}
