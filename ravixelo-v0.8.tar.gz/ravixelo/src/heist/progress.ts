// Persistent progress for the heist mode. Pure functions + a storage-like interface so they can be unit-tested without a browser.
import { clampLoadout, Difficulty, isDifficulty, Loadout, nextCost, noUpgrades, UpgradeId } from './rules';

export type Gfx = 'auto' | 'high' | 'low';
export interface Save {
  sens: number; sound: boolean; haptics: boolean; gfx: Gfx; difficulty: Difficulty;
  best: number;      // best single payout
  wallet: number;    // spendable cash
  earned: number;    // lifetime cash earned
  heists: number; wins: number; silentWins: number;
  upgrades: Loadout;
}
type KV = Pick<Storage, 'getItem' | 'setItem'>;
const KEY = 'ravixelo.heist.v2', OLD_KEY = 'ravixelo.heist.v1';
export const MAX_WALLET = 99_999_999;

export const defaultSave = (): Save => ({ sens: 1, sound: true, haptics: true, gfx: 'auto', difficulty: 'pro', best: 0, wallet: 0, earned: 0, heists: 0, wins: 0, silentWins: 0, upgrades: noUpgrades() });
const nn = (x: unknown, hi = MAX_WALLET) => (typeof x === 'number' && Number.isFinite(x) && x >= 0 ? Math.min(hi, Math.floor(x)) : null);

/** Reads and validates a save. Anything corrupted falls back to defaults; the old v1 key is migrated once. */
export function loadSave(s: Pick<Storage, 'getItem'>): Save {
  const d = defaultSave();
  const read = (k: string) => { try { const o = JSON.parse(s.getItem(k) ?? 'null'); return o && typeof o === 'object' && !Array.isArray(o) ? (o as Record<string, unknown>) : null; } catch { return null; } };
  const o = read(KEY) ?? read(OLD_KEY); if (!o) return d;
  if (typeof o.sens === 'number' && Number.isFinite(o.sens) && o.sens >= .3 && o.sens <= 3) d.sens = o.sens;
  if (typeof o.sound === 'boolean') d.sound = o.sound;
  if (typeof o.haptics === 'boolean') d.haptics = o.haptics;
  if (o.gfx === 'high' || o.gfx === 'low') d.gfx = o.gfx;
  if (isDifficulty(o.difficulty)) d.difficulty = o.difficulty;
  d.best = nn(o.best) ?? 0; d.wallet = nn(o.wallet) ?? 0; d.earned = nn(o.earned) ?? 0;
  d.heists = nn(o.heists, 1e9) ?? 0; d.wins = nn(o.wins, 1e9) ?? 0; d.silentWins = nn(o.silentWins, 1e9) ?? 0;
  if (o.upgrades && typeof o.upgrades === 'object') d.upgrades = clampLoadout(o.upgrades as Record<string, unknown>);
  return d;
}
export function writeSave(s: KV, v: Save) { try { s.setItem(KEY, JSON.stringify(v)); } catch { /* quota / private mode */ } }

/** Tries to buy the next level of an upgrade. Returns the new save, or null if maxed or too expensive. */
export function buyUpgrade(v: Save, id: UpgradeId): Save | null {
  const cost = nextCost(v.upgrades, id); if (cost === null || v.wallet < cost) return null;
  return { ...v, wallet: v.wallet - cost, upgrades: { ...v.upgrades, [id]: v.upgrades[id] + 1 } };
}
/** Adds cash to the wallet (never negative, capped). */
export const addCash = (v: Save, amount: number): Save => {
  const a = Math.max(0, Math.floor(amount)); return a === 0 ? v : { ...v, wallet: Math.min(MAX_WALLET, v.wallet + a), earned: Math.min(MAX_WALLET, v.earned + a) };
};
/** Records a finished heist. `payout` raises the personal best only for wins. */
export const recordRun = (v: Save, r: { win: boolean; payout: number; alarmed: boolean }): Save => ({
  ...v, heists: v.heists + 1, wins: v.wins + (r.win ? 1 : 0), silentWins: v.silentWins + (r.win && !r.alarmed ? 1 : 0), best: r.win ? Math.max(v.best, r.payout) : v.best,
});
