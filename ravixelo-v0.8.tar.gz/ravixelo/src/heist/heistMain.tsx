import { StrictMode, useEffect, useRef, useState } from 'react';
import type { CSSProperties, PointerEvent as RPointerEvent } from 'react';
import { createRoot } from 'react-dom/client';
import { HeistGame, HeistHud, HeistResult, HState } from './HeistGame';
import * as RL from './rules';
import { fmtMoney } from './rules';
import { addCash, buyUpgrade, Gfx, loadSave, recordRun, Save, writeSave } from './progress';
import { ads } from '../ads';
import { Ad } from '../Ad';
import { isNative } from '../platform';
import { PRIVACY_URL } from '../config';

const ZERO: HeistHud = { hp: 100, maxHp: 100, hm: 0, weapon: '', mag: 0, reserve: 0, reloading: false, stance: 'stand', obj: '', objDist: 0, prompt: '', progress: 0, bags: 0, alarm: false, eta: -1, cops: 0, hit: 0, aim: false, msg: '', mission: RL.newMission(), fps: 0 };
const coarse = matchMedia('(pointer:coarse)').matches;
const native = isNative();

/** Touch button. Defined OUTSIDE App on purpose: a component declared inside App is a new type on every render (the HUD re-renders ~12x/s),
 *  which made React destroy and re-create every button mid-press and could leave FIRE stuck on. */
function Btn({ label, on, off, style }: { label: string; on: () => void; off?: () => void; style?: CSSProperties }) {
  return <button className="tb" style={style} aria-label={label}
    onPointerDown={e => { e.stopPropagation(); e.preventDefault(); try { e.currentTarget.setPointerCapture(e.pointerId); } catch { /* ignore */ } on(); }}
    onPointerUp={e => { e.stopPropagation(); off?.(); }} onPointerCancel={() => off?.()} onLostPointerCapture={() => off?.()} onContextMenu={e => e.preventDefault()}>{label}</button>;
}

function App() {
  const cv = useRef<HTMLCanvasElement>(null), mini = useRef<HTMLCanvasElement>(null), g = useRef<HeistGame | null>(null), keys = useRef(new Set<string>());
  const [st, setSt] = useState<HState>('ready'), [hud, setHud] = useState(ZERO), [res, setRes] = useState<HeistResult | null>(null), [err, setErr] = useState('');
  const [save, setSave] = useState<Save>(() => loadSave(localStorage)), saveRef = useRef(save); saveRef.current = save;
  const [shop, setShop] = useState(false), [privacy, setPrivacy] = useState(false), [busy, setBusy] = useState(''), [note, setNote] = useState(''), [, setTick] = useState(0);
  const stRef = useRef(st); stRef.current = st; const shopRef = useRef(shop); shopRef.current = shop; const privRef = useRef(privacy); privRef.current = privacy;
  const paid = useRef(0), doubled = useRef(false), pending = useRef<HeistResult | null>(null), leaving = useRef(false), back = useRef<() => void>(() => {});

  const persist = (n: Save) => { saveRef.current = n; setSave(n); writeSave(localStorage, n); };
  const applyPrefs = (p: Save) => { const x = g.current; if (!x) return; x.sens = .0022 * p.sens; x.sfx.muted = !p.sound; x.haptics = p.haptics; x.setDifficulty(p.difficulty); };
  const change = (patch: Partial<Save>) => { const n = { ...saveRef.current, ...patch }; persist(n); applyPrefs(n); };
  const lock = () => { if (!coarse) void cv.current?.requestPointerLock?.(); };

  /** Called when a heist ends. Cash is paid once per run even if the player continues after a rewarded ad. */
  const onResult = (r: HeistResult) => {
    setRes(r); setNote('');
    const reward = RL.walletReward(r.win, r.payout, r.kills), delta = Math.max(0, reward - paid.current); paid.current = Math.max(paid.current, reward);
    let n = addCash(saveRef.current, delta);
    if (r.win || !r.canRevive) { n = recordRun(n, r); pending.current = null; } else pending.current = r; // a loss that can still be revived is recorded when the player moves on
    persist(n);
  };
  const flushPending = () => { const p = pending.current; if (p) { pending.current = null; persist(recordRun(saveRef.current, p)); } };

  useEffect(() => {
    let dead = false, game: HeistGame | null = null; const K = keys.current; void ads.init().then(() => { if (!dead) setTick(t => t + 1); });
    const move = () => g.current?.setMove((K.has('KeyD') ? 1 : 0) - (K.has('KeyA') ? 1 : 0), (K.has('KeyW') ? 1 : 0) - (K.has('KeyS') ? 1 : 0));
    const kd = (e: KeyboardEvent) => {
      const x = g.current; if (!x || x.state !== 'playing') return; K.add(e.code); const c = e.code;
      if (['KeyW', 'KeyA', 'KeyS', 'KeyD'].includes(c)) move(); else if (c === 'ShiftLeft' || c === 'ShiftRight') x.setSprint(true); else if (c === 'Space') { x.press('jump'); e.preventDefault(); } else if (c === 'KeyC') x.press('crouch'); else if (c === 'KeyZ') x.press('prone');
      else if (c === 'KeyR') x.press('reload'); else if (c === 'KeyE') x.setInteract(true); else if (c === 'KeyV') x.press('view'); else if (c === 'Digit1') x.press('rifle'); else if (c === 'Digit2') x.press('pistol'); else if (c === 'KeyQ') x.press('swap'); else if (c === 'KeyP') x.pause();
    };
    const ku = (e: KeyboardEvent) => { K.delete(e.code); if (['KeyW', 'KeyA', 'KeyS', 'KeyD'].includes(e.code)) move(); if (e.code.startsWith('Shift')) g.current?.setSprint(false); if (e.code === 'KeyE') g.current?.setInteract(false); };
    const mm = (e: MouseEvent) => { if (document.pointerLockElement === cv.current) g.current?.look(e.movementX, e.movementY); };
    const md = (e: MouseEvent) => { if (document.pointerLockElement !== cv.current) return; if (e.button === 0) g.current?.setFire(true); if (e.button === 2) g.current?.setAim(true); };
    const mu = (e: MouseEvent) => { if (e.button === 0) g.current?.setFire(false); if (e.button === 2) g.current?.setAim(false); };
    const pl = () => { if (!document.pointerLockElement && g.current?.state === 'playing' && !coarse) g.current.pause(); };
    const blur = () => { K.clear(); g.current?.setMove(0, 0); g.current?.setFire(false); g.current?.setInteract(false); };
    const away = () => { blur(); g.current?.pause(); }; // phone call, home button, tab switch: never keep playing (or sounding the alarm) in the background
    const hidden = () => { if (document.hidden) away(); };
    const nativeBack = () => back.current();
    const cm = (e: Event) => e.preventDefault(); const canvas = cv.current!;
    HeistGame.create(canvas, { onHud: setHud, onState: setSt, onResult }, saveRef.current.gfx === 'auto' ? undefined : saveRef.current.gfx)
      .then(x => { if (dead) { x.dispose(); return; } game = x; g.current = x; applyPrefs(saveRef.current); x.setLoadout(saveRef.current.upgrades); x.setMinimap(mini.current); }).catch(e => setErr(String(e)));
    addEventListener('keydown', kd); addEventListener('keyup', ku); addEventListener('mousemove', mm); addEventListener('mousedown', md); addEventListener('mouseup', mu); addEventListener('blur', blur); addEventListener('pagehide', away); addEventListener('ravixelo:back', nativeBack);
    document.addEventListener('pointerlockchange', pl); document.addEventListener('visibilitychange', hidden); canvas.addEventListener('contextmenu', cm);
    return () => {
      dead = true; removeEventListener('keydown', kd); removeEventListener('keyup', ku); removeEventListener('mousemove', mm); removeEventListener('mousedown', md); removeEventListener('mouseup', mu); removeEventListener('blur', blur); removeEventListener('pagehide', away); removeEventListener('ravixelo:back', nativeBack);
      document.removeEventListener('pointerlockchange', pl); document.removeEventListener('visibilitychange', hidden); canvas.removeEventListener('contextmenu', cm); game?.dispose(); g.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [save.gfx]);

  // Banner ads only on menu / result screens (never while playing or paused).
  const bannerScreen = (st === 'ready' && !shop && !privacy) || st === 'over';
  useEffect(() => { if (bannerScreen) void ads.showBanner(); else void ads.hideBanner(); }, [bannerScreen]);

  const newRun = () => { paid.current = 0; doubled.current = false; pending.current = null; setNote(''); setRes(null); };
  const play = () => { newRun(); g.current?.start(); lock(); };
  /** Leaving a finished heist is the natural break where an interstitial may show (paced by adPolicy.ts). */
  const leave = async (go: () => void) => { if (leaving.current) return; leaving.current = true; try { flushPending(); await ads.afterRun(saveRef.current.heists); } finally { leaving.current = false; } go(); };
  const restart = () => void leave(() => { newRun(); g.current?.restart(); lock(); });
  const restartNow = () => { flushPending(); newRun(); g.current?.restart(); lock(); }; // from the pause menu: no ad
  const menu = () => void leave(() => { newRun(); g.current?.toMenu(); setSt('ready'); });
  const resume = () => { g.current?.resume(); lock(); };
  const quitToMenu = () => { flushPending(); newRun(); g.current?.toMenu(); setSt('ready'); };

  const watchContinue = async () => {
    if (busy) return; setBusy('Loading ad...'); const ok = await ads.showRewarded(); setBusy('');
    if (ok && g.current?.revive()) { pending.current = null; setRes(null); lock(); } else setNote('No reward: the ad was not completed or is unavailable.');
  };
  const watchDouble = async () => {
    if (busy || doubled.current || !res?.win) return; setBusy('Loading ad...'); const ok = await ads.showRewarded(); setBusy('');
    if (ok && !doubled.current) { doubled.current = true; persist(addCash(saveRef.current, res.payout)); setNote(`Bonus +${fmtMoney(res.payout)} added!`); } else if (!ok) setNote('No reward: the ad was not completed or is unavailable.');
  };
  const buy = (id: RL.UpgradeId) => { const n = buyUpgrade(saveRef.current, id); if (!n) return; persist(n); g.current?.setLoadout(n.upgrades); };

  // Android back button / Esc handling: pause, resume, close panels, go to the menu, and only then leave the app.
  back.current = () => {
    if (privRef.current) setPrivacy(false); else if (shopRef.current) setShop(false);
    else if (stRef.current === 'playing') g.current?.pause(); else if (stRef.current === 'paused') resume(); else if (stRef.current === 'over') quitToMenu(); else ads.exitApp();
  };

  // ---- touch controls
  const joy = useRef<{ id: number; x: number; y: number } | null>(null), lk = useRef<{ id: number; x: number; y: number } | null>(null); const [knob, setKnob] = useState<[number, number]>([0, 0]);
  const jd = (e: RPointerEvent) => { (e.currentTarget as Element).setPointerCapture(e.pointerId); joy.current = { id: e.pointerId, x: e.clientX, y: e.clientY }; };
  const jm = (e: RPointerEvent) => { const j = joy.current; if (!j || j.id !== e.pointerId) return; let dx = e.clientX - j.x, dy = e.clientY - j.y; const l = Math.hypot(dx, dy), R = 55; if (l > R) { dx = dx / l * R; dy = dy / l * R; } setKnob([dx, dy]); g.current?.setMove(dx / R, -dy / R); g.current?.setSprint(dy / R < -.9); };
  const ju = () => { joy.current = null; setKnob([0, 0]); g.current?.setMove(0, 0); g.current?.setSprint(false); };
  const ld = (e: RPointerEvent) => { (e.currentTarget as Element).setPointerCapture(e.pointerId); lk.current = { id: e.pointerId, x: e.clientX, y: e.clientY }; };
  const lm = (e: RPointerEvent) => { const l = lk.current; if (!l || l.id !== e.pointerId) return; g.current?.look((e.clientX - l.x) * 1.8, (e.clientY - l.y) * 1.8); l.x = e.clientX; l.y = e.clientY; };
  const lu = () => { lk.current = null; };

  const p = hud, low = p.hp < p.maxHp * .35, D = RL.DIFFICULTY[save.difficulty];
  const privacyLink = native ? PRIVACY_URL : (PRIVACY_URL || '/privacy.html');
  return <>
    <div id="stage"><canvas ref={cv} onClick={() => { if (st === 'playing') lock(); }} /></div>
    {st === 'playing' && <>
      <div className="vig" style={{ opacity: Math.min(1, p.hit * .8 + (low ? .35 : 0)), boxShadow: 'inset 0 0 140px 40px #c00' }} />
      <div className="xh" style={{ opacity: p.aim ? .5 : 1 }} />{p.hm > 0 && <div className="hm" style={{ color: p.hm === 2 ? '#ff4a4a' : '#fff' }} />}
      <canvas ref={mini} width={150} height={150} className="mini" />
      <div className="top"><div><b>{p.obj}</b><br />{p.objDist} m{p.bags > 0 ? ` · ${p.bags} bags (${fmtMoney(p.bags * RL.BAG_VALUE)})` : ''}</div>{p.alarm && <div className="alarm">ALARM {p.eta > 0 ? `· police in ${p.eta}s` : `· ${p.cops} cops`}</div>}</div>
      {p.msg && <div className="toast" aria-live="polite">{p.msg}</div>}
      {p.prompt && <div className="prompt">{p.prompt}{p.progress > 0 && <div className="bar"><i style={{ width: `${p.progress * 100}%` }} /></div>}</div>}
      <div className="bl"><div className="hp"><i style={{ width: `${Math.min(100, p.hp / p.maxHp * 100)}%`, background: low ? '#e33' : '#4c8' }} /></div><small>{p.stance.toUpperCase()}{coarse ? '' : ' · C crouch · Z prone'}</small></div>
      <div className="br"><b style={{ fontSize: 28 }}>{p.reloading ? '...' : p.mag}</b> / {p.reserve}<br /><small>{p.weapon}</small></div>
      {coarse && <>
        <div className="look" onPointerDown={ld} onPointerMove={lm} onPointerUp={lu} onPointerCancel={lu} />
        <div className="joy" onPointerDown={jd} onPointerMove={jm} onPointerUp={ju} onPointerCancel={ju}><i style={{ transform: `translate(${knob[0]}px,${knob[1]}px)` }} /></div>
        <div className="tbs">
          <Btn label="FIRE" on={() => g.current?.setFire(true)} off={() => g.current?.setFire(false)} style={{ width: 84, height: 84, background: '#c33' }} />
          <Btn label="AIM" on={() => g.current?.setAim(true)} off={() => g.current?.setAim(false)} /><Btn label="JUMP" on={() => g.current?.press('jump')} /><Btn label="STANCE" on={() => g.current?.press('cycle')} /><Btn label="RELOAD" on={() => g.current?.press('reload')} />
          <Btn label="USE" on={() => g.current?.setInteract(true)} off={() => g.current?.setInteract(false)} /><Btn label="SWAP" on={() => g.current?.press('swap')} /><Btn label="VIEW" on={() => g.current?.press('view')} /><Btn label="II" on={() => g.current?.pause()} />
        </div></>}
    </>}
    {err && <div className="ov"><h2>Could not start</h2><p>{err}</p></div>}
    {st === 'ready' && !err && !shop && !privacy && <div className="ov"><h1>RAVIXELO: HEIST</h1>
      <p>Meridian Trust Bank holds a fortune and a lazy security system. Get inside, persuade the manager to hand over the keycard, drill the vault, grab the cash and reach the getaway van. Stay quiet and the alarm may never ring. Start shooting and the police will come.</p>
      <p className="hint">{coarse ? 'Left stick: move (push forward to sprint) · Drag right side: look · Buttons: fire, aim, jump, stance, reload, use, swap, view' : 'WASD move · Mouse look · LMB fire · RMB aim · Shift sprint · Space jump · C crouch · Z prone · R reload · E use (hold to drill) · 1 rifle / 2 pistol · V camera · Esc pause'}</p>
      <p className="hint">Tip: the suppressed pistol silently takes down a guard who has not noticed you.</p>
      <div className="vehs" role="group" aria-label="Difficulty">{(Object.keys(RL.DIFFICULTY) as RL.Difficulty[]).map(d => <button key={d} className="sec" aria-pressed={save.difficulty === d} onClick={() => change({ difficulty: d })}>{RL.DIFFICULTY[d].name}</button>)}</div>
      <p className="hint">{D.blurb}</p>
      <div className="row"><label>Look sensitivity <input type="range" min=".3" max="3" step=".1" value={save.sens} onChange={e => change({ sens: +e.target.value })} /></label>
        <label><input type="checkbox" checked={save.sound} onChange={e => change({ sound: e.target.checked })} /> Sound</label>
        {coarse && <label><input type="checkbox" checked={save.haptics} onChange={e => change({ haptics: e.target.checked })} /> Vibration</label>}
        <label>Graphics <select value={save.gfx} onChange={e => change({ gfx: e.target.value as Gfx })}><option value="auto">Auto</option><option value="high">High</option><option value="low">Low (faster)</option></select></label></div>
      <p className="rec">Cash {fmtMoney(save.wallet)} · Best payout {fmtMoney(save.best)} · Heists {save.heists} ({save.wins} won)</p>
      <div className="vehs"><button className="big" autoFocus onClick={play}>Start heist</button><button onClick={() => setShop(true)}>Gear shop</button></div>
      {!native && <a href="#runner" onClick={() => setTimeout(() => location.reload(), 0)} className="lnk">Play the arcade runner instead</a>}
      <Ad />
      <div className="row"><a className="lnk" href={privacyLink || '#'} target={privacyLink ? '_blank' : undefined} rel="noopener" onClick={e => { if (!privacyLink) { e.preventDefault(); setPrivacy(true); } }}>Privacy &amp; ads</a>{ads.privacyOptions && <button className="sec" onClick={() => void ads.openPrivacyOptions()}>Ad privacy options</button>}</div></div>}
    {st === 'ready' && shop && <div className="ov"><h1>Gear shop</h1><p className="rec">Cash {fmtMoney(save.wallet)}</p>
      <div className="shop">{RL.UPGRADES.map(u => { const lv = save.upgrades[u.id], cost = RL.nextCost(save.upgrades, u.id); return <div key={u.id} className="item"><div><b>{u.name}</b> <span className="pips" aria-label={`level ${lv} of ${u.costs.length}`}>{'●'.repeat(lv)}{'○'.repeat(u.costs.length - lv)}</span><br /><small>{u.effect(lv)}{cost !== null ? ` → ${u.effect(lv + 1)}` : ' (max)'}</small></div>
        <button disabled={cost === null || save.wallet < cost} onClick={() => buy(u.id)}>{cost === null ? 'Maxed' : fmtMoney(cost)}</button></div>; })}</div>
      <p className="hint">Earn cash by completing heists. Upgrades are permanent.</p><button className="big" autoFocus onClick={() => setShop(false)}>Back</button></div>}
    {st === 'ready' && privacy && <div className="ov"><h2>Privacy &amp; ads</h2>
      <p className="hint" style={{ textAlign: 'left' }}>Your progress (cash, upgrades, settings) is stored only on this device. No account, no analytics. {native ? 'This app shows ads from Google AdMob on menu and result screens only; ads may use your device advertising ID, and where required you are asked for consent. You can change that under "Ad privacy options" when available, or in your Android settings (Google > Ads).' : 'If ads are enabled they are served by Google and appear on menu and result screens only.'}</p>
      <button className="big" autoFocus onClick={() => setPrivacy(false)}>Back</button></div>}
    {st === 'paused' && <div className="ov"><h1>Paused</h1><button className="big" autoFocus onClick={resume}>Resume</button><button onClick={restartNow}>Restart heist</button><button onClick={quitToMenu}>Main menu</button></div>}
    {st === 'over' && res && <div className="ov"><h1 style={{ color: res.win ? '#7dff6b' : '#ff5a5a' }}>{res.win ? 'HEIST COMPLETE' : 'WASTED'}</h1><p>{res.why}</p>
      {res.win && <p className="rec" style={{ fontSize: 26 }}>{fmtMoney(res.payout)} {'★'.repeat(res.stars)}{'☆'.repeat(3 - res.stars)}</p>}
      <p>Bags {res.bags} · Time {Math.round(res.time)}s · Takedowns {res.kills} · Accuracy {res.shots ? Math.round(res.hits / res.shots * 100) : 0}%{res.civHits ? ` · Civilians hurt ${res.civHits}` : ''}{res.alarmed ? ' · Alarm raised' : ' · Silent run bonus!'}</p>
      <p className="rec">Cash {fmtMoney(save.wallet)}{res.win && res.payout > 0 && res.payout >= save.best ? ' · New best!' : ''}</p>{note && <p aria-live="polite">{note}</p>}
      <div className="vehs">{res.win && !doubled.current && ads.rewardedReady() && <button disabled={!!busy} onClick={() => void watchDouble()}>{busy || `Watch ad: +${fmtMoney(res.payout)} bonus`}</button>}
        {!res.win && res.canRevive && ads.rewardedReady() && <button disabled={!!busy} onClick={() => void watchContinue()}>{busy || 'Watch ad to continue'}</button>}</div>
      <div className="vehs"><button className="big" autoFocus onClick={restart}>Try again</button><button onClick={() => { setShop(true); menu(); }}>Gear shop</button><button onClick={menu}>Main menu</button></div><Ad /></div>}
  </>;
}
createRoot(document.getElementById('root')!).render(<StrictMode><App /></StrictMode>);
