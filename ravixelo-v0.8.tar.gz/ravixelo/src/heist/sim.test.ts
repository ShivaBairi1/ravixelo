// Integration smoke test: runs the real game loop (physics, AI, doors, objectives) with a stubbed renderer and canvas.
import { describe, it, expect, vi, beforeAll } from 'vitest';
vi.mock('three', async orig => { const T = (await orig()) as Record<string, unknown>; class WebGLRenderer { domElement = {}; shadowMap = { enabled: false, type: 0 }; toneMapping = 0; toneMappingExposure = 1; info = { reset() {} }; setPixelRatio() {} setSize() {} render() {} dispose() {} } return { ...T, WebGLRenderer }; });
vi.mock('./assets', async orig => { const A = (await orig()) as Record<string, unknown>; const T = await import('three'); return { ...A, makeSky: () => new T.Vector3(.5, .8, .3) }; });
import { HeistGame, HeistHud, HeistResult } from './HeistGame';
import * as RL from './rules';
type Any = Record<string, any>;
beforeAll(() => {
  const ctx = new Proxy({}, { get: (_t, k) => (k === 'createImageData' ? (w: number, h: number) => ({ data: new Uint8ClampedArray(w * h * 4) }) : () => undefined), set: () => true });
  const g = globalThis as Any; g.window = g; g.document = { createElement: () => ({ width: 0, height: 0, getContext: () => ctx }), pointerLockElement: null, exitPointerLock() {} };
  g.matchMedia = () => ({ matches: false }); g.devicePixelRatio = 1; g.ResizeObserver = class { observe() {} disconnect() {} }; g.requestAnimationFrame = () => 0; g.cancelAnimationFrame = () => {};
});
async function boot() {
  const huds: HeistHud[] = [], results: HeistResult[] = []; const canvas = { parentElement: { clientWidth: 800, clientHeight: 450 } } as unknown as HTMLCanvasElement;
  const game = await HeistGame.create(canvas, { onHud: h => huds.push(h), onState: () => {}, onResult: r => results.push(r) }, 'low'); const G = game as unknown as Any; game.sfx.muted = true; let t = 1000;
  const tick = (n: number, keepAlive = true) => { for (let i = 0; i < n; i++) { t += 1000 / 60; if (keepAlive) G.hp = 1e6; G.frame(t); } };
  const put = (x: number, z: number, yaw = 0) => { G.pBody.setTranslation({ x, y: G.feetY + .92, z }, true); G.yaw = yaw; G.vel.set(0, 0); tick(2); };
  game.start(); tick(2); return { game, G, huds, results, tick, put };
}
describe('full game simulation (stub renderer)', () => {
  it('moves, changes stance, jumps and reloads without errors', async () => {
    const { game, G, tick } = await boot(); const z0 = G.pz; game.setMove(0, 1); tick(180); expect(G.pz).toBeLessThan(z0 - 5); game.setMove(0, 0);
    game.press('crouch'); tick(5); expect(G.stance).toBe('crouch'); game.press('prone'); tick(5); expect(G.stance).toBe('prone'); game.press('cycle'); tick(5); expect(G.stance).toBe('stand');
    game.press('jump'); tick(10); expect(G.feetY).toBeGreaterThan(.05); tick(90); expect(G.feetY).toBeLessThan(.1);
    G.ammo.rifle.mag = 5; game.press('reload'); tick(160); expect(G.ammo.rifle.mag).toBe(30); game.press('swap'); tick(2); expect(G.wid).toBe('pistol'); game.press('view'); tick(5); game.press('view'); game.dispose();
  });
  it('plays the whole heist: keycard, staff door, drill, loot, escape', async () => {
    const { game, G, huds, results, tick, put } = await boot();
    put(-10, -8.9); game.setInteract(true); tick(140); game.setInteract(false); expect(G.m.keycard).toBe(true); expect(G.m.inside).toBe(true);
    put(0, -7.2); game.setInteract(true); tick(3); game.setInteract(false); tick(3); expect(G.m.staffOpen).toBe(true); tick(60);
    put(0, -14.9); game.setInteract(true); tick(700); game.setInteract(false); expect(G.m.vaultOpen).toBe(true); // the drill is loud but no longer forces the alarm: guards must actually spot you
    tick(90); for (const [x, z] of [[-2, -20.6], [1, -20.6], [4, -20.6]]) { put(x, z); for (let k = 0; k < 3; k++) { game.setInteract(true); tick(2); game.setInteract(false); tick(2); } } expect(G.m.bags).toBeGreaterThanOrEqual(1);
    put(10, -26); tick(5); expect(results.length).toBe(1); expect(results[0].win).toBe(true); expect(results[0].payout).toBe(RL.payout(results[0].bags, 0, results[0].alarmed)); expect(huds.length).toBeGreaterThan(10); game.dispose();
  });
  it('shooting works, raises the alarm, and police spawn and approach', async () => {
    const { game, G, tick, put } = await boot(); put(0, 3, 0); const mag0 = G.ammo.rifle.mag; game.setFire(true); tick(30); game.setFire(false);
    expect(G.ammo.rifle.mag).toBeLessThan(mag0); expect(G.shots).toBeGreaterThan(2); expect(G.alarm).toBe(true);
    tick(30 * 60); expect(G.copsSpawned).toBeGreaterThanOrEqual(3); const cops = G.actors.filter((a: Any) => a.kind === 'cop' && !a.dead); expect(cops.length).toBeGreaterThan(0);
    expect(Math.min(...cops.map((c: Any) => Math.hypot(c.pos.x - G.px, c.pos.z - G.pz)))).toBeLessThan(25); game.dispose();
  });
  it('enemies can defeat a player who stands in the open (game over is reported)', async () => {
    const { game, G, results, tick, put } = await boot(); put(0, 3, 0); game.setFire(true); tick(10); game.setFire(false); G.hp = 100;
    for (let i = 0; i < 60 * 60 && !results.length; i++) tick(1, false);
    expect(results.length).toBe(1); expect(results[0].win).toBe(false); expect(game.state).toBe('over'); game.dispose();
  });
  it('a silent run keeps the alarm off and a killed guard counts', async () => {
    const { game, G, tick, put } = await boot(); put(-20, 14); game.setMove(0, 0); tick(300); expect(G.alarm).toBe(false);
    const g0 = G.actors.find((a: Any) => a.kind === 'guard'); g0.hp = 1; G.kill(g0); expect(G.kills).toBe(1); expect(g0.dead).toBe(true); tick(5); game.dispose();
  });
  it('a suppressed pistol takes down an unaware guard silently (no alarm)', async () => {
    const { game, G, tick, put } = await boot(); const guard = G.actors.find((a: Any) => a.kind === 'guard'); guard.patrol = []; guard.state = 'idle'; guard.pos.set(-6, 0, 2); guard.yaw = Math.PI; // facing away (+z), player stands behind him
    put(-6, -2.5, Math.PI); game.press('pistol'); tick(2); game.setFire(true); tick(3); game.setFire(false); tick(2);
    expect(guard.dead).toBe(true); expect(G.kills).toBe(1); expect(G.alarm).toBe(false); game.dispose();
  });
  it('the rifle is loud: a hit raises the alarm', async () => {
    const { game, G, tick, put } = await boot(); const guard = G.actors.find((a: Any) => a.kind === 'guard'); guard.patrol = []; guard.state = 'idle'; guard.pos.set(-6, 0, 2); guard.yaw = Math.PI;
    put(-6, -2.5, Math.PI); game.press('rifle'); tick(2); game.setFire(true); tick(6); game.setFire(false); expect(G.alarm).toBe(true); game.dispose();
  });
  it('one continue after being taken down, then it is final', async () => {
    const { game, G, results, tick } = await boot(); G.hurt(9999); expect(results.length).toBe(1); expect(results[0].win).toBe(false); expect(results[0].canRevive).toBe(true);
    expect(game.revive()).toBe(true); expect(game.state).toBe('playing'); expect(G.hp).toBeGreaterThan(50); G.hurt(9999); expect(game.state).toBe('playing'); // 4 s of protection after reviving
    tick(60 * 5, false); G.hurt(9999); expect(results.length).toBe(2); expect(results[1].canRevive).toBe(false); expect(game.revive()).toBe(false); game.dispose();
  });
  it('menu reset clears leftovers; loadout and difficulty apply', async () => {
    const { game, G, tick, put } = await boot(); put(0, 3, 0); game.setFire(true); tick(20); game.setFire(false); game.toMenu();
    expect(game.state).toBe('ready'); expect(G.decals.every((d: Any) => !d.visible)).toBe(true); expect(G.ammo.rifle.mag).toBe(30); expect(G.alarm).toBe(false);
    game.setLoadout({ armor: 2, ammo: 2, drill: 1, stealth: 0 }); expect(G.maxHp).toBe(130); expect(G.hp).toBe(130); expect(G.ammo.rifle.reserve).toBe(180); expect(G.drillSec).toBeLessThan(RL.DRILL_TIME);
    game.setDifficulty('legend'); expect(G.diff.pay).toBe(1.5); game.dispose();
  });
});
