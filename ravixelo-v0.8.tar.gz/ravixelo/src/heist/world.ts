import * as THREE from 'three';
import RAPIER from '@dimforge/rapier3d-compat';
import { BANK, BOUNDS, COVER, DOORS, DoorDef, EXTRACT, LIGHTS, LOOT, Mat, WALLS } from './level';
import { Rect } from './nav';
import { Mats, signTexture } from './assets';

export interface Door { def: DoorDef; group: THREE.Group; panels: THREE.Mesh[]; body: RAPIER.RigidBody; open: number; target: number; locked: boolean }
export interface LootItem { mesh: THREE.Group; x: number; z: number; taken: boolean }
export interface WorldRefs { doors: Door[]; loot: LootItem[]; copCars: { g: THREE.Group; red: THREE.MeshStandardMaterial; blue: THREE.MeshStandardMaterial }[]; geos: THREE.BufferGeometry[]; group: THREE.Group }

/** Box with UVs scaled to world size so textures keep a constant real-world scale. */
function boxGeo(w: number, h: number, d: number, m?: THREE.MeshStandardMaterial) {
  const g = new THREE.BoxGeometry(w, h, d), uv = g.attributes.uv as THREE.BufferAttribute, rep = m?.map?.repeat ?? new THREE.Vector2(1, 1), dims = [[d, h], [d, h], [w, d], [w, d], [w, h], [w, h]];
  for (let f = 0; f < 6; f++) for (let v = 0; v < 4; v++) { const i = f * 4 + v; uv.setXY(i, uv.getX(i) * dims[f][0] / (2 * rep.x), uv.getY(i) * dims[f][1] / (2 * rep.y)); }
  return g;
}
function planeGeo(w: number, d: number, m: THREE.MeshStandardMaterial) {
  const g = new THREE.PlaneGeometry(w, d).rotateX(-Math.PI / 2), uv = g.attributes.uv as THREE.BufferAttribute, rep = m.map?.repeat ?? new THREE.Vector2(1, 1);
  for (let i = 0; i < uv.count; i++) uv.setXY(i, uv.getX(i) * w / (2 * rep.x), uv.getY(i) * d / (2 * rep.y)); return g;
}
export function buildWorld(scene: THREE.Scene, world: RAPIER.World, M: Mats, shadows: boolean): WorldRefs {
  const R: WorldRefs = { doors: [], loot: [], copCars: [], geos: [], group: new THREE.Group() }; scene.add(R.group); const grp = R.group;
  const mesh = (geo: THREE.BufferGeometry, mat: THREE.Material, x: number, y: number, z: number, cast = true, recv = true) => { R.geos.push(geo); const m = new THREE.Mesh(geo, mat); m.position.set(x, y, z); m.castShadow = shadows && cast; m.receiveShadow = shadows && recv; grp.add(m); return m; };
  const fixed = (x: number, y: number, z: number, hx: number, hy: number, hz: number, rest = .2) => { const b = world.createRigidBody(RAPIER.RigidBodyDesc.fixed().setTranslation(x, y, z)); world.createCollider(RAPIER.ColliderDesc.cuboid(hx, hy, hz).setRestitution(rest).setFriction(.8), b); return b; };
  const solid = (r: Rect, h: number, mat: THREE.MeshStandardMaterial, y0 = 0, collide = true) => { mesh(boxGeo(r.w, h, r.d, mat), mat, r.x, y0 + h / 2, r.z); if (collide) fixed(r.x, y0 + h / 2, r.z, r.w / 2, h / 2, r.d / 2); };
  // ground, road, sidewalks
  fixed(0, -.5, -5, 80, .5, 60); mesh(planeGeo(260, 260, M.grass), M.grass, 0, -.01, -5, false, true);
  mesh(planeGeo(100, 12, M.asphalt), M.asphalt, 0, .005, 16, false, true); for (let x = -46; x < 46; x += 6) mesh(new THREE.BoxGeometry(2.6, .01, .18), M.band, x, .012, 16, false, false);
  mesh(planeGeo(100, 4, M.sidewalk), M.sidewalk, 0, .01, 8, false, true); mesh(planeGeo(100, 3, M.sidewalk), M.sidewalk, 0, .01, 23.5, false, true); mesh(planeGeo(60, 8, M.concrete), M.concrete, 0, .01, -28, false, true);
  // bank shell
  const front = [WALLS[0], WALLS[1]];
  WALLS.forEach((w, i) => {
    if (front.includes(w)) { solid(w, 1, M.brick, 0, false); mesh(new THREE.BoxGeometry(w.w, 1.8, .06), M.glass, w.x, 1.9, w.z, false, false); solid(w, .8, M.brick, 2.8, false); fixed(w.x, BANK.h / 2, w.z, w.w / 2, BANK.h / 2, w.d / 2); }
    else solid(w, BANK.h, i < 6 ? M.brick : M.wall);
  });
  for (const d of DOORS) { const horiz = d.along === 'x'; mesh(boxGeo(horiz ? d.w + .1 : .3, .9, horiz ? .3 : d.w + .1, M.wall), M.wall, d.x, 3.15, d.z); }
  const roof = { x: (BANK.minX + BANK.maxX) / 2, z: (BANK.minZ + BANK.maxZ) / 2, w: BANK.maxX - BANK.minX + .6, d: BANK.maxZ - BANK.minZ + .6 }; solid(roof, .35, M.concrete, BANK.h, false);
  mesh(planeGeo(roof.w - .6, roof.d - .6, M.tile), M.tile, roof.x, .02, roof.z, false, true); mesh(planeGeo(8, 8, M.carpet), M.carpet, -10, .03, -12, false, true);
  const sign = new THREE.Mesh(new THREE.PlaneGeometry(7, 1.3), new THREE.MeshStandardMaterial({ map: signTexture('MERIDIAN TRUST'), emissive: 0x332200, emissiveMap: signTexture('MERIDIAN TRUST') })); sign.position.set(0, 4.6, 6.2); R.geos.push(sign.geometry); grp.add(sign);
  // cover / furniture
  const matFor = (m: Mat): THREE.MeshStandardMaterial => (m === 'wood' ? M.wood : m === 'metal' ? M.steel : m === 'fabric' ? M.fabric : m === 'crate' ? M.crate : m === 'concrete' ? M.concrete : m === 'van' ? M.van : M.car[0]);
  COVER.forEach((c, i) => {
    if (c.mat === 'car' || c.mat === 'van') { const g = carModel(M, c.mat === 'van' ? M.van : M.car[i % 4], c.mat === 'van', R); g.position.set(c.x, 0, c.z); grp.add(g); fixed(c.x, c.h / 2, c.z, c.w / 2, c.h / 2, c.d / 2); }
    else { solid(c, c.h, matFor(c.mat)); if (c.mat === 'wood' && c.h < 1) mesh(new THREE.BoxGeometry(.5, .35, .04), M.screen, c.x, c.h + .2, c.z, false, false); }
  });
  // vault deposit-box wall + shelves for atmosphere
  mesh(boxGeo(.2, 2.6, 7, M.steel), M.steel, -13.8, 1.3, -20); mesh(boxGeo(.2, 2.6, 7, M.steel), M.steel, 9.8, 1.3, -22);
  // boundary
  const B = BOUNDS; fixed(0, 3, B.minZ - .5, 41, 3, .5); fixed(0, 3, B.maxZ + .5, 41, 3, .5); fixed(B.minX - .5, 3, -5, .5, 3, 32); fixed(B.maxX + .5, 3, -5, .5, 3, 32);
  // lights (emissive panels; real lights are added by the game for quality control)
  for (const [x, z] of LIGHTS) mesh(new THREE.BoxGeometry(1.4, .06, .5), M.emis, x, BANK.h - .05, z, false, false);
  // doors
  for (const d of DOORS) {
    const horiz = d.along === 'x', group = new THREE.Group(), panels: THREE.Mesh[] = []; const sliding = d.kind === 'auto' || d.kind === 'vault';
    const mat = d.kind === 'vault' ? M.steel : d.kind === 'auto' ? M.glass : d.kind === 'locked' ? M.steel : M.wood, th = d.kind === 'vault' ? .5 : d.kind === 'auto' ? .06 : .12, hh = d.kind === 'vault' ? 3.2 : 2.7;
    const n = d.kind === 'auto' ? 2 : 1, pw = d.w / n;
    for (let k = 0; k < n; k++) { const gg = new THREE.BoxGeometry(horiz ? pw : th, hh, horiz ? th : pw); R.geos.push(gg); const p = new THREE.Mesh(gg, mat); p.castShadow = shadows; panels.push(p); group.add(p); if (d.kind === 'vault') { const t = new THREE.TorusGeometry(.5, .07, 8, 20); R.geos.push(t); const wheel = new THREE.Mesh(t, M.dark); wheel.position.set(0, 0, th / 2 + .1); p.add(wheel); } }
    if (sliding) panels.forEach((p, k) => p.position.set(horiz ? (k - (n - 1) / 2) * pw : 0, hh / 2, horiz ? 0 : (k - (n - 1) / 2) * pw)); else { const hx = horiz ? -d.w / 2 : 0, hz = horiz ? 0 : -d.w / 2; group.position.set(hx, 0, hz); panels[0].position.set(horiz ? d.w / 2 : 0, hh / 2, horiz ? 0 : d.w / 2); }
    group.position.add(new THREE.Vector3(d.x, 0, d.z)); grp.add(group);
    const body = world.createRigidBody(RAPIER.RigidBodyDesc.fixed().setTranslation(d.x, hh / 2, d.z)); world.createCollider(RAPIER.ColliderDesc.cuboid(horiz ? d.w / 2 : th / 2, hh / 2, horiz ? th / 2 : d.w / 2), body);
    R.doors.push({ def: d, group, panels, body, open: 0, target: 0, locked: d.kind === 'locked' || d.kind === 'vault' });
  }
  // loot
  for (const [x, z] of LOOT) { const g = new THREE.Group(); const b = new THREE.Mesh(new THREE.BoxGeometry(.5, .28, .34), M.cash), band = new THREE.Mesh(new THREE.BoxGeometry(.52, .08, .12), M.band); R.geos.push(b.geometry, band.geometry); b.castShadow = band.castShadow = shadows; g.add(b, band); g.position.set(x, 1.0, z); grp.add(g); R.loot.push({ mesh: g, x, z, taken: false }); }
  // trees, lamps, skyline
  const trunk = new THREE.CylinderGeometry(.18, .25, 3, 8), leaf = new THREE.SphereGeometry(1.6, 12, 10); R.geos.push(trunk, leaf);
  for (const [x, z] of [[-30, 8], [-20, 8], [-6, 8], [8, 8], [20, 8], [32, 8], [-30, 24], [-8, 24], [14, 24], [32, 24], [-34, -20], [34, -20]]) { mesh(trunk, M.trunk, x, 1.5, z); mesh(leaf, M.leaf, x, 4, z); }
  const pole = new THREE.CylinderGeometry(.06, .08, 6, 8); R.geos.push(pole);
  for (let x = -36; x <= 36; x += 12) { mesh(pole, M.dark, x, 3, 9.8); mesh(new THREE.BoxGeometry(.9, .12, .3), M.emis, x + .3, 6, 9.8, false, false); }
  for (let i = 0; i < 40; i++) { const side = i % 4, w = 10 + (i * 7) % 14, h = 24 + (i * 13) % 50, a = (i * 2.399) % (Math.PI * 2); const dist = 62 + (i * 5) % 30; const x = Math.cos(a) * dist * (side < 2 ? 1.4 : 1), z = Math.sin(a) * dist - 8; if (Math.abs(x) < 46 && z > -42 && z < 32) continue; mesh(new THREE.BoxGeometry(w, h, w), M.sky[i % 3], x, h / 2, z, false, false); }
  // police cars (hidden until the alarm)
  for (const [x, z] of [[-17, 14.5], [17, 14.5]]) { const red = new THREE.MeshStandardMaterial({ color: 0xff2020, emissive: 0xff2020, emissiveIntensity: 0 }), blue = new THREE.MeshStandardMaterial({ color: 0x2050ff, emissive: 0x2050ff, emissiveIntensity: 0 }); const g = carModel(M, M.car[2], false, R, { red, blue }); g.position.set(x, 0, z); g.rotation.y = x < 0 ? .2 : -.2; g.visible = false; grp.add(g); R.copCars.push({ g, red, blue }); fixed(x, .75, z, 2.2, .75, .95); }
  void EXTRACT; return R;
}
function carModel(M: Mats, body: THREE.MeshStandardMaterial, van: boolean, R: WorldRefs, lights?: { red: THREE.MeshStandardMaterial; blue: THREE.MeshStandardMaterial }) {
  const g = new THREE.Group(), add = (w: number, h: number, d: number, m: THREE.Material, x: number, y: number, z: number) => { const ge = new THREE.BoxGeometry(w, h, d); R.geos.push(ge); const me = new THREE.Mesh(ge, m); me.position.set(x, y, z); me.castShadow = true; g.add(me); return me; };
  if (van) { add(5.4, 1.7, 2.2, body, 0, 1.2, 0); add(1.6, 1.0, 2.1, M.glass, -1.9, 1.7, 0); } else { add(4.4, .8, 1.9, body, 0, .65, 0); add(2.2, .6, 1.7, M.glass, -.2, 1.2, 0); }
  const wl = (van ? 2 : 1.4); for (const sx of [-wl, wl]) for (const sz of [-.95, .95]) { const c = new THREE.CylinderGeometry(.35, .35, .25, 14).rotateX(Math.PI / 2); R.geos.push(c); const w = new THREE.Mesh(c, M.dark); w.position.set(sx, .35, sz); g.add(w); }
  if (lights) { add(.3, .12, .5, lights.red, -.2, 1.55, -.45); add(.3, .12, .5, lights.blue, -.2, 1.55, .45); }
  return g;
}
