import { describe, it, expect } from 'vitest';
import * as P from './progress';
import * as R from './rules';
const mem = (v?: string, old?: string) => { const m: Record<string, string> = {}; if (v !== undefined) m['ravixelo.heist.v2'] = v; if (old !== undefined) m['ravixelo.heist.v1'] = old; return { getItem: (k: string) => m[k] ?? null, setItem: (k: string, x: string) => { m[k] = x; } }; };
describe('save data', () => {
  it('round-trips and survives corruption', () => {
    const m = mem(); const s = P.addCash(P.defaultSave(), 123456); P.writeSave(m, s); expect(P.loadSave(m)).toEqual(s);
    for (const bad of ['not json', 'null', '[]', '{"wallet":-5,"sens":99,"difficulty":"god","gfx":"ultra","upgrades":{"armor":99,"ammo":-3}}']) {
      const l = P.loadSave(mem(bad)); expect(l.wallet).toBe(0); expect(l.sens).toBe(1); expect(l.difficulty).toBe('pro'); expect(l.gfx).toBe('auto'); expect(l.upgrades.armor).toBeLessThanOrEqual(R.maxLevel('armor')); expect(l.upgrades.ammo).toBe(0);
    }
  });
  it('migrates the old v1 key (best score, sound, sensitivity)', () => { const l = P.loadSave(mem(undefined, '{"sens":1.5,"sound":false,"gfx":"low","best":90000}')); expect(l.sens).toBe(1.5); expect(l.sound).toBe(false); expect(l.gfx).toBe('low'); expect(l.best).toBe(90000); expect(l.wallet).toBe(0); });
  it('buying upgrades spends cash, respects max level and price', () => {
    let s = P.addCash(P.defaultSave(), 70000); expect(P.buyUpgrade(P.defaultSave(), 'armor')).toBeNull();
    s = P.buyUpgrade(s, 'armor')!; expect(s.wallet).toBe(10000); expect(s.upgrades.armor).toBe(1); expect(P.buyUpgrade(s, 'armor')).toBeNull();
    let rich = P.addCash(P.defaultSave(), 5e6); for (let i = 0; i < 10; i++) rich = P.buyUpgrade(rich, 'ammo') ?? rich; expect(rich.upgrades.ammo).toBe(R.maxLevel('ammo')); expect(P.buyUpgrade(rich, 'ammo')).toBeNull();
  });
  it('cash is never negative or unbounded', () => { const s = P.addCash(P.defaultSave(), -50); expect(s.wallet).toBe(0); expect(P.addCash(P.addCash(s, P.MAX_WALLET), 10).wallet).toBe(P.MAX_WALLET); });
  it('records runs: best only on wins, silent wins counted', () => {
    let s = P.recordRun(P.defaultSave(), { win: true, payout: 150000, alarmed: false }); expect([s.heists, s.wins, s.silentWins, s.best]).toEqual([1, 1, 1, 150000]);
    s = P.recordRun(s, { win: false, payout: 0, alarmed: true }); expect([s.heists, s.wins, s.best]).toEqual([2, 1, 150000]);
    s = P.recordRun(s, { win: true, payout: 90000, alarmed: true }); expect(s.best).toBe(150000); expect(s.silentWins).toBe(1);
  });
});
describe('v0.8 rules', () => {
  const none = R.noUpgrades();
  it('upgrade maths', () => {
    expect(R.maxHp(none)).toBe(100); expect(R.maxHp({ ...none, armor: 4 })).toBe(160); expect(R.drillSeconds({ ...none, drill: 3 })).toBeLessThan(R.DRILL_TIME); expect(R.drillSeconds(none)).toBe(R.DRILL_TIME);
    expect(R.reserveFor(R.WEAPONS.rifle, { ...none, ammo: 2 })).toBe(180); expect(R.stealthMul({ ...none, stealth: 3 })).toBeCloseTo(.7); expect(R.nextCost(none, 'armor')).toBe(60000);
    expect(R.nextCost({ ...none, armor: 4 }, 'armor')).toBeNull(); expect(R.clampLoadout({ armor: 2.9, drill: 'x', stealth: 99 })).toEqual({ armor: 2, ammo: 0, drill: 0, stealth: 3 });
  });
  it('difficulty scales threat and pay', () => {
    expect(R.DIFFICULTY.rookie.enemyDmg).toBeLessThan(R.DIFFICULTY.pro.enemyDmg); expect(R.DIFFICULTY.legend.enemyDmg).toBeGreaterThan(R.DIFFICULTY.pro.enemyDmg); expect(R.DIFFICULTY.legend.pay).toBeGreaterThan(R.DIFFICULTY.rookie.pay);
    expect(R.copsAllowed(9999, R.DIFFICULTY.rookie.copCap)).toBe(6); expect(R.copsAllowed(9999)).toBe(10); expect(R.detectRange('stand', true, .5)).toBe(10); expect(R.isDifficulty('pro')).toBe(true); expect(R.isDifficulty('x')).toBe(false);
  });
  it('only the silenced pistol makes silent takedowns, and only on unaware guards', () => {
    expect(R.stealthKill(R.WEAPONS.pistol, true)).toBe(true); expect(R.stealthKill(R.WEAPONS.pistol, false)).toBe(false); expect(R.stealthKill(R.WEAPONS.rifle, true)).toBe(false);
  });
  it('wallet rewards', () => { expect(R.walletReward(true, 120000, 0)).toBe(120000); expect(R.walletReward(false, 0, 2)).toBe(6000); expect(R.walletReward(false, 0, 99)).toBe(15000); expect(R.walletReward(false, 0, -4)).toBe(0); });
});
