// Pure game rules for the heist mode (unit-tested; no rendering here).
export type Stance = 'stand' | 'crouch' | 'prone';
export const STANCE: Record<Stance, { speed: number; sprint: number; eye: number; h: number; noise: number }> = {
  stand: { speed: 3.6, sprint: 6, eye: 1.62, h: 1.8, noise: 1 },
  crouch: { speed: 2, sprint: 2, eye: 1.05, h: 1.2, noise: .6 },
  prone: { speed: .9, sprint: .9, eye: .4, h: .55, noise: .3 },
};
export const nextStance = (s: Stance): Stance => (s === 'stand' ? 'crouch' : s === 'crouch' ? 'prone' : 'stand');
export type WeaponId = 'pistol' | 'rifle';
export interface Weapon { id: WeaponId; name: string; mag: number; reserve: number; rate: number; dmg: number; spread: number; recoil: number; auto: boolean; noise: number; reload: number }
export const WEAPONS: Record<WeaponId, Weapon> = {
  pistol: { id: 'pistol', name: 'Suppressed pistol', mag: 12, reserve: 48, rate: .22, dmg: 28, spread: .012, recoil: .018, auto: false, noise: 9, reload: 1.3 },
  rifle: { id: 'rifle', name: 'Assault rifle', mag: 30, reserve: 120, rate: .095, dmg: 22, spread: .02, recoil: .01, auto: true, noise: 40, reload: 2.1 },
};
export const hitDamage = (w: Weapon, dist: number, head: boolean) => Math.round(w.dmg * (head ? 2.5 : 1) * Math.max(.4, 1 - dist / 90));
export const spreadFor = (w: Weapon, stance: Stance, moving: boolean, aiming: boolean, bloom: number) =>
  w.spread * (aiming ? .45 : 1) * (stance === 'stand' ? 1 : stance === 'crouch' ? .7 : .5) * (moving ? 1.8 : 1) + bloom;
export const carrySlow = (bags: number) => 1 - Math.min(bags, 6) * .05;
/** How far (m) guards can notice the player. */
export const detectRange = (s: Stance, moving: boolean, mul = 1) => 20 * STANCE[s].noise * (moving ? 1 : .65) * mul;
/** Chance an enemy shot hits the player. */
export const hitChance = (dist: number, s: Stance, moving: boolean) => Math.max(.08, Math.min(.85, .8 - dist * .025)) * (s === 'stand' ? 1 : s === 'crouch' ? .75 : .55) * (moving ? .8 : 1);

export interface MissionState { inside: boolean; keycard: boolean; staffOpen: boolean; drill: number; vaultOpen: boolean; bags: number; extracted: boolean }
export const newMission = (): MissionState => ({ inside: false, keycard: false, staffOpen: false, drill: 0, vaultOpen: false, bags: 0, extracted: false });
export type Obj = 'enter' | 'keycard' | 'staff' | 'drill' | 'loot' | 'escape' | 'done';
export function objective(m: MissionState): Obj {
  if (m.extracted) return 'done'; if (!m.inside) return 'enter'; if (!m.keycard && !m.staffOpen) return 'keycard'; if (!m.staffOpen) return 'staff';
  if (!m.vaultOpen) return 'drill'; if (m.bags < 1) return 'loot'; return 'escape';
}
export const OBJ_TEXT: Record<Obj, string> = {
  enter: 'Enter Meridian Trust Bank', keycard: 'Find the manager (office, west side) and demand the keycard', staff: 'Unlock the STAFF door behind the counter',
  drill: 'Drill the vault door (hold E)', loot: 'Grab cash bags inside the vault', escape: 'Escape to the getaway van in the back alley', done: 'Heist complete',
};
export const DRILL_TIME = 10, BAG_VALUE = 40000, MAX_BAGS = 6;
export const payout = (bags: number, civHits: number, alarmed: boolean) => Math.max(0, bags * BAG_VALUE - civHits * 25000 + (alarmed ? 0 : 30000));
export const stars = (bags: number, alarmed: boolean, hp: number) => 1 + (bags >= 4 ? 1 : 0) + (!alarmed ? 1 : hp > 50 ? 1 : 0);
export const copsAllowed = (secondsSinceAlarm: number, cap = 10) => (secondsSinceAlarm < 12 ? 0 : Math.min(cap, 2 + Math.floor((secondsSinceAlarm - 12) / 14)));
export const fmtMoney = (n: number) => '$' + n.toLocaleString('en-US');

// ---- v0.8: difficulty, upgrades, stealth, rewards (all pure and unit-tested)
export type Difficulty = 'rookie' | 'pro' | 'legend';
export interface DifficultyDef { name: string; enemyDmg: number; detect: number; copCap: number; pay: number; blurb: string }
export const DIFFICULTY: Record<Difficulty, DifficultyDef> = {
  rookie: { name: 'Rookie', enemyDmg: .7, detect: .8, copCap: 6, pay: .75, blurb: 'Softer guards, fewer police. 75% payout.' },
  pro: { name: 'Pro', enemyDmg: 1, detect: 1, copCap: 10, pay: 1, blurb: 'The intended challenge.' },
  legend: { name: 'Legend', enemyDmg: 1.35, detect: 1.25, copCap: 14, pay: 1.5, blurb: 'Sharp-eyed guards, heavy police. 150% payout.' },
};
export const isDifficulty = (v: unknown): v is Difficulty => v === 'rookie' || v === 'pro' || v === 'legend';

export type UpgradeId = 'armor' | 'ammo' | 'drill' | 'stealth';
export type Loadout = Record<UpgradeId, number>;
export interface UpgradeDef { id: UpgradeId; name: string; costs: number[]; effect: (level: number) => string }
export const UPGRADES: UpgradeDef[] = [
  { id: 'armor', name: 'Body armor', costs: [60000, 120000, 200000, 300000], effect: l => `Max health ${100 + l * 15}` },
  { id: 'ammo', name: 'Extra magazines', costs: [40000, 90000, 160000], effect: l => `Reserve ammo +${l * 25}%` },
  { id: 'drill', name: 'Thermal drill', costs: [80000, 160000, 260000], effect: l => `Vault drill ${(DRILL_TIME * (1 - l * .12)).toFixed(1)} s` },
  { id: 'stealth', name: 'Soft soles', costs: [100000, 200000, 320000], effect: l => `Guards notice you ${l * 10}% later` },
];
export const noUpgrades = (): Loadout => ({ armor: 0, ammo: 0, drill: 0, stealth: 0 });
export const maxLevel = (id: UpgradeId) => UPGRADES.find(u => u.id === id)!.costs.length;
export const clampLoadout = (l: Partial<Record<UpgradeId, unknown>>): Loadout => {
  const o = noUpgrades(); for (const u of UPGRADES) { const v = l[u.id]; if (typeof v === 'number' && Number.isFinite(v)) o[u.id] = Math.max(0, Math.min(u.costs.length, Math.floor(v))); } return o;
};
/** Price of the next level, or null when maxed. */
export const nextCost = (l: Loadout, id: UpgradeId): number | null => UPGRADES.find(u => u.id === id)!.costs[l[id]] ?? null;
export const maxHp = (l: Loadout) => 100 + l.armor * 15;
export const drillSeconds = (l: Loadout) => DRILL_TIME * (1 - l.drill * .12);
export const reserveFor = (w: Weapon, l: Loadout) => Math.round(w.reserve * (1 + l.ammo * .25));
export const stealthMul = (l: Loadout) => 1 - l.stealth * .1;

/** A silenced weapon (pistol) kills an unaware guard in one shot without raising the alarm. */
export const isSilenced = (w: Weapon) => w.noise < 30;
export const stealthKill = (w: Weapon, victimUnaware: boolean) => victimUnaware && isSilenced(w);

/** Money added to the player's wallet after a run. Wins pay the payout; a loss pays a small takedown bonus. */
export const walletReward = (win: boolean, payoutValue: number, kills: number) => (win ? payoutValue : Math.min(15000, Math.max(0, kills) * 3000));
