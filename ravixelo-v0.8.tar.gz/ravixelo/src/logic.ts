import { C, VEHICLES, Vehicle, VehicleId, ZONES } from './config';
export type GameState = 'ready' | 'playing' | 'paused' | 'over';
export type GameEvent = 'play' | 'pause' | 'resume' | 'die' | 'retry';
const T: Record<GameState, Partial<Record<GameEvent, GameState>>> = {
  ready: { play: 'playing' }, playing: { pause: 'paused', die: 'over' },
  paused: { resume: 'playing' }, over: { retry: 'playing' },
};
export const transition = (s: GameState, e: GameEvent): GameState => T[s][e] ?? s;

export interface Run { distance: number; orbs: number; bonus: number; stolen: number; banked: number; collected: Set<string> }
export const createRun = (): Run => ({ distance: 0, orbs: 0, bonus: 0, stolen: 0, banked: 0, collected: new Set() });
export const addDistance = (r: Run, d: number) => { if (d > r.distance) r.distance = d; };
export function collectOrb(r: Run, id: string, mult = 1): boolean {
  if (r.collected.has(id)) return false;
  r.collected.add(id); r.orbs++; r.bonus += (mult - 1) * C.orbPts; return true;
}
export const cashOf = (r: Run) => Math.max(0, r.orbs * C.orbPts + r.bonus - r.stolen);
export const score = (r: Run) => Math.floor(r.distance) + cashOf(r);

export interface Store { best: number; sound: boolean; vehicle: VehicleId; plays: number; keys: number; fpv: boolean; daily: { d: number; best: number } }
type KV = Pick<Storage, 'getItem' | 'setItem'>;
const KEY = 'ravixelo.v1';
const nn = (x: unknown) => (typeof x === 'number' && Number.isFinite(x) && x >= 0 ? Math.floor(x) : null);
export const defaultStore = (): Store => ({ best: 0, sound: true, vehicle: 'ball', plays: 0, keys: 0, fpv: false, daily: { d: 0, best: 0 } });
export function loadStore(s: KV): Store {
  const d = defaultStore();
  try {
    const o = JSON.parse(s.getItem(KEY) ?? 'null');
    if (o && typeof o === 'object') {
      d.best = nn(o.best) ?? 0; d.plays = nn(o.plays) ?? 0; d.keys = Math.min(999, nn(o.keys) ?? 0); if (typeof o.fpv === 'boolean') d.fpv = o.fpv;
      if (typeof o.sound === 'boolean') d.sound = o.sound;
      if (VEHICLES.some(v => v.id === o.vehicle)) d.vehicle = o.vehicle;
      if (o.daily && typeof o.daily === 'object') d.daily = { d: nn(o.daily.d) ?? 0, best: nn(o.daily.best) ?? 0 };
    }
  } catch { /* corrupted: use defaults */ }
  return d;
}
export function saveStore(s: KV, v: Store) { try { s.setItem(KEY, JSON.stringify(v)); } catch { /* quota/private mode */ } }
export function submitScore(v: Store, sc: number, seed?: number): { store: Store; record: boolean } {
  if (seed) { const cur = v.daily.d === seed ? v.daily.best : 0; return sc > cur ? { store: { ...v, daily: { d: seed, best: sc } }, record: true } : { store: v, record: false }; }
  return sc > v.best ? { store: { ...v, best: sc }, record: true } : { store: v, record: false };
}
export const dailySeed = (t = new Date()) => t.getUTCFullYear() * 10000 + (t.getUTCMonth() + 1) * 100 + t.getUTCDate();
export const unlocked = (v: Vehicle, s: Store) => Math.max(s.best, s.daily.best) >= v.unlock;
export type PowerKind = 'shield' | 'ghost' | 'double' | 'calm' | 'bomb' | 'bank';
const PK: PowerKind[] = ['shield', 'ghost', 'double', 'calm'];
export const zoneNo = (d: number) => (d < C.firstZone ? 0 : 1 + Math.floor((d - C.firstZone) / C.zoneLen));
export const zoneIndex = (d: number) => zoneNo(d) % ZONES.length;
export const levelAt = (d: number) => 1 + Math.floor(Math.max(0, d) / C.levelLen);
export const windAt = (t: number, lvl: number) => Math.sin(t * 1.1) * Math.max(0, Math.sin(t * .3)) * (4 + lvl);

export type Kind = 'open' | 'barrier' | 'hurdle' | 'underpass' | 'chasm' | 'oncoming' | 'police' | 'gridlock' | 'ambush' | 'patrol';
export interface Chaser { x: number; type: 'robber' | 'cop' }
export interface Seg { index: number; kind: Kind; x: number; w: number; lanes: number[]; bikes: boolean[]; chasers: Chaser[]; orbs: number[]; power?: PowerKind; px?: number; bomb?: number }
const S = (index: number, kind: Kind, o: Partial<Seg> = {}): Seg => ({ index, kind, x: 0, w: 0, lanes: [], bikes: [], chasers: [], orbs: [0], ...o });
const INITIAL: Seg[] = [
  S(0, 'open'), S(1, 'open', { orbs: [-2, 2], power: 'shield', px: 0 }), S(2, 'hurdle'), S(3, 'underpass'),
  S(4, 'barrier', { x: -2, w: 5, orbs: [2.5] }), S(5, 'oncoming', { lanes: [-3, 3], bikes: [false, false], bomb: 0 }),
  S(6, 'ambush', { chasers: [{ x: 0, type: 'robber' }], orbs: [0, 0] }),
];
export function rng(seed: number) { let a = seed >>> 0; return () => { a = (a + 0x6d2b79f5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
const half = C.trackW / 2;
const W: [Kind, number, number][] = [['open', 10, 0], ['barrier', 12, 0], ['hurdle', 12, 0], ['underpass', 10, 0], ['oncoming', 16, 5], ['ambush', 10, 7], ['chasm', 8, 8], ['police', 10, 9], ['patrol', 8, 12], ['gridlock', 7, 14]];
function kindFromP(p: number, index: number): Kind {
  const a = W.filter(w => index >= w[2]); let x = p * a.reduce((s, w) => s + w[1], 0);
  for (const w of a) if ((x -= w[1]) < 0) return w[0];
  return 'open';
}
export function pickKind(index: number, seed: number): Kind {
  return index < INITIAL.length ? INITIAL[index].kind : kindFromP(rng(seed ^ Math.imul(index, 2654435761))(), index);
}
/** Hurdles/chasms need a jump, underpasses a slide, gridlock a jump or a bomb; the rest need steering room. */
export function isPassable(s: Seg): boolean {
  switch (s.kind) {
    case 'barrier': return Math.max(s.x - s.w / 2 + half, half - (s.x + s.w / 2)) >= C.minFree;
    case 'police': return isPassable({ ...s, kind: 'barrier' }) && isPassable({ ...s, kind: 'barrier', x: -s.x });
    case 'oncoming': return new Set(s.lanes).size <= 2;
    case 'ambush': case 'patrol': return s.chasers.length <= 2;
    default: return true;
  }
}
export function generateSegment(index: number, seed: number): Seg {
  if (index < INITIAL.length) return INITIAL[index];
  const r = rng(seed ^ Math.imul(index, 2654435761)); const kind = kindFromP(r(), index), diff = Math.min(1, index / 40), side = r() < .5 ? -1 : 1;
  let s = S(index, kind, { orbs: [-side * 2.5] });
  if (kind === 'barrier') s = { ...s, x: side * 2.2 * r(), w: 3.5 + diff * 1.5 };
  else if (kind === 'police') s = { ...s, x: side * 1.8, w: 4.4 };
  else if (kind === 'chasm') s = { ...s, orbs: [0, 0, 0] };
  else if (kind === 'oncoming') {
    const all = [-3, 0, 3], a = Math.floor(r() * 3), lanes = [all[a]];
    if (r() < .4 + diff * .3) lanes.push(all[(a + 1 + Math.floor(r() * 2)) % 3]);
    s = { ...s, lanes, bikes: lanes.map(() => r() < .4) };
  } else if (kind === 'gridlock') s = { ...s, lanes: [-3.3, 0, 3.3], bikes: [false, false, false], orbs: [] };
  else if (kind === 'ambush') { const ch: Chaser[] = [{ x: (r() - .5) * 5, type: 'robber' }]; if (diff > .3 && r() < .5) ch.push({ x: -ch[0].x || 2, type: 'robber' }); s = { ...s, chasers: ch, orbs: [0, 0] }; }
  else if (kind === 'patrol') s = { ...s, chasers: [{ x: side * 2, type: 'cop' }] };
  let out = isPassable(s) ? s : S(index, 'open');
  if (index >= 5 && r() < .25) out = { ...out, power: PK[Math.floor(r() * 4)], px: (r() - .5) * 5 };
  if (index % 25 === 12) out = { ...out, power: 'bank', px: 0 };
  if (pickKind(index + 1, seed) === 'gridlock') out = { ...out, bomb: 0 }; else if (index >= 8 && r() < .12) out = { ...out, bomb: (r() - .5) * 5 };
  return out;
}
export const pruneSegments = <T extends { index: number }>(l: T[], playerD: number): T[] =>
  l.filter(s => (s.index + 1) * C.segLen > playerD - C.behind * C.segLen);
export const speedAt = (d: number) => Math.min(C.speedMax, C.speed0 + d / 180);
export function steerVx(vx: number, dir: number, dt: number, p: { acc?: number; maxLat?: number; damp?: number; accMul?: number; wind?: number } = {}): number {
  const acc = (p.acc ?? C.latAcc) * (p.accMul ?? 1);
  const n = (dir ? vx + dir * acc * dt * (Math.sign(vx) === -dir ? C.reverseBoost : 1) : vx * Math.exp(-(p.damp ?? C.latDamp) * dt)) + (p.wind ?? 0) * dt;
  const m = p.maxLat ?? C.maxLat; return Math.max(-m, Math.min(m, n));
}

export const SWIPE_PX = 36;
export function swipeDir(dx: number, dy: number): 'jump' | 'slide' | null {
  if (Math.abs(dy) < SWIPE_PX || Math.abs(dy) < Math.abs(dx) * 1.2) return null;
  return dy < 0 ? 'jump' : 'slide';
}
export interface Tap { t: number; x: number; y: number }
export const isDoubleTap = (a: Tap | null, b: Tap) => !!a && b.t - a.t > 0 && b.t - a.t < 320 && Math.hypot(b.x - a.x, b.y - a.y) < 80;
export const keysFor = (orbs: number) => Math.floor(orbs / 10);

export type Msg = { t: 'go'; seed: number } | { t: 'pos'; x: number; y: number; z: number; s: number; d: number; a: boolean } | { t: 'dead'; s: number; d: number };
const fin = (v: unknown, lo: number, hi: number): v is number => typeof v === 'number' && Number.isFinite(v) && v >= lo && v <= hi;
/** Messages from the other player are untrusted: validate and clamp before use. */
export function parseMsg(m: unknown): Msg | null {
  if (!m || typeof m !== 'object') return null; const o = m as Record<string, unknown>;
  if (o.t === 'go' && fin(o.seed, 0, 2 ** 31)) return { t: 'go', seed: Math.floor(o.seed) };
  if (o.t === 'pos' && fin(o.x, -20, 20) && fin(o.y, -50, 50) && fin(o.z, -1e7, 10) && fin(o.s, 0, 1e8) && fin(o.d, 0, 1e7) && typeof o.a === 'boolean') return { t: 'pos', x: o.x, y: o.y, z: o.z, s: Math.floor(o.s), d: Math.floor(o.d), a: o.a };
  if (o.t === 'dead' && fin(o.s, 0, 1e8) && fin(o.d, 0, 1e7)) return { t: 'dead', s: Math.floor(o.s), d: Math.floor(o.d) };
  return null;
}
export const duelWinner = (me: number, opp: number): 'me' | 'opp' | 'draw' => (me > opp ? 'me' : me < opp ? 'opp' : 'draw');
const ROOM_CHARS = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
export const roomCode = (rand: () => number = Math.random) => Array.from({ length: 6 }, () => ROOM_CHARS[Math.floor(rand() * ROOM_CHARS.length)]).join('');
export const parseRoom = (hash: string): string | null => /^#room=([A-HJ-NP-Z2-9]{6})$/i.exec(hash)?.[1]?.toUpperCase() ?? null;

/** Cash carried is exposed to robbers; banked cash is safe. */
export const carried = (r: Run) => Math.max(0, cashOf(r) - r.banked);
export function bank(r: Run): number { const c = carried(r); r.banked += c; return c; }

export type MissionId = 'coins' | 'kos' | 'dist' | 'bombs' | 'bank';
export interface Mission { id: MissionId; target: number; progress: number; done: boolean }
export interface MissionState { d: number; items: Mission[] }
export interface RunStats { coins: number; kos: number; dist: number; bombs: number; banks: number }
const MPOOL: [MissionId, number[]][] = [['coins', [40, 60, 80]], ['kos', [2, 3, 4]], ['dist', [1500, 2500, 3500]], ['bombs', [2, 3]], ['bank', [1, 2]]];
export const MISSION_TEXT: Record<MissionId, string> = { coins: 'Collect coins', kos: 'Knock out robbers', dist: 'Run in one go (m)', bombs: 'Throw bombs', bank: 'Bank your cash' };
export function missionsFor(day: number): MissionState {
  const r = rng(day * 31 + 7), pool = [...MPOOL], items: Mission[] = [];
  while (items.length < 3) { const [id, ts] = pool.splice(Math.floor(r() * pool.length), 1)[0]; items.push({ id, target: ts[Math.floor(r() * ts.length)], progress: 0, done: false }); }
  return { d: day, items };
}
export function applyRun(m: MissionState, s: RunStats): { state: MissionState; newlyDone: number } {
  let newlyDone = 0;
  const items = m.items.map(i => {
    if (i.done) return i;
    const v = i.id === 'coins' ? s.coins : i.id === 'kos' ? s.kos : i.id === 'bombs' ? s.bombs : i.id === 'bank' ? s.banks : s.dist;
    const progress = Math.min(i.target, i.id === 'dist' ? Math.max(i.progress, v) : i.progress + v), done = progress >= i.target;
    if (done) newlyDone++; return { ...i, progress, done };
  });
  return { state: { ...m, items }, newlyDone };
}
const MKEY = 'ravixelo.missions.v1';
export function loadMissions(s: Pick<Storage, 'getItem'>, day: number): MissionState {
  try {
    const o = JSON.parse(s.getItem(MKEY) ?? 'null');
    if (o && o.d === day && Array.isArray(o.items) && o.items.length === 3 && o.items.every((i: Mission) => MISSION_TEXT[i.id] && Number.isFinite(i.target) && Number.isFinite(i.progress) && typeof i.done === 'boolean')) return o as MissionState;
  } catch { /* corrupted */ }
  return missionsFor(day);
}
export const saveMissions = (s: Pick<Storage, 'setItem'>, m: MissionState) => { try { s.setItem(MKEY, JSON.stringify(m)); } catch { /* quota */ } };
