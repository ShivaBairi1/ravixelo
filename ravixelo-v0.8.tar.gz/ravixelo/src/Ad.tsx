import { useEffect } from 'react';
import { ADBREAK_TEST, ADSENSE_CLIENT, ADSENSE_SLOT, REWARD_DEMO } from './config';
import { isNative } from './platform';
let loaded = false;
type W = { adsbygoogle?: unknown[]; adBreak?: (o: unknown) => void; adConfig?: (o: unknown) => void };
// AdSense is for websites only; Google does not allow it inside apps (the Android build uses AdMob via ads.ts).
const valid = () => !isNative() && /^ca-pub-\d+$/.test(ADSENSE_CLIENT);
/** Loads the AdSense script once (only if configured) and defines the H5 Games Ads adBreak/adConfig shims. */
export function ensureAdScript() {
  if (loaded || !valid()) return; loaded = true;
  const w = window as unknown as W; const q = (w.adsbygoogle = w.adsbygoogle || []);
  w.adBreak = w.adConfig = (o: unknown) => { q.push(o); };
  const s = document.createElement('script'); s.async = true; s.crossOrigin = 'anonymous'; s.src = `https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=${ADSENSE_CLIENT}`;
  if (ADBREAK_TEST) s.setAttribute('data-adbreak-test', 'on');
  document.head.appendChild(s);
}
export const realRewardedAvailable = () => typeof (window as unknown as W).adBreak === 'function';
export const rewardedAvailable = () => realRewardedAvailable() || REWARD_DEMO;
/** Resolves true only if the player actually watched the rewarded ad. */
export function showRewarded(): Promise<boolean> {
  return new Promise(res => {
    const w = window as unknown as W; if (!w.adBreak) return res(false);
    let ok = false; let done = false; const fin = () => { if (!done) { done = true; res(ok); } };
    try { w.adBreak({ type: 'reward', name: 'revive', beforeReward: (show: () => void) => show(), adViewed: () => { ok = true; }, adDismissed: () => { ok = false; }, adBreakDone: fin }); } catch { fin(); }
    setTimeout(fin, 60000);
  });
}
/** Banner unit for menu / game-over screens only; renders nothing unless configured. */
export function Ad() {
  const on = valid() && !!ADSENSE_SLOT;
  useEffect(() => {
    if (!on) return; ensureAdScript();
    try { const w = window as unknown as W; (w.adsbygoogle = w.adsbygoogle || []).push({}); } catch { /* ad blocked */ }
  }, [on]);
  if (!on) return null;
  return <ins className="adsbygoogle" style={{ display: 'block', width: '100%', maxWidth: 320, minHeight: 50, marginTop: 8 }} data-ad-client={ADSENSE_CLIENT} data-ad-slot={ADSENSE_SLOT} data-ad-format="horizontal" />;
}
