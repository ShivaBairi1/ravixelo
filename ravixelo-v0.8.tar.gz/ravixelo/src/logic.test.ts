import { describe, it, expect } from 'vitest';
import * as L from './logic';
const mem = (v?: string) => { let s = v; return { getItem: () => s ?? null, setItem: (_: string, x: string) => { s = x; } }; };
describe('scoring', () => {
  it('distance + orbs, no duplicates', () => {
    const r = L.createRun(); L.addDistance(r, 100.9); expect(L.score(r)).toBe(100);
    expect(L.collectOrb(r, 'a')).toBe(true); expect(L.collectOrb(r, 'a')).toBe(false); expect(L.score(r)).toBe(125);
    L.addDistance(r, 50); expect(r.distance).toBe(100.9);
  });
});
describe('state machine', () => {
  it('transitions, pause/resume, retry', () => {
    let s = L.transition('ready', 'play'); expect(s).toBe('playing');
    s = L.transition(s, 'pause'); expect(s).toBe('paused'); expect(L.transition(s, 'die')).toBe('paused');
    s = L.transition(s, 'resume'); s = L.transition(s, 'die'); expect(s).toBe('over'); expect(L.transition(s, 'retry')).toBe('playing');
  });
  it('restart gives a fresh run', () => { const a = L.createRun(); L.collectOrb(a, 'x'); const b = L.createRun(); expect(b).toEqual({ distance: 0, orbs: 0, bonus: 0, stolen: 0, banked: 0, collected: new Set() }); });
});
describe('storage', () => {
  it('persists best', () => { const m = mem(); const { store, record } = L.submitScore(L.loadStore(m), 50); expect(record).toBe(true); L.saveStore(m, store); expect(L.loadStore(m).best).toBe(50); expect(L.submitScore(store, 40).record).toBe(false); });
  it.each(['not json', '{"best":-3,"sound":5}', '{"best":"x"}', 'null', '[]'])('invalid %s -> safe defaults', v => { expect(L.loadStore(mem(v))).toEqual(L.defaultStore()); });
});
describe('track', () => {
  it('initial segments deterministic regardless of seed', () => { for (let i = 0; i < 5; i++) expect(L.generateSegment(i, 1)).toEqual(L.generateSegment(i, 999)); });
  it('same seed => same segments; all passable', () => { for (let i = 5; i < 300; i++) { const s = L.generateSegment(i, 42); expect(s).toEqual(L.generateSegment(i, 42)); expect(L.isPassable(s)).toBe(true); } });
  it('rejects impassable segment', () => { expect(L.isPassable({ index: 9, kind: 'barrier', x: 0, w: 9, lanes: [], bikes: [], chasers: [], orbs: [] })).toBe(false); });
  it('prunes old segments', () => { const l = Array.from({ length: 10 }, (_, index) => ({ index })); const k = L.pruneSegments(l, 5 * 24); expect(k[0].index).toBe(3); expect(k.length).toBe(7); });
});
describe('progression', () => {
  it('levels, speed, combo, daily seed, unlocks, wind, zones, theft', () => {
    expect(L.levelAt(0)).toBe(1); expect(L.levelAt(400)).toBe(2); expect(L.speedAt(1e6)).toBe(17); expect(L.speedAt(400)).toBeGreaterThan(L.speedAt(0));
    const r = L.createRun(); L.collectOrb(r, 'o', 3); expect(L.score(r)).toBe(75); r.stolen = 30; expect(L.score(r)).toBe(45); r.stolen = 999; expect(L.score(r)).toBe(0);
    expect(L.dailySeed(new Date(Date.UTC(2026, 9, 26)))).toBe(20261026);
    const s = L.defaultStore(); const v = L.submitScore(s, 90, 20261026); expect(v.record).toBe(true); expect(v.store.best).toBe(0); expect(L.submitScore(v.store, 80, 20261026).record).toBe(false); expect(L.submitScore(v.store, 80, 20261027).record).toBe(true);
    expect(L.unlocked({ unlock: 400 } as never, { ...s, best: 400 })).toBe(true); expect(L.unlocked({ unlock: 400 } as never, s)).toBe(false);
    expect(L.steerVx(0, 0, 1, { wind: 2 })).toBe(2);
    expect(L.zoneIndex(0)).toBe(0); expect(L.zoneIndex(1499)).toBe(0); expect(L.zoneIndex(1500)).toBe(1); expect(L.zoneIndex(6000)).toBe(2); expect(L.zoneNo(1500 + 4500 * 5)).toBe(6); expect(L.zoneIndex(1500 + 4500 * 5)).toBe(1);
  });
  it('passability rules', () => {
    const b = { index: 9, kind: 'barrier' as const, x: 1.8, w: 4.4, lanes: [], bikes: [], chasers: [], orbs: [] };
    expect(L.isPassable(b)).toBe(true); expect(L.isPassable({ ...b, w: 8 })).toBe(false);
    expect(L.isPassable({ ...b, kind: 'police' })).toBe(true); expect(L.isPassable({ ...b, kind: 'police', w: 8 })).toBe(false);
    expect(L.isPassable({ ...b, kind: 'oncoming', lanes: [-3, 0] })).toBe(true); expect(L.isPassable({ ...b, kind: 'oncoming', lanes: [-3, 0, 3] })).toBe(false);
    expect(L.isPassable({ ...b, kind: 'ambush', chasers: [{ x: 0, type: 'robber' }, { x: 1, type: 'robber' }, { x: 2, type: 'robber' }] })).toBe(false);
  });
  it('tutorial order and gridlock always preceded by a bomb', () => {
    expect(L.generateSegment(1, 5).power).toBe('shield');
    expect([2, 3, 4, 5, 6].map(i => L.generateSegment(i, 3).kind)).toEqual(['hurdle', 'underpass', 'barrier', 'oncoming', 'ambush']);
    let g = 0; const kinds = new Set<string>();
    for (let seed = 1; seed < 20; seed++) for (let i = 7; i < 200; i++) { const s = L.generateSegment(i, seed); kinds.add(s.kind); if (s.kind === 'gridlock') { g++; expect(L.generateSegment(i - 1, seed).bomb).toBe(0); } }
    expect(g).toBeGreaterThan(0); expect(kinds.size).toBe(10);
  });
});

describe('touch gestures', () => {
  it('swipe up jumps, down slides, short or sideways moves do nothing', () => {
    expect(L.swipeDir(0, -60)).toBe('jump'); expect(L.swipeDir(5, 60)).toBe('slide'); expect(L.swipeDir(0, -20)).toBeNull(); expect(L.swipeDir(80, -50)).toBeNull();
  });
  it('double tap needs two close, quick taps', () => {
    const a = { t: 1000, x: 100, y: 100 }; expect(L.isDoubleTap(null, a)).toBe(false);
    expect(L.isDoubleTap(a, { t: 1200, x: 120, y: 110 })).toBe(true); expect(L.isDoubleTap(a, { t: 1400, x: 100, y: 100 })).toBe(false); expect(L.isDoubleTap(a, { t: 1200, x: 300, y: 100 })).toBe(false);
  });
});

describe('keys and view settings', () => {
  it('keys earned from coins; store validates keys and fpv', () => {
    expect(L.keysFor(0)).toBe(0); expect(L.keysFor(25)).toBe(2);
    expect(L.loadStore(mem('{"keys":7,"fpv":true}'))).toMatchObject({ keys: 7, fpv: true });
    expect(L.loadStore(mem('{"keys":-2,"fpv":"yes"}'))).toMatchObject({ keys: 0, fpv: false });
    expect(L.loadStore(mem('{"keys":99999}')).keys).toBe(999);
  });
});

describe('duel messages', () => {
  it('validates untrusted peer messages', () => {
    expect(L.parseMsg({ t: 'go', seed: 5.7 })).toEqual({ t: 'go', seed: 5 }); expect(L.parseMsg({ t: 'go', seed: -1 })).toBeNull(); expect(L.parseMsg(null)).toBeNull(); expect(L.parseMsg('x')).toBeNull();
    expect(L.parseMsg({ t: 'pos', x: 1, y: 0.5, z: -30, s: 10, d: 5, a: true })).not.toBeNull(); expect(L.parseMsg({ t: 'pos', x: 999, y: 0, z: 0, s: 1, d: 1, a: true })).toBeNull(); expect(L.parseMsg({ t: 'pos', x: 1, y: 0, z: 0, s: NaN, d: 1, a: true })).toBeNull();
    expect(L.parseMsg({ t: 'dead', s: 12, d: 3 })).toEqual({ t: 'dead', s: 12, d: 3 }); expect(L.parseMsg({ t: 'evil' })).toBeNull();
  });
  it('winner, room codes and invite links', () => {
    expect(L.duelWinner(5, 3)).toBe('me'); expect(L.duelWinner(3, 5)).toBe('opp'); expect(L.duelWinner(4, 4)).toBe('draw');
    expect(L.roomCode(() => 0)).toBe('AAAAAA'); expect(L.roomCode()).toMatch(/^[A-HJ-NP-Z2-9]{6}$/);
    expect(L.parseRoom('#room=abc234')).toBe('ABC234'); expect(L.parseRoom('#room=ABCO12')).toBeNull(); expect(L.parseRoom('')).toBeNull();
  });
});

describe('bank it or lose it', () => {
  it('banking protects cash from theft', () => {
    const r = L.createRun(); L.collectOrb(r, 'a'); L.collectOrb(r, 'b'); expect(L.carried(r)).toBe(50); expect(L.bank(r)).toBe(50); expect(L.carried(r)).toBe(0);
    L.collectOrb(r, 'c'); expect(L.carried(r)).toBe(25); r.stolen += 12; expect(L.carried(r)).toBe(13); expect(L.score(r)).toBe(63);
  });
  it('vault every 25 segments, deterministic', () => { expect(L.generateSegment(12, 9).power).toBe('bank'); expect(L.generateSegment(37, 9).power).toBe('bank'); expect(L.generateSegment(37, 9)).toEqual(L.generateSegment(37, 9)); });
});
describe('daily missions', () => {
  it('3 distinct missions per day, progress, rewards once, corrupted storage', () => {
    const m = L.missionsFor(20261028); expect(m.items).toHaveLength(3); expect(new Set(m.items.map(i => i.id)).size).toBe(3); expect(L.missionsFor(20261028)).toEqual(m);
    const big = { coins: 999, kos: 999, dist: 99999, bombs: 99, banks: 99 }; const a = L.applyRun(m, big); expect(a.newlyDone).toBe(3); expect(L.applyRun(a.state, big).newlyDone).toBe(0);
    const mem2 = (v?: string) => ({ getItem: () => v ?? null }); expect(L.loadMissions(mem2('garbage'), 5).d).toBe(5); expect(L.loadMissions(mem2(JSON.stringify(m)), 20261028)).toEqual(m); expect(L.loadMissions(mem2(JSON.stringify(m)), 20261029).d).toBe(20261029);
  });
});
