import * as THREE from 'three';
import RAPIER from '@dimforge/rapier3d-compat';
import { C, MAX_REVIVES, VEHICLES, Vehicle, VehicleId, ZONES } from './config';
import { Seg, Run, PowerKind, createRun, addDistance, collectOrb, score, cashOf, generateSegment, pruneSegments, speedAt, steerVx, levelAt, windAt, dailySeed, zoneIndex, rng, carried, bank, GameState, transition } from './logic';

export interface Hud { score: number; dist: number; orbs: number; level: number; shield: number; ghost: number; dbl: number; calm: number; combo: number; bombs: number; zone: string; chase: boolean; carried: number; banked: number }
export interface Result { score: number; distance: number; orbs: number; level: number; seed: number; daily: boolean; reason: string; zone: string; stolen: number; revives: number; canRevive: boolean; kos: number; bombs: number; banks: number }
export interface Hooks { onHud(h: Hud): void; onMsg(t: string): void; onOver(r: Result): void; onPause(): void }
interface Haz { m: THREE.Object3D; pos: THREE.Vector3; h: [number, number, number]; b?: RAPIER.RigidBody; c?: RAPIER.Collider; vz?: number; start: number; z0: number; hi?: boolean; label: string; broken: boolean; near: boolean; minD: number }
interface Pick { m: THREE.Mesh; p: THREE.Vector3; id: string; taken: boolean; kind?: PowerKind }
interface Rig { g: THREE.Group; torso: THREE.Group; aU: THREE.Object3D[]; aL: THREE.Object3D[]; tU: THREE.Object3D[]; tL: THREE.Object3D[] }
interface Chs { g: THREE.Group; rig: Rig; type: 'robber' | 'cop'; x: number; z: number; down: boolean; ph: number; act: boolean }
interface SegObj { seg: Seg; group: THREE.Group; bodies: RAPIER.RigidBody[]; haz: Haz[]; pk: Pick[]; chs: Chs[] }
const FOOT = .96;
const PWC: Record<PowerKind, number> = { shield: 0x38e1ff, ghost: 0xb388ff, double: 0x7dff6b, calm: 0xffffff, bomb: 0xff3030, bank: 0x7aa2ff };
const PWT: Record<PowerKind, string> = { shield: 'Shield +1 life', ghost: 'Ghost: pass through anything!', double: 'Double points!', calm: 'Calm: no penalties!', bomb: 'Bomb! Press B or tap Bomb to clear the road', bank: 'Vault! Your cash is banked: robbers cannot take it' };

export class Game {
  state: GameState = 'ready'; muted = false; reducedMotion = matchMedia('(prefers-reduced-motion: reduce)').matches;
  private r: THREE.WebGLRenderer; private scene = new THREE.Scene(); private cam = new THREE.PerspectiveCamera(65, 1, .1, 200);
  private world!: RAPIER.World; private ball!: RAPIER.RigidBody; private segs = new Map<number, SegObj>(); private run: Run = createRun();
  private vehicle: Vehicle = VEHICLES[0]; private daily = false; private seed = 1;
  private veh = new THREE.Group(); private opp!: Rig; private oppOn = false; private oppAlive = true; private oppPh = 0; private oppPos = new THREE.Vector3(); private oppTgt = new THREE.Vector3(); private forcedSeed: number | null = null; private noPause = false; private shadows: THREE.Mesh[] = [];
  private circ = new THREE.CircleGeometry(.6, 16).rotateX(-Math.PI / 2); private shm = new THREE.MeshBasicMaterial({ color: 0x000000, transparent: true, opacity: .35, depthWrite: false });
  private kos = 0; private bombsUsed = 0; private banks = 0; private hints = false; private hinted = new Set<number>(); private shake = 0; private beatT = 0; private beatI = 0;
  private lowQ = (navigator.hardwareConcurrency || 4) <= 4 || ((navigator as unknown as { deviceMemory?: number }).deviceMemory ?? 8) <= 4;
  private runner: Rig | null = null; private cop!: Rig; private copPh = 0; private fpv = false; private stumbleT = 0; private slowT = 0; private gap = 6; private cx = 0; private revives = 0; private lastGroundZ = -4; private wheels: THREE.Mesh[] = []; private vGeos: THREE.BufferGeometry[] = []; private wr = .3; private foot = .9; private bubble!: THREE.Mesh; private ph = 0;
  private level = 1; private zone = 0; private shield = 0; private ghost = 0; private dbl = 0; private calm = 0; private inv = 0; private combo = 0; private bombs = 0; private lastOrb = -9; private lastRob = -99; private lastHud = 0; private ghostLook = false; private reason = '';
  private jump = false; private slideReq = false; private punchReq = false; private bombReq = false; private slideT = 0; private punchT = 0; private punchCd = 0; private blastT = 0;
  private px = 0; private bumpT = -1; private dir = 0; private acc = 0; private last = 0; private t = 0; private raf = 0; private ro: ResizeObserver; private ac?: AudioContext;
  private ub = new THREE.BoxGeometry(1, 1, 1); private sph = new THREE.SphereGeometry(.5, 14, 14); private cone = new THREE.ConeGeometry(.5, 1, 10); private cyl = new THREE.CylinderGeometry(.5, .5, 1, 10);
  private coinG = new THREE.CylinderGeometry(.35, .35, .08, 16).rotateX(Math.PI / 2); private octa = new THREE.OctahedronGeometry(.5);
  private mc = new Map<string, THREE.MeshStandardMaterial>(); private polR = new THREE.MeshStandardMaterial({ color: 0xff2030, emissive: 0xff2030 }); private polB = new THREE.MeshStandardMaterial({ color: 0x2060ff, emissive: 0x2060ff });
  private bub = new THREE.MeshStandardMaterial({ color: 0x38e1ff, emissive: 0x38e1ff, transparent: true, opacity: .25, depthWrite: false });
  private blastM = new THREE.MeshBasicMaterial({ color: 0xffa040, transparent: true, opacity: 0 }); private blast = new THREE.Mesh(this.sph, this.blastM);
  private ground!: THREE.Mesh; private gmat = new THREE.MeshStandardMaterial({ color: ZONES[0].ground }); private tSky = new THREE.Color(); private tGnd = new THREE.Color();
  private pv = new Float32Array(80 * 3); private pl = new Float32Array(80); private pp = new Float32Array(80 * 3); private pCol = new Float32Array(80 * 3); private pi = 0;
  private pGeo = new THREE.BufferGeometry(); private pMat = new THREE.PointsMaterial({ size: .22, vertexColors: true, transparent: true, depthWrite: false });

  static async create(canvas: HTMLCanvasElement, hooks: Hooks) { await RAPIER.init(); return new Game(canvas, hooks); }
  private constructor(private canvas: HTMLCanvasElement, private hooks: Hooks) {
    this.r = new THREE.WebGLRenderer({ canvas, antialias: true });
    this.scene.background = new THREE.Color(ZONES[0].sky); this.scene.fog = new THREE.Fog(ZONES[0].sky, 20, 80);
    this.scene.add(new THREE.AmbientLight(0x9aa8d0, .9)); const L = new THREE.DirectionalLight(0xffffff, 1.3); L.position.set(4, 10, 6); this.scene.add(L);
    this.ground = new THREE.Mesh(new THREE.PlaneGeometry(500, 500).rotateX(-Math.PI / 2), this.gmat); this.ground.position.y = -3.2; this.scene.add(this.ground);
    this.blast.visible = false; this.scene.add(this.blast);
    this.pp.fill(-100); this.pGeo.setAttribute('position', new THREE.BufferAttribute(this.pp, 3)); this.pGeo.setAttribute('color', new THREE.BufferAttribute(this.pCol, 3));
    const pts = new THREE.Points(this.pGeo, this.pMat); pts.frustumCulled = false; this.scene.add(pts); this.scene.add(this.veh);
    this.cop = this.rig(0x1d3f9a, 0x142a5e, false, 0x10204a, true, false); this.scene.add(this.cop.g);
    this.opp = this.rig(0xd6336c, 0x222233, false, 0x2b2b2b, true, true); this.opp.g.visible = false; this.scene.add(this.opp.g);
    const mark = new THREE.Mesh(this.cone, this.mat(0xd6336c, 0xd6336c)); mark.scale.set(.5, .6, .5); mark.rotation.x = Math.PI; mark.position.set(0, 1.5, 0); this.opp.torso.add(mark);
    for (let i = 0; i < 3; i++) { const sh = new THREE.Mesh(this.circ, this.shm); sh.renderOrder = 1; this.scene.add(sh); this.shadows.push(sh); }
    this.scene.add(new THREE.HemisphereLight(0xaac8ff, 0x202030, .7));
    this.ro = new ResizeObserver(() => this.resize()); this.ro.observe(canvas.parentElement!);
    document.addEventListener('visibilitychange', this.onVis);
    this.reset(); this.resize(); this.raf = requestAnimationFrame(this.frame);
  }
  private onVis = () => { if (document.hidden && this.state === 'playing' && !this.noPause) { this.pause(); this.hooks.onPause(); } };
  private resize() {
    const p = this.canvas.parentElement!, w = p.clientWidth, h = p.clientHeight;
    this.r.setPixelRatio(Math.min(devicePixelRatio, this.lowQ ? 1.5 : 2)); this.r.setSize(w, h, false);
    this.cam.aspect = w / h; this.cam.fov = w / h < 1 ? 80 : 65; this.cam.updateProjectionMatrix();
  }
  setHints(b: boolean) { this.hints = b; } private vib(ms: number) { if (!this.muted) navigator.vibrate?.(ms); }
  setFpv(b: boolean) { this.fpv = b; } setNoPause(b: boolean) { this.noPause = b; }
  setSeed(n: number | null) { if (this.state === 'playing' || this.state === 'paused') return; this.forcedSeed = n; this.reset(); }
  setOpponent(s: { x: number; y: number; z: number; a: boolean } | null) {
    if (!s) { this.oppOn = false; this.opp.g.visible = false; return; }
    this.oppTgt.set(s.x, s.y, s.z); this.oppAlive = s.a; if (!this.oppOn) { this.oppOn = true; this.oppPos.copy(this.oppTgt); } this.opp.g.visible = true;
  }
  getSnapshot() { const p = this.ball.translation(); return { x: p.x, y: p.y, z: p.z, s: score(this.run), d: Math.floor(this.run.distance), a: this.state === 'playing' }; }
  revive(): boolean {
    if (this.state !== 'over' || this.revives >= MAX_REVIVES) return false;
    const p = this.ball.translation(), v = this.vehicle; let z = p.z;
    if (p.y < -1) { z = this.lastGroundZ; for (const s of this.segs.values()) { const z0 = -s.seg.index * C.segLen; if (s.seg.kind === 'chasm' && p.z <= z0 && p.z > z0 - C.segLen) z = z0 - 16; } }
    this.ball.setTranslation({ x: 0, y: v.r + .2, z }, true); this.ball.setLinvel({ x: 0, y: 0, z: 0 }, true);
    for (const s of this.segs.values()) { for (const h of s.haz) if (Math.abs(h.pos.z - z) < 30) { h.broken = true; h.m.visible = false; } for (const c of s.chs) if (!c.down && Math.abs(c.z - z) < 30) this.knock(c); }
    this.revives++; this.inv = 3; this.stumbleT = C.stumbleTime; this.reason = ''; this.dir = 0; this.state = transition('over', 'retry'); this.last = 0; this.acc = 0; this.emitHud(0, true); return true;
  }
  setDir(d: number) { this.dir = d; } setMuted(m: boolean) { this.muted = m; }
  doJump() { if (this.state === 'playing') this.jump = true; } doSlide() { if (this.state === 'playing') this.slideReq = true; }
  doPunch() { if (this.state === 'playing') this.punchReq = true; } doBomb() { if (this.state === 'playing') this.bombReq = true; }
  setVehicle(id: VehicleId) { if (this.state === 'playing' || this.state === 'paused') return; this.vehicle = VEHICLES.find(v => v.id === id) ?? VEHICLES[0]; this.reset(); }
  setMode(daily: boolean) { if (this.state === 'playing' || this.state === 'paused') return; this.daily = daily; this.reset(); }
  toMenu() { this.state = 'ready'; this.reset(); }
  start() { this.sfx(0, 0); if (this.state === 'over') this.reset(); this.state = transition(this.state === 'over' ? 'ready' : this.state, 'play'); this.last = 0; this.acc = 0; }
  pause() { this.state = transition(this.state, 'pause'); this.dir = 0; }
  resume() { this.state = transition(this.state, 'resume'); this.last = 0; this.acc = 0; }

  private mat(c: number, e = 0, t = false) { const k = `${c}:${e}:${t}`; let m = this.mc.get(k); if (!m) { m = new THREE.MeshStandardMaterial({ color: c, emissive: e, roughness: .65, transparent: t }); this.mc.set(k, m); } return m; }
  private bx(par: THREE.Object3D, mat: THREE.Material, sx: number, sy: number, sz: number, x: number, y: number, z: number) { const m = new THREE.Mesh(this.ub, mat); m.scale.set(sx, sy, sz); m.position.set(x, y, z); par.add(m); return m; }
  private limb(par: THREE.Object3D, mat: THREE.Material, w: number, h: number, x: number, y: number) { const p = new THREE.Group(); p.position.set(x, y, 0); this.bx(p, mat, w, h, w, 0, -h / 2, 0); par.add(p); return p; }
  private gc = new Map<string, THREE.BufferGeometry>();
  private cap(r: number, len: number) { const k = `${r}:${len}`; let g = this.gc.get(k); if (!g) { g = new THREE.CapsuleGeometry(r, len, 4, 10); this.gc.set(k, g); } return g; }
  /** Original stylized 3D character built from rounded primitives (hoodie, cap, face, backpack, sneakers). */
  private rig(shirt: number, pants: number, t: boolean, hair: number, cap: boolean, bag: boolean): Rig {
    const g = new THREE.Group(), torso = new THREE.Group(); g.add(torso); g.scale.setScalar(.85);
    const sm = this.mat(shirt, 0, t), pm = this.mat(pants, 0, t), sk = this.mat(0xe8b88e, 0, t), shoe = this.mat(0xf4f4f4, 0, t), dk = this.mat(0x151515, 0, t), cp = this.mat(hair, 0, t), wh = this.mat(0xffffff, 0, t);
    const P = (par: THREE.Object3D, geo: THREE.BufferGeometry, mat: THREE.Material, x: number, y: number, z: number, sx = 1, sy = 1, sz = 1) => { const m = new THREE.Mesh(geo, mat); m.position.set(x, y, z); m.scale.set(sx, sy, sz); par.add(m); return m; };
    P(torso, this.cap(.25, .16), sm, 0, .22, 0, 1.05, 1, .78); P(torso, this.cap(.23, .06), pm, 0, -.14, 0, 1, 1, .8); this.bx(torso, dk, .5, .06, .4, 0, -.01, 0);
    P(torso, this.cap(.07, .04), sk, 0, .56, 0); P(torso, this.sph, sk, 0, .8, 0, .4, .44, .42);
    for (const sx of [-1, 1]) { P(torso, this.sph, wh, sx * .075, .83, -.17, .07, .08, .04); P(torso, this.sph, dk, sx * .075, .83, -.19, .035, .045, .02); this.bx(torso, dk, .08, .016, .02, sx * .075, .9, -.18); }
    P(torso, this.sph, this.mat(0xd9a07a, 0, t), 0, .78, -.19, .05, .05, .05); this.bx(torso, this.mat(0x8a3a3a, 0, t), .07, .015, .02, 0, .72, -.18);
    P(torso, this.sph, cp, 0, .9, .02, .43, .3, .46); if (cap) this.bx(torso, cp, .3, .03, .24, 0, .87, -.2);
    if (bag) { P(torso, this.cap(.14, .1), this.mat(0xd9a520, 0, t), 0, .22, .27, 1, 1, .7); for (const sx of [-1, 1]) this.bx(torso, this.mat(0x8a6a10, 0, t), .04, .5, .03, sx * .13, .22, -.17); }
    const mk = (par: THREE.Object3D, geo: THREE.BufferGeometry, mat: THREE.Material, len: number, x: number, y: number) => { const p = new THREE.Group(); p.position.set(x, y, 0); P(p, geo, mat, 0, -len / 2, 0); par.add(p); return p; };
    const aU: THREE.Object3D[] = [], aL: THREE.Object3D[] = [], tU: THREE.Object3D[] = [], tL: THREE.Object3D[] = [];
    for (const sx of [-1, 1]) {
      const u = mk(torso, this.cap(.075, .2), sm, .35, sx * .33, .46); aU.push(u); const l = mk(u, this.cap(.065, .18), sk, .31, 0, -.35); aL.push(l); P(l, this.sph, dk, 0, -.33, 0, .15, .15, .15);
      const th = mk(g, this.cap(.1, .2), pm, .4, sx * .13, -.28); tU.push(th); const sh = mk(th, this.cap(.085, .18), pm, .35, 0, -.4); tL.push(sh);
      P(sh, this.sph, shoe, 0, -.36, -.06, .26, .16, .44); this.bx(sh, dk, .22, .04, .38, 0, -.43, -.06);
    }
    return { g, torso, aU, aL, tU, tL };
  }
  /** Procedural run / jump / slide / punch pose. Positive x-rotation swings a limb forward (toward -z). */
  private animRig(r: Rig, ph: number, run: boolean, air: boolean, slide: boolean, punch: boolean) {
    for (let i = 0; i < 2; i++) {
      const a = ph + i * Math.PI;
      if (!run) { r.aU[i].rotation.x = r.aL[i].rotation.x = r.tU[i].rotation.x = r.tL[i].rotation.x = 0; continue; }
      if (slide) { r.tU[i].rotation.x = 1.3; r.tL[i].rotation.x = -.15; r.aU[i].rotation.x = -.5; r.aL[i].rotation.x = .2; }
      else if (air) { r.tU[i].rotation.x = i ? 1.1 : .4; r.tL[i].rotation.x = i ? -1.3 : -.6; r.aU[i].rotation.x = i ? -1.7 : -1.1; r.aL[i].rotation.x = .5; }
      else { r.tU[i].rotation.x = Math.sin(a) * .95; r.tL[i].rotation.x = -Math.max(0, -Math.cos(a)) * 1.2; r.aU[i].rotation.x = -Math.sin(a) * .85; r.aL[i].rotation.x = 1.1; }
    }
    if (punch) { r.aU[0].rotation.x = 1.6; r.aL[0].rotation.x = 0; }
    r.torso.rotation.x = !run ? 0 : slide ? 1.0 : air ? -.1 : -.18;
    r.g.position.y = 0;
  }
  private buildVeh() {
    this.veh.clear(); this.vGeos.forEach(g => g.dispose()); this.vGeos = []; this.wheels = []; this.runner = null;
    const v = this.vehicle, t = true, body = this.mat(0x2ab8ff, 0x06304a, t), dark = this.mat(0x0a1626, 0, t), acc = this.mat(0x9be8ff, 0, t); this.foot = v.id === 'ball' ? FOOT : v.r;
    const add = (g: THREE.BufferGeometry, mat: THREE.Material, x: number, y: number, z: number) => { this.vGeos.push(g); const me = new THREE.Mesh(g, mat); me.position.set(x, y, z); this.veh.add(me); return me; };
    const wheel = (rad: number, w: number, x: number, y: number, z: number) => { const g = new THREE.CylinderGeometry(rad, rad, w, 16); g.rotateZ(Math.PI / 2); this.wheels.push(add(g, dark, x, y, z)); this.wr = rad; };
    if (v.id === 'ball') { this.runner = this.rig(0x2a8fe0, 0x1f2a44, t, 0xd02a2a, true, true); this.veh.add(this.runner.g); }
    else if (v.id === 'bike') { wheel(.28, .08, 0, -.1, -.45); wheel(.28, .08, 0, -.1, .45); add(new THREE.BoxGeometry(.12, .16, .95), body, 0, .02, 0); add(new THREE.SphereGeometry(.17, 12, 12), acc, 0, .3, .05); }
    else { for (const sx of [-.55, .55]) for (const sz of [-.55, .55]) wheel(.3, .16, sx, -.3, sz); add(new THREE.BoxGeometry(1, .34, 1.8), body, 0, -.05, 0); add(new THREE.BoxGeometry(.8, .3, .8), acc, 0, .26, .1); }
    this.bubble = add(new THREE.SphereGeometry(v.r * 1.7, 16, 16), this.bub, 0, 0, 0);
  }
  private reset() {
    this.segs.forEach(s => this.dropSeg(s)); this.segs.clear(); this.world?.free(); const v = this.vehicle;
    this.world = new RAPIER.World({ x: 0, y: -C.gravity, z: 0 }); this.world.timestep = C.fixedDt;
    this.run = createRun(); this.seed = this.forcedSeed ?? (this.daily ? dailySeed() : (Math.random() * 1e9) | 0); this.dir = 0; this.t = 0; this.acc = 0; this.pl.fill(0);
    this.jump = this.slideReq = this.punchReq = this.bombReq = false; this.slideT = this.punchT = this.punchCd = this.blastT = 0; this.blast.visible = false; this.reason = '';
    this.kos = this.bombsUsed = this.banks = 0; this.hinted.clear(); this.shake = 0; this.stumbleT = this.slowT = 0; this.gap = C.chaseFar; this.cx = 0; this.revives = 0; this.lastGroundZ = -C.startD; this.level = 1; this.zone = 0; this.shield = v.shield; this.bombs = 0; this.ghost = this.dbl = this.calm = this.inv = this.combo = 0; this.lastOrb = -9; this.lastRob = -99;
    (this.scene.background as THREE.Color).set(ZONES[0].sky); (this.scene.fog as THREE.Fog).color.set(ZONES[0].sky); this.gmat.color.set(ZONES[0].ground);
    this.ball = this.world.createRigidBody(RAPIER.RigidBodyDesc.dynamic().setTranslation(0, v.r + .1, -C.startD).setCcdEnabled(true).setAngularDamping(.2));
    this.world.createCollider(RAPIER.ColliderDesc.ball(v.r).setRestitution(.3).setFriction(1), this.ball);
    this.buildVeh(); this.ensureSegs(0); this.emitHud(0, true);
  }
  private solid(o: SegObj, mat: THREE.Material, x: number, y: number, z: number, h: [number, number, number], rest = .3) {
    this.bx(o.group, mat, h[0] * 2, h[1] * 2, h[2] * 2, x, y, z);
    const b = this.world.createRigidBody(RAPIER.RigidBodyDesc.fixed().setTranslation(x, y, z)); this.world.createCollider(RAPIER.ColliderDesc.cuboid(...h).setRestitution(rest).setFriction(1), b); o.bodies.push(b);
  }
  private addHaz(o: SegObj, g: THREE.Object3D, x: number, y: number, z: number, h: [number, number, number], label: string, opt: { phys?: boolean; vz?: number; hi?: boolean } = {}) {
    g.position.set(x, y, z); o.group.add(g); let b: RAPIER.RigidBody | undefined, c: RAPIER.Collider | undefined;
    if (opt.phys !== false) { b = this.world.createRigidBody(opt.vz ? RAPIER.RigidBodyDesc.kinematicPositionBased().setTranslation(x, y, z) : RAPIER.RigidBodyDesc.fixed().setTranslation(x, y, z)); c = this.world.createCollider(RAPIER.ColliderDesc.cuboid(...h).setRestitution(.3).setFriction(1), b); o.bodies.push(b); }
    o.haz.push({ m: g, pos: new THREE.Vector3(x, y, z), h, b, c, vz: opt.vz, start: -1, z0: z, hi: opt.hi, label, broken: false, near: false, minD: 99 });
  }
  private car(wd: number, color: number, police: boolean) {
    const g = new THREE.Group(), t = true;
    this.bx(g, this.mat(color, 0, t), wd, .8, 4.2, 0, -.25, 0); this.bx(g, this.mat(police ? 0x1a2a6a : 0x223344, 0, t), wd * .85, .5, 2.2, 0, .45, -.2);
    for (const sx of [-1, 1]) { this.bx(g, this.mat(0x111111, 0, t), .3, .5, .8, sx * (wd / 2), -.45, -1.4); this.bx(g, this.mat(0x111111, 0, t), .3, .5, .8, sx * (wd / 2), -.45, 1.4); this.bx(g, this.mat(0xffffcc, 0xffffaa, t), .4, .2, .1, sx * wd * .32, -.3, 2.1); this.bx(g, this.mat(0xaa0000, 0x660000, t), .4, .2, .1, sx * wd * .32, -.3, -2.1); }
    if (police) { this.bx(g, this.mat(0x1a2a6a, 0, t), wd + .02, .2, 4.22, 0, -.25, 0); this.bx(g, this.polR, .5, .2, .4, -.35, .8, -.2); this.bx(g, this.polB, .5, .2, .4, .35, .8, -.2); }
    return g;
  }
  private bike() { const g = new THREE.Group(), t = true; this.bx(g, this.mat(0x333344, 0, t), .35, .6, 1.6, 0, -.2, 0); this.bx(g, this.mat(0xc0392b, 0, t), .45, .6, .4, 0, .25, -.1); const h = new THREE.Mesh(this.sph, this.mat(0x222222, 0, t)); h.scale.setScalar(.3); h.position.set(0, .65, -.1); g.add(h); this.bx(g, this.mat(0xffffcc, 0xffffaa, t), .2, .2, .1, 0, -.1, .85); return g; }
  private chaser(o: SegObj, type: 'robber' | 'cop', x: number, z: number) {
    const rg = type === 'cop' ? this.rig(0x1d3f9a, 0x142a5e, false, 0x10204a, true, false) : this.rig(0x2b2b2b, 0x3a3a3a, false, 0x151515, false, false);
    if (type === 'robber') this.bx(rg.torso, this.mat(0xc0392b), .4, .12, .4, 0, .66, -.02);
    rg.g.rotation.y = Math.PI; rg.g.position.set(x, FOOT, z); o.group.add(rg.g); o.chs.push({ g: rg.g, rig: rg, type, x, z, down: false, ph: 0, act: false });
  }
  private build(seg: Seg) {
    const L = C.segLen, z0 = -seg.index * L, zc = z0 - L / 2, hw = C.trackW / 2, o: SegObj = { seg, group: new THREE.Group(), bodies: [], haz: [], pk: [], chs: [] };
    const road = this.mat(0x2b2f3a), rail = this.mat(0xbfc7d5, 0x202a35), lvl = this.level, k = seg.kind;
    if (k === 'chasm') { this.solid(o, road, 0, -.5, z0 - 4.75, [hw, .5, 4.75]); this.solid(o, road, 0, -.5, z0 - L + 4.75, [hw, .5, 4.75]); this.bx(o.group, this.mat(0xffd000, 0x886600), hw * 2, .05, .6, 0, .03, z0 - 9.2); this.bx(o.group, this.mat(0xffd000, 0x886600), hw * 2, .05, .6, 0, .03, z0 - 14.8); }
    else this.solid(o, road, 0, -.5, zc, [hw, .5, L / 2]);
    for (const s of [-1, 1]) { this.solid(o, rail, s * (hw + .25), .5, zc, [.25, .75, L / 2], .5); for (const zz of [3, 9, 15, 21]) this.bx(o.group, this.mat(0xffffff, 0x333333), .12, .02, 2.2, s * 1.7, .01, z0 - zz); }
    this.bx(o.group, this.mat(0x555b66), 1, 3, 1, -4, -1.7, zc); this.bx(o.group, this.mat(0x555b66), 1, 3, 1, 4, -1.7, zc);
    if (k === 'barrier') { const g = new THREE.Group(); this.bx(g, this.mat(0xff6a2b, 0x5a1800, true), seg.w, 1.5, .8, 0, 0, 0); this.bx(g, this.mat(0xffffff, 0x444444, true), seg.w, .25, .82, 0, .3, 0); this.addHaz(o, g, seg.x, .75, z0 - 12, [seg.w / 2, .75, .4], 'a roadblock'); }
    if (k === 'hurdle') { const g = new THREE.Group(); this.bx(g, this.mat(0xffd000, 0x554400, true), hw * 2, .7, .4, 0, 0, 0); for (const sx of [-3, -1, 1, 3]) this.bx(g, this.mat(0x111111, 0, true), .8, .72, .42, sx, 0, 0); this.addHaz(o, g, 0, .35, z0 - 12, [hw, .35, .25], 'a barrier you needed to jump'); }
    if (k === 'underpass') { const g = new THREE.Group(); this.bx(g, this.mat(0x6b7280), 10.6, .9, 3, 0, 0, 0); this.bx(g, this.mat(0xffd000, 0x886600), 10.6, .15, .1, 0, -.35, 1.52); this.addHaz(o, g, 0, 1.05, z0 - 12, [5.3, .45, 1.5], 'a low underpass (slide!)', { phys: false, hi: true }); for (const sx of [-5.9, 5.9]) this.bx(o.group, this.mat(0x6b7280), 1, 6, 3, sx, 1.3, z0 - 12); }
    if (k === 'chasm') { this.bx(o.group, this.mat(0x0b1a2a), hw * 2, .1, 4.6, 0, -2.5, z0 - 12); this.bx(o.group, this.mat(0xffd000, 0x886600), 1.4, 1.4, .2, -4.2, 1.4, z0 - 8.5); }
    if (k === 'oncoming') seg.lanes.forEach((lx, i) => { const b = seg.bikes[i]; const g = b ? this.bike() : this.car(2, [0xc9d1da, 0x8a2be2, 0x2e8b57, 0xd4af37][(seg.index + i) % 4], false); this.addHaz(o, g, lx, b ? .6 : .7, z0 - 20, b ? [.4, .6, .9] : [1, .7, 2.1], b ? 'an oncoming bike' : 'oncoming traffic', { vz: b ? 8 + lvl * .5 : 5.5 + lvl * .4 }); });
    if (k === 'gridlock') seg.lanes.forEach((lx, i) => this.addHaz(o, this.car(2.6, [0xc9d1da, 0x8a2be2, 0x2e8b57][i], false), lx, .7, z0 - 12, [1.3, .7, 2.2], 'a traffic jam'));
    if (k === 'police') for (const [sx, zz] of [[seg.x, 7], [-seg.x, 17]]) { const g = new THREE.Group(); g.add(this.car(2.1, 0xf2f2f2, true).translateX(-1.1), this.car(2.1, 0xf2f2f2, true).translateX(1.1)); this.addHaz(o, g, sx, .7, z0 - zz, [2.2, .7, 2.2], 'a police roadblock'); }
    for (const c of seg.chasers) this.chaser(o, k === 'patrol' ? 'cop' : 'robber', c.x, z0 - 15);
    const pick = (x: number, z: number, id: string, kind?: PowerKind) => { const m = new THREE.Mesh(kind === 'bomb' ? this.sph : kind ? this.octa : this.coinG, kind ? this.mat(PWC[kind], PWC[kind]) : this.mat(0xffd23f, 0xb38600)); if (kind === 'bomb') m.scale.setScalar(.8); const p = new THREE.Vector3(x, 1, z); m.position.copy(p); o.group.add(m); o.pk.push({ m, p, id, taken: false, kind }); };
    seg.orbs.forEach((x, i) => pick(x, z0 - 6 - i * 3, `${seg.index}:${i}`));
    if (seg.power) pick(seg.px ?? 0, z0 - 3, `${seg.index}:p`, seg.power);
    if (seg.bomb !== undefined) pick(seg.bomb, z0 - 5, `${seg.index}:b`, 'bomb');
    this.scenery(o, seg, z0); this.scene.add(o.group); this.segs.set(seg.index, o);
  }
  private scenery(o: SegObj, seg: Seg, z0: number) {
    const zi = zoneIndex(seg.index * C.segLen), Z = ZONES[zi], r = rng(seg.index * 7919 + zi), gy = -3.2, g = o.group;
    for (const side of [-1, 1]) for (let k = 0; k < (this.lowQ ? 2 : 4); k++) {
      const z = z0 - k * 6 - 1 - r() * 4, x = side * (8 + r() * 7), pc = Z.props[Math.floor(r() * 3)], pm = this.mat(pc, (pc >> 1) & 0x7f7f7f & 0x1f1f1f);
      if (Z.kind === 'towers') { const w = 3 + r() * 3, h = 8 + r() * 20; this.bx(g, pm, w, h, w, x, gy + h / 2, z); this.bx(g, this.mat(Z.glow, Z.glow), w + .1, .3, w + .1, x, gy + h * (.4 + r() * .5), z); }
      else if (Z.kind === 'old') { const h = 3 + r() * 3; this.bx(g, pm, 4, h, 4, x, gy + h / 2, z); if (r() < .5) { const c = new THREE.Mesh(this.cone, this.mat(0x7a2f22)); c.scale.set(4.6, 2.2, 4.6); c.position.set(x, gy + h + 1.1, z); g.add(c); } else { const d = new THREE.Mesh(this.sph, this.mat(0xd9c9a0)); d.scale.setScalar(3.4); d.position.set(x, gy + h, z); g.add(d); } this.bx(g, this.mat(Z.glow, Z.glow), .3, .3, .3, side * 6.5, gy + 4, z); }
      else if (Z.kind === 'desert') { if (r() < .55) { const c = new THREE.Mesh(this.cyl, this.mat(0x3f8f3a)); c.scale.set(.8, 3.5, .8); c.position.set(x, gy + 1.75, z); g.add(c); this.bx(g, this.mat(0x3f8f3a), 1.4, .6, .6, x + .8, gy + 2.2, z); } else { const h = 4 + r() * 6; this.bx(g, pm, 6 + r() * 4, h, 6, x, gy + h / 2, z); } }
      else if (Z.kind === 'harbor') { this.bx(g, pm, 2.4, 2.6, 6, x, gy + 1.3, z); if (r() < .6) this.bx(g, this.mat(Z.props[(k + 1) % 3]), 2.4, 2.6, 6, x, gy + 3.9, z); if (k === 0) { this.bx(g, this.mat(0xe8b73a), .6, 16, .6, x, gy + 8, z); this.bx(g, this.mat(0xe8b73a), .6, .6, 10, x, gy + 16, z - 3); } }
      else { const tr = new THREE.Mesh(this.cyl, this.mat(0x5a3b22)); tr.scale.set(.6, 2, .6); tr.position.set(x, gy + 1, z); g.add(tr); const c = new THREE.Mesh(this.cone, pm); c.scale.set(4, 6, 4); c.position.set(x, gy + 5, z); g.add(c); const cap = new THREE.Mesh(this.cone, this.mat(0xffffff)); cap.scale.set(1.8, 2, 1.8); cap.position.set(x, gy + 7.6, z); g.add(cap); }
    }
    if (seg.index % 9 === 4 && seg.kind !== 'chasm') { const zc = z0 - 12; for (const sx of [-5.8, 5.8]) this.bx(g, this.mat(0xd24b3a), .5, 9, .5, sx, 4.5, zc); this.bx(g, this.mat(0xd24b3a, 0x330000), 12, .6, .5, 0, 9, zc); this.bx(g, this.mat(0xffffff, 0xffffff), 12, .1, .1, 0, 8.6, zc); }
  }
  private dropSeg(o: SegObj) { this.scene.remove(o.group); if (this.world) o.bodies.forEach(b => this.world.removeRigidBody(b)); o.bodies.length = 0; }
  private ensureSegs(d: number) {
    const cur = Math.floor(d / C.segLen);
    for (let i = Math.max(0, cur - C.behind); i <= cur + C.ahead; i++) if (!this.segs.has(i)) this.build(generateSegment(i, this.seed));
    const keep = new Set(pruneSegments([...this.segs.values()].map(s => s.seg), d).map(s => s.index));
    for (const [i, o] of this.segs) if (!keep.has(i)) { this.dropSeg(o); this.segs.delete(i); }
  }
  private burst(x: number, y: number, z: number, hex: number, n: number) {
    if (this.reducedMotion) return; const c = new THREE.Color(hex);
    for (let k = 0; k < n; k++) { const i = this.pi++ % 80; this.pp.set([x, y, z], i * 3); this.pv.set([(Math.random() - .5) * 6, Math.random() * 4, (Math.random() - .5) * 6], i * 3); this.pl[i] = .6; this.pCol.set([c.r, c.g, c.b], i * 3); }
  }
  private updP(dt: number) {
    for (let i = 0; i < 80; i++) { if (this.pl[i] > 0) { this.pl[i] -= dt; for (let a = 0; a < 3; a++) this.pp[i * 3 + a] += this.pv[i * 3 + a] * dt; this.pv[i * 3 + 1] -= 9 * dt; } else this.pp[i * 3 + 1] = -100; }
    (this.pGeo.attributes.position as THREE.BufferAttribute).needsUpdate = true; (this.pGeo.attributes.color as THREE.BufferAttribute).needsUpdate = true;
  }
  private knock(c: Chs) { c.down = true; c.g.rotation.set(-Math.PI / 2, Math.PI, 0); c.g.position.y = .25; c.act = false; }
  private punch(p: { x: number; z: number }) {
    this.sfx(250, .08, 'square');
    for (const s of this.segs.values()) for (const c of s.chs) if (!c.down && c.type === 'robber' && p.z - c.z > -1 && p.z - c.z < 4.5 && Math.abs(p.x - c.x) < 2.4) { this.knock(c); this.run.bonus += 30; this.kos++; this.vib(30); this.burst(c.x, 1, c.z, 0xffd23f, 12); this.hooks.onMsg('Robber down! +$30'); }
  }
  private explode(p: { x: number; z: number }) {
    const cx = p.x, cz = p.z - 13; this.blast.position.set(cx, 1, cz); this.blast.visible = true; this.blastT = .5; this.bombsUsed++; this.shake = .6; this.vib(80); let n = 0;
    for (const s of this.segs.values()) {
      for (const h of s.haz) if (!h.broken && Math.abs(h.pos.z - cz) < 9 && Math.abs(h.pos.x - cx) < 9) { h.broken = true; h.m.visible = false; this.run.bonus += 15; n++; }
      for (const c of s.chs) if (!c.down && Math.abs(c.z - cz) < 9 && Math.abs(c.x - cx) < 9) { this.knock(c); n++; }
    }
    this.burst(cx, 1, cz, 0xff8a2b, 40); this.sfx(90, .5, 'sawtooth'); this.hooks.onMsg(n ? `BOOM! Cleared ${n} obstacles` : 'BOOM!');
  }
  private step(dt: number) {
    const v = this.vehicle, lv = this.ball.linvel(), p = this.ball.translation(), d = Math.max(0, -p.z - C.startD), sp = speedAt(d) * (this.slowT > 0 ? .6 : 1), calm = this.calm > 0, L = this.level;
    const vx = steerVx(lv.x, this.dir, dt, { acc: v.acc, maxLat: v.maxLat, damp: !calm && L >= 3 ? v.damp * .4 : v.damp, accMul: !calm && L >= 7 ? 1.25 : 1, wind: !calm && L >= 5 ? windAt(this.t, L) : 0 });
    const grounded = p.y < v.r + .12 && Math.abs(lv.y) < .5; let vy = lv.y;
    if (this.jump && grounded) { vy = 5.5; this.sfx(520, .06); } this.jump = false;
    if (this.slideReq && grounded && this.slideT <= 0) this.slideT = .7; this.slideReq = false;
    if (this.punchReq && this.punchCd <= 0) { this.punchCd = .5; this.punchT = .25; this.punch(p); } this.punchReq = false;
    if (this.bombReq && this.bombs > 0) { this.bombs--; this.explode(p); } this.bombReq = false;
    this.px = vx; this.ball.setLinvel({ x: vx, y: vy, z: -sp }, true); this.ball.setAngvel({ x: 0, y: 0, z: 0 }, true);
    this.t += dt; for (const k of ['ghost', 'dbl', 'calm', 'inv', 'slideT', 'punchT', 'punchCd', 'stumbleT', 'slowT'] as const) this[k] = Math.max(0, this[k] - dt);
    if (this.t - this.lastOrb > 2.2) this.combo = 0;
    const gh = this.ghost > 0 || this.inv > 0;
    for (const s of this.segs.values()) {
      for (const h of s.haz) {
        if (h.c) { const want = gh || h.broken; if (h.c.isSensor() !== want) h.c.setSensor(want); }
        if (h.vz && !h.broken) { if (h.start < 0 && p.z - h.z0 < 55) h.start = this.t; if (h.start >= 0) { h.pos.z = h.z0 + h.vz * (this.t - h.start); h.b?.setNextKinematicTranslation({ x: h.pos.x, y: h.pos.y, z: h.pos.z }); } }
      }
      for (const c of s.chs) if (!c.down) { const dz = p.z - c.z; c.act = dz > -1 && dz < 30; if (c.act) { const spd = (c.type === 'cop' ? 2 : 2.6) + L * .25; c.x += Math.max(-spd * dt, Math.min(spd * dt, p.x - c.x)); c.ph += dt * 10; } }
    }
    this.world.step();
    const nv = this.ball.linvel().x; if (Math.abs(nv - this.px) > 2.5 && this.t - this.bumpT > .2) { this.bumpT = this.t; this.sfx(200, .07, 'square'); const q = this.ball.translation(); this.burst(q.x, q.y, q.z, 0x38e1ff, 6); }
  }
  private stumble(x: number, y: number, z: number) { this.shake = .5; this.vib(120); this.stumbleT = C.stumbleTime; this.slowT = .7; this.inv = 1.2; this.burst(x, y, z, 0xff6a2b, 25); this.sfx(150, .3, 'sawtooth'); this.hooks.onMsg('Stumbled! The inspector is right behind you!'); }
  private die(why: string) { this.reason = why; }
  private check() {
    const v = this.vehicle, p = this.ball.translation(), d = -p.z - C.startD; addDistance(this.run, d);
    this.ensureSegs(Math.max(0, -p.z));
    const lvl = levelAt(d), zi = zoneIndex(d);
    if (lvl > this.level) { this.level = lvl; this.run.bonus += 50 * (lvl - 1); this.sfx(660, .2); this.hooks.onMsg(`LEVEL ${lvl} — faster!` + (lvl === 3 ? ' Slippery roads!' : lvl === 5 ? ' Crosswinds!' : lvl === 7 ? ' Twitchy steering!' : '')); }
    if (this.hints) {
      const idx = Math.floor(-p.z / C.segLen), off = (-p.z) % C.segLen, H: Record<number, string> = { 2: 'Swipe UP (or W) to jump the barrier!', 3: 'Swipe DOWN (or S) to slide under!', 4: 'Steer around the roadblock', 5: 'Oncoming traffic! Weave, and grab the bomb', 6: 'Robber! Double-tap (or F) to punch him, or jump him' };
      if (off > 3 && !this.hinted.has(idx)) { const h = H[idx] ?? (idx % 25 === 12 ? 'Blue vault ahead: bank your cash so robbers cannot steal it!' : ''); this.hinted.add(idx); if (h) this.hooks.onMsg(h); }
    }
    if (zi !== this.zone) { this.zone = zi; this.hooks.onMsg(`Entering ${ZONES[zi].name}`); }
    const bp = new THREE.Vector3(p.x, p.y, p.z), gh = this.ghost > 0 || this.inv > 0; if (p.y < v.r + .25 && Math.abs(this.ball.linvel().y) < 1) this.lastGroundZ = p.z; let dead = p.y < C.fallY; if (dead) this.die('Fell off the road');
    for (const s of this.segs.values()) {
      for (const h of s.haz) {
        if (h.broken || gh || (h.hi && this.slideT > 0)) continue;
        const dx = Math.max(Math.abs(p.x - h.pos.x) - h.h[0], 0), dy = Math.max(Math.abs(p.y - h.pos.y) - h.h[1], 0), dz = Math.max(Math.abs(p.z - h.pos.z) - h.h[2], 0), dist = Math.hypot(dx, dy, dz);
        if (dist < v.r + .06) {
          if (this.shield > 0) { this.shield--; this.inv = 1.6; h.broken = true; h.m.visible = false; this.burst(h.pos.x, h.pos.y, h.pos.z, 0xff6a2b, 25); this.sfx(300, .15, 'square'); this.hooks.onMsg('Shield absorbed the hit!'); } else if (this.stumbleT <= 0) { this.stumble(h.pos.x, h.pos.y, h.pos.z); h.broken = true; h.m.visible = false; } else { dead = true; this.die(`Caught by the inspector after ${h.label}`); }
        } else { h.minD = Math.min(h.minD, dist); if (!h.near && !h.hi && p.z < h.pos.z - h.h[2] - v.r && h.minD < v.r + .75) { h.near = true; const b = 10 * (this.dbl > 0 ? 2 : 1); this.run.bonus += b; this.hooks.onMsg(`Close call +$${b}`); } }
      }
      for (const c of s.chs) {
        if (c.down || gh || p.y > 1.5 || Math.abs(p.z - c.z) > .9 || Math.abs(p.x - c.x) > .8 + v.r * .4) continue;
        if (c.type === 'cop') { if (this.shield > 0) { this.shield--; this.inv = 1.6; this.knock(c); this.hooks.onMsg('Shield stopped the officer!'); } else if (this.stumbleT <= 0) { this.stumble(c.x, 1, c.z); this.knock(c); } else { dead = true; this.die('Caught by the inspector'); } }
        else if (this.shield > 0) { this.shield--; this.inv = 1.6; this.knock(c); this.hooks.onMsg('Shield stopped the robber!'); }
        else { this.knock(c); const take = Math.floor(carried(this.run) * .5); this.vib(60); this.run.stolen += take; this.burst(c.x, 1, c.z, 0xffd23f, 16); this.sfx(180, .25, 'sawtooth'); this.hooks.onMsg(`Robbed! -$${take}. Punch or jump them!`); if (this.t - this.lastRob < 6) { dead = true; this.die('Mugged by the gang'); } this.lastRob = this.t; this.inv = 1; }
      }
      for (const q of s.pk) {
        if (q.taken || q.p.distanceTo(bp) > v.r + (q.kind ? .7 : .45)) continue;
        q.taken = true; q.m.visible = false;
        if (q.kind) { if (q.kind === 'shield') this.shield = Math.min(3, this.shield + 1); else if (q.kind === 'ghost') this.ghost = 6; else if (q.kind === 'double') this.dbl = 10; else if (q.kind === 'calm') this.calm = 8; else if (q.kind === 'bank') { bank(this.run); this.banks++; } else this.bombs = Math.min(3, this.bombs + 1); this.burst(q.p.x, q.p.y, q.p.z, PWC[q.kind], 14); this.sfx(660, .15); this.hooks.onMsg(PWT[q.kind]); }
        else { this.combo = this.t - this.lastOrb < 2.2 ? this.combo + 1 : 1; this.lastOrb = this.t; if (collectOrb(this.run, q.id, Math.min(this.combo, 4) * (this.dbl > 0 ? 2 : 1))) { this.sfx(700 + this.combo * 60, .08); this.burst(q.p.x, q.p.y, q.p.z, 0xffd23f, 10); } }
      }
    }
    if (dead) { this.state = transition(this.state, 'die'); this.dir = 0; this.sfx(120, .35, 'sawtooth'); this.vib(200); this.shake = .6; this.burst(p.x, p.y, p.z, 0xff6a2b, 40); this.emitHud(0, true); this.hooks.onOver({ score: score(this.run), distance: Math.floor(this.run.distance), orbs: this.run.orbs, level: this.level, seed: this.seed, daily: this.daily, reason: this.reason, zone: ZONES[this.zone].name, stolen: this.run.stolen, revives: this.revives, canRevive: this.revives < MAX_REVIVES, kos: this.kos, bombs: this.bombsUsed, banks: this.banks }); }
  }
  private emitHud(now: number, force = false) {
    if (!force && now - this.lastHud < 70) return; this.lastHud = now;
    this.hooks.onHud({ score: score(this.run), dist: Math.floor(this.run.distance), orbs: this.run.orbs, level: this.level, shield: this.shield, ghost: Math.ceil(this.ghost), dbl: Math.ceil(this.dbl), calm: Math.ceil(this.calm), combo: this.combo, bombs: this.bombs, zone: ZONES[this.zone].name, chase: this.stumbleT > 0, carried: carried(this.run), banked: this.run.banked });
  }
  sfx(f: number, dur: number, type: OscillatorType = 'sine', vol = .08) {
    try {
      this.ac ??= new AudioContext(); if (!f || this.muted) return;
      const o = this.ac.createOscillator(), g = this.ac.createGain(); o.type = type; o.frequency.value = f; g.gain.value = vol;
      g.gain.exponentialRampToValueAtTime(.001, this.ac.currentTime + dur); o.connect(g).connect(this.ac.destination); o.start(); o.stop(this.ac.currentTime + dur);
    } catch { /* audio unavailable */ }
  }
  private frame = (now: number) => {
    this.raf = requestAnimationFrame(this.frame);
    const dt = this.last ? Math.min((now - this.last) / 1000, .1) : 0; this.last = now;
    if (this.state === 'playing') {
      this.acc += dt; let n = 0;
      while (this.acc >= C.fixedDt && n++ < C.maxSteps && this.state === 'playing') { this.step(C.fixedDt); this.acc -= C.fixedDt; this.check(); }
      if (n > C.maxSteps) this.acc = 0; this.emitHud(now);
    }
    this.updP(dt);
    if (this.state === 'playing' && !this.muted) { this.beatT += dt; const len = 60 / (100 + this.level * 8) / 2; if (this.beatT >= len) { this.beatT -= len; this.sfx([55, 55, 82, 55, 73, 55, 98, 73][this.beatI++ % 8], len * 1.6, 'triangle', .05); } }
    const p = this.ball.translation(), vx = this.ball.linvel().x, gh = this.ghost > 0 || this.inv > 0, sl = this.slideT > 0, run = this.state === 'playing', air = p.y > this.vehicle.r + .3, sp = speedAt(this.run.distance);
    const rs = this.runner ? 1 : (sl ? .55 : 1), bob = this.runner && run && !air && !sl ? Math.abs(Math.sin(this.ph)) * .07 : 0;
    this.veh.position.set(p.x, p.y + this.foot * rs - this.vehicle.r + bob - (this.runner && sl ? .35 : 0), p.z); this.veh.scale.y = rs; this.veh.rotation.set(0, -vx * .03, -vx * .04); this.veh.visible = !this.fpv;
    this.ph += run ? dt * sp * .75 : 0; this.wheels.forEach(w => { w.rotation.x -= (run ? sp : 0) * dt / this.wr; });
    if (this.runner) this.animRig(this.runner, this.ph, run, air, sl, this.punchT > 0);
    const tgt = this.stumbleT > 0 ? C.chaseNear : C.chaseFar, caught = this.state === 'over' && this.reason.startsWith('Caught');
    this.gap += ((caught ? .9 : tgt) - this.gap) * (1 - Math.exp(-dt * 3)); this.cx += (p.x - this.cx) * (1 - Math.exp(-dt * 5)); this.copPh += run ? dt * sp * .75 + dt * 2 : 0;
    this.cop.g.position.set(this.cx, FOOT + (run ? Math.abs(Math.sin(this.copPh)) * .07 : 0), p.z + this.gap); this.cop.g.visible = !this.fpv; this.animRig(this.cop, this.copPh, run, false, false, false);
    if (this.oppOn) {
      this.oppPos.lerp(this.oppTgt, 1 - Math.exp(-dt * 10)); const al = this.oppAlive; this.oppPh += al ? dt * sp * .75 : 0; this.animRig(this.opp, this.oppPh, al, this.oppPos.y > .9, false, false);
      this.opp.g.rotation.x = al ? 0 : -Math.PI / 2; this.opp.g.position.set(this.oppPos.x, al ? this.oppPos.y - .5 + FOOT : .3, this.oppPos.z);
    }
    const sp3: [number, number, number][] = [[p.x, p.z, Math.max(.4, 1.1 - Math.max(0, p.y - this.vehicle.r) * .3)], [this.cx, p.z + this.gap, 1], [this.oppPos.x, this.oppPos.z, 1]];
    this.shadows.forEach((m, i) => { m.visible = i === 2 ? this.oppOn : i === 0 ? !this.fpv : !this.fpv; m.position.set(sp3[i][0], .04, sp3[i][1]); m.scale.setScalar(sp3[i][2]); });
    this.bubble.visible = this.shield > 0 || (this.inv > 0 && Math.floor(this.t * 10) % 2 === 0);
    if (gh !== this.ghostLook) { this.ghostLook = gh; this.mc.forEach((m, k) => { if (k.endsWith(':true')) m.opacity = gh ? .4 : 1; }); }
    const flash = Math.sin(now / 90) > 0 ? 1 : .15; this.polR.emissiveIntensity = flash; this.polB.emissiveIntensity = 1.15 - flash;
    for (const sg of this.segs.values()) {
      for (const h of sg.haz) if (h.vz) h.m.position.copy(h.pos);
      for (const c of sg.chs) { c.g.position.x = c.x; if (!c.down) this.animRig(c.rig, c.ph, c.act, false, false, false); }
      if (!this.reducedMotion) for (const q of sg.pk) q.m.rotation.y += dt * 3;
    }
    if (this.blastT > 0) { this.blastT -= dt; const k = 1 - this.blastT / .5; this.blast.scale.setScalar(2 + k * 16); this.blastM.opacity = Math.max(0, this.blastT * 1.4); if (this.blastT <= 0) this.blast.visible = false; }
    const Z = ZONES[zoneIndex(this.run.distance)], kc = 1 - Math.exp(-dt * 1.5), bg = this.scene.background as THREE.Color;
    this.tSky.set(Z.sky); this.tGnd.set(Z.ground); bg.lerp(this.tSky, kc); (this.scene.fog as THREE.Fog).color.copy(bg); this.gmat.color.lerp(this.tGnd, kc); this.ground.position.z = p.z;
    if (this.fpv) {
      const eye = p.y - this.vehicle.r + (this.runner ? (sl ? .7 : 1.62) : this.vehicle.id === 'bike' ? 1.15 : .95) + (run && !air && !sl ? Math.sin(this.ph * 2) * .035 : 0);
      this.cam.position.set(p.x, eye, p.z - .15); this.cam.fov = (this.canvas.parentElement!.clientWidth < this.canvas.parentElement!.clientHeight ? 85 : 78) + (sp - 10) * .6; this.cam.updateProjectionMatrix();
      this.cam.lookAt(p.x * .97, eye - .25, p.z - 14); this.cam.rotateZ(-vx * .012);
    } else {
      this.cam.fov = this.canvas.parentElement!.clientWidth < this.canvas.parentElement!.clientHeight ? 80 : 65; this.cam.updateProjectionMatrix();
      const k = 1 - Math.exp(-8 * dt); const tx = p.x * .6, ty = p.y + 5, tz = p.z + 8.5;
      this.cam.position.x += (tx - this.cam.position.x) * k; this.cam.position.y += (ty - this.cam.position.y) * k; this.cam.position.z += (tz - this.cam.position.z) * k;
      this.cam.lookAt(p.x * .8, 0.5, p.z - 6);
    }
    if (this.shake > 0) { this.shake -= dt; if (!this.reducedMotion) { this.cam.position.x += (Math.random() - .5) * this.shake * .6; this.cam.position.y += (Math.random() - .5) * this.shake * .6; } }
    this.r.render(this.scene, this.cam);
  };
  dispose() {
    cancelAnimationFrame(this.raf); this.ro.disconnect(); document.removeEventListener('visibilitychange', this.onVis);
    this.segs.forEach(s => this.dropSeg(s)); this.segs.clear(); this.world.free(); this.vGeos.forEach(g => g.dispose());
    this.mc.forEach(m => m.dispose()); [this.polR, this.polB, this.bub, this.blastM, this.gmat, this.pMat, this.shm].forEach(m => m.dispose());
    [this.ub, this.sph, this.cone, this.cyl, this.coinG, this.octa, this.pGeo, this.ground.geometry, this.circ, ...this.gc.values()].forEach(g => g.dispose()); this.r.dispose(); this.ac?.close();
  }
}
