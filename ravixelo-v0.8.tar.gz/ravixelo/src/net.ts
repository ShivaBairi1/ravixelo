import Peer, { DataConnection } from 'peerjs';
import { Msg, parseMsg, roomCode } from './logic';
export const NET_OK = import.meta.env.VITE_NO_NET !== '1';
const PREFIX = 'ravixelo-';
/** Peer-to-peer duel link (WebRTC via the free public PeerJS broker) plus optional voice chat. */
export class DuelNet {
  peer?: Peer; conn?: DataConnection; stream = new MediaStream(); mic = false;
  onMsg: (m: Msg) => void = () => {}; onOpen = () => {}; onClose = () => {}; onAudio: (s: MediaStream) => void = () => {};
  private async getMic() {
    try { this.stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } }); this.mic = true; } catch { this.mic = false; }
  }
  private bind(c: DataConnection) {
    this.conn = c; c.on('open', () => this.onOpen()); c.on('close', () => this.onClose()); c.on('error', () => this.onClose());
    c.on('data', d => { const m = parseMsg(d); if (m) this.onMsg(m); });
  }
  async host(): Promise<string> {
    await this.getMic();
    for (let tries = 0; tries < 4; tries++) {
      const code = roomCode();
      try {
        await new Promise<void>((res, rej) => {
          const p = new Peer(PREFIX + code); this.peer = p; p.on('open', () => res()); p.on('error', e => rej(e));
          p.on('connection', c => { if (this.conn?.open) { c.close(); return; } this.bind(c); });
          p.on('call', call => { call.answer(this.stream); call.on('stream', s => this.onAudio(s)); });
        });
        return code;
      } catch (e) { this.peer?.destroy(); if ((e as { type?: string }).type !== 'unavailable-id') throw e; }
    }
    throw new Error('Could not reserve a room code');
  }
  async join(code: string): Promise<void> {
    await this.getMic();
    await new Promise<void>((res, rej) => {
      const p = new Peer(); this.peer = p; p.on('error', e => rej(e));
      p.on('open', () => {
        const c = p.connect(PREFIX + code.toUpperCase(), { reliable: true }); this.bind(c); c.on('open', () => res());
        const call = p.call(PREFIX + code.toUpperCase(), this.stream); call.on('stream', s => this.onAudio(s));
        setTimeout(() => rej(new Error('Room not found or unreachable')), 15000);
      });
    });
  }
  send(m: Msg) { if (this.conn?.open) this.conn.send(m); }
  setMuted(m: boolean) { this.stream.getAudioTracks().forEach(t => { t.enabled = !m; }); }
  close() { try { this.conn?.close(); this.peer?.destroy(); this.stream.getTracks().forEach(t => t.stop()); } catch { /* already closed */ } }
}
