// Picks the game: Heist (default, also the only mode in the Android app) or the old arcade runner (#runner, website only:
// its 1v1 duels need microphone + WebRTC, which the Android app deliberately does not request).
import { isNative } from './platform';
if (location.hash === '#runner' && !isNative()) await import('./main'); else await import('./heist/heistMain');
export {};
