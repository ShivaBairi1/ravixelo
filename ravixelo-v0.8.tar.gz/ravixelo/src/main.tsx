import { StrictMode, useEffect, useRef, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { BRAND, PAY_LINK, REVIVE_COST, REWARD_DEMO, STORY, VEHICLES } from './config';
import { Game, Hud, Result } from './game';
import { Ad, ensureAdScript, realRewardedAvailable, rewardedAvailable, showRewarded } from './Ad';
import { DuelNet, NET_OK } from './net';
import { duelWinner, parseRoom, applyRun, loadMissions, MISSION_TEXT, saveMissions, MissionState, keysFor, Tap, isDoubleTap, swipeDir, GameState, loadStore, saveStore, submitScore, Store, unlocked, dailySeed } from './logic';

const ZERO: Hud = { score: 0, dist: 0, orbs: 0, level: 1, shield: 0, ghost: 0, dbl: 0, calm: 0, combo: 0, bombs: 0, zone: 'Neon Downtown', chase: false, carried: 0, banked: 0 };
type Duel = { role: 'host' | 'guest'; code: string; linked: boolean; closed: boolean; phase: 'lobby' | 'count' | 'play'; count: number; me: number | null; opp: { d: number; s: number; a: boolean; final: number | null }; muted: boolean; mic: boolean };
type Over = Result & { record: boolean; unlock: string; keysEarned: number };
function App() {
  const cv = useRef<HTMLCanvasElement>(null); const g = useRef<Game | null>(null); const tm = useRef(0); const [miss, setMiss] = useState<MissionState>(() => loadMissions(localStorage, dailySeed())); const missRef = useRef(miss); missRef.current = miss; const missDone = useRef(false); const [missNote, setMissNote] = useState(''); const net = useRef<DuelNet | null>(null); const aud = useRef<HTMLAudioElement>(null); const [duel, setDuel] = useState<Duel | null>(null); const duelRef = useRef<Duel | null>(null); duelRef.current = duel;
  const [duelMenu, setDuelMenu] = useState(false); const [joinCode, setJoinCode] = useState(''); const [derr, setDerr] = useState(''); const [busy, setBusy] = useState(false); const granted = useRef(0); const [adLeft, setAdLeft] = useState<number | null>(null);
  const [st, setSt] = useState<GameState>('ready'); const [hud, setHud] = useState(ZERO);
  const [store, setStore] = useState<Store>(() => loadStore(localStorage)); const storeRef = useRef(store); storeRef.current = store;
  const [over, setOver] = useState<Over | null>(null); const [err, setErr] = useState(''); const [msg, setMsg] = useState(''); const [daily, setDaily] = useState(false); const [shared, setShared] = useState('');
  const put = (n: Store) => { setStore(n); storeRef.current = n; saveStore(localStorage, n); };
  const toggleFpv = () => { const n = { ...storeRef.current, fpv: !storeRef.current.fpv }; put(n); g.current?.setFpv(n.fpv); };
  const doRevive = () => { if (g.current?.revive()) { setOver(null); setSt('playing'); setShared(''); return true; } return false; };
  const useKeys = () => { if (storeRef.current.keys < REVIVE_COST) return; if (doRevive()) put({ ...storeRef.current, keys: storeRef.current.keys - REVIVE_COST }); }; // charge keys only if the revive really happened
  const watchAd = async () => {
    if (realRewardedAvailable()) { setShared('Loading ad...'); const ok = await showRewarded(); setShared(ok ? '' : 'Ad not completed or unavailable'); if (ok) doRevive(); } else if (REWARD_DEMO) setAdLeft(3);
  };
  const buyKeys = () => { if (PAY_LINK) window.open(PAY_LINK, '_blank', 'noopener'); else if (REWARD_DEMO) put({ ...storeRef.current, keys: storeRef.current.keys + 5 }); };
  useEffect(() => { if (adLeft === null) return; if (adLeft <= 0) { setAdLeft(null); doRevive(); return; } const id = setTimeout(() => setAdLeft(adLeft - 1), 1000); return () => clearTimeout(id); }, [adLeft]);
  useEffect(() => {
    ensureAdScript(); let dead = false, game: Game | null = null; const keys = new Set<string>();
    const sync = () => g.current?.setDir((keys.has('r') ? 1 : 0) - (keys.has('l') ? 1 : 0));
    const kd = (e: KeyboardEvent, down: boolean) => {
      const k = e.key.toLowerCase(), m = k === 'arrowleft' || k === 'a' ? 'l' : k === 'arrowright' || k === 'd' ? 'r' : '';
      if (m) { down ? keys.add(m) : keys.delete(m); sync(); e.preventDefault(); }
      if (down && (k === 'arrowup' || k === 'w' || (k === ' ' && g.current?.state === 'playing'))) { g.current?.doJump(); e.preventDefault(); }
      if (down && (k === 'arrowdown' || k === 's')) { g.current?.doSlide(); e.preventDefault(); }
      if (down && (k === 'f' || k === 'j')) g.current?.doPunch();
      if (down && (k === 'b' || k === 'e')) g.current?.doBomb();
      if (down && !e.repeat && k === 'c') toggleFpv();
      if (down && !e.repeat) {
        if (k === 'escape' || k === 'p') toggle();
        else if ((k === ' ' || k === 'enter') && g.current && ['ready', 'over'].includes(g.current.state)) { e.preventDefault(); play(); }
      }
    };
    const down = (e: KeyboardEvent) => kd(e, true), up = (e: KeyboardEvent) => kd(e, false), blur = () => { keys.clear(); sync(); };
    Game.create(cv.current!, {
      onHud: setHud, onPause: () => setSt('paused'),
      onMsg: t => { setMsg(t); clearTimeout(tm.current); tm.current = window.setTimeout(() => setMsg(''), 2200); },
      onOver: r => {
        if (duelRef.current) { net.current?.send({ t: 'dead', s: r.score, d: r.distance }); setDuel(d => d && { ...d, me: r.score }); setSt('over'); setMsg(''); return; }
        const old = storeRef.current, { store: ns, record } = submitScore(old, r.score, r.daily ? r.seed : undefined); const kd = keysFor(r.orbs) - granted.current; let md = 0; if (!missDone.current) { missDone.current = true; const ar = applyRun(missRef.current, { coins: r.orbs, kos: r.kos, dist: r.distance, bombs: r.bombs, banks: r.banks }); setMiss(ar.state); saveMissions(localStorage, ar.state); md = ar.newlyDone; setMissNote(md ? `Mission complete! +${md * 2} keys` : ''); }
        let cur = record ? ns : old; if (md > 0) cur = { ...cur, keys: Math.min(999, cur.keys + md * 2) }; if (kd > 0) { granted.current += kd; cur = { ...cur, keys: Math.min(999, cur.keys + kd) }; } if (record || kd > 0 || md > 0) put(cur); if (record) g.current?.sfx(1200, .3);
        const nu = VEHICLES.filter(v => !unlocked(v, old) && unlocked(v, ns)).map(v => v.name).join(', ');
        setOver({ ...r, record, unlock: nu, keysEarned: Math.max(0, kd) }); setSt('over'); setMsg('');
      },
    }).then(x => { if (dead) x.dispose(); else { game = x; g.current = x; x.setMuted(!storeRef.current.sound); x.setVehicle(storeRef.current.vehicle); x.setFpv(storeRef.current.fpv); x.setHints(storeRef.current.plays < 3); } }).catch(e => setErr(String(e)));
    addEventListener('keydown', down); addEventListener('keyup', up); addEventListener('blur', blur);
    return () => { dead = true; removeEventListener('keydown', down); removeEventListener('keyup', up); removeEventListener('blur', blur); game?.dispose(); g.current = null; };
  }, []);
  const play = () => { granted.current = 0; missDone.current = false; setMissNote(''); g.current?.setHints(storeRef.current.plays < 3); put({ ...storeRef.current, plays: storeRef.current.plays + 1 }); g.current?.start(); setOver(null); setHud(ZERO); setSt('playing'); setShared(''); };
  const toggle = () => { const x = g.current; if (!x || duelRef.current) return; if (x.state === 'playing') { x.pause(); setSt('paused'); } else if (x.state === 'paused') { x.resume(); setSt('playing'); } };
  const side = (e: React.PointerEvent) => { if (st === 'playing') g.current?.setDir(e.clientX < innerWidth / 2 ? -1 : 1); };
  const gest = useRef<{ cur: (Tap & { moved: boolean }) | null; last: Tap | null }>({ cur: null, last: null });
  const stop = () => { g.current?.setDir(0); gest.current.cur = null; };
  const down = (e: React.PointerEvent) => { (e.target as Element).setPointerCapture?.(e.pointerId); side(e); gest.current.cur = { t: performance.now(), x: e.clientX, y: e.clientY, moved: false }; };
  const move = (e: React.PointerEvent) => {
    if (e.buttons) side(e); const c = gest.current.cur; if (!c || st !== 'playing') return;
    const dx = e.clientX - c.x, dy = e.clientY - c.y, sw = swipeDir(dx, dy);
    if (sw) { sw === 'jump' ? g.current?.doJump() : g.current?.doSlide(); c.x = e.clientX; c.y = e.clientY; c.moved = true; } else if (Math.hypot(dx, dy) > 14) c.moved = true;
  };
  const up = () => {
    const c = gest.current.cur; stop();
    if (!c || c.moved || st !== 'playing' || performance.now() - c.t > 250) return;
    if (isDoubleTap(gest.current.last, c)) { g.current?.doPunch(); gest.current.last = null; } else gest.current.last = { t: c.t, x: c.x, y: c.y };
  };
  const mute = () => { const n = { ...store, sound: !store.sound }; put(n); g.current?.setMuted(!n.sound); };
  const pick = (id: typeof VEHICLES[number]['id']) => { put({ ...store, vehicle: id }); g.current?.setVehicle(id); };
  const mode = (d: boolean) => { setDaily(d); g.current?.setMode(d); };
  const share = async () => {
    if (!over) return; const v = VEHICLES.find(x => x.id === store.vehicle)!.name;
    const text = `I scored ${over.score} (${over.distance} m, reached ${over.zone}; ${over.reason}) in ${BRAND} as the ${v}${over.daily ? ` on today's Daily Challenge #${over.seed}` : ''}. Can you beat me?`;
    try { if (navigator.share) { await navigator.share({ text, url: location.href }); setShared('Shared!'); } else { await navigator.clipboard.writeText(`${text} ${location.href}`); setShared('Copied to clipboard!'); } } catch { setShared('Share cancelled'); }
  };
  useEffect(() => { const r = parseRoom(location.hash); if (r) { setJoinCode(r); setDuelMenu(true); } }, []);
  useEffect(() => { if (duel?.phase !== 'play') return; const id = setInterval(() => { const sn = g.current?.getSnapshot(); if (sn) net.current?.send({ t: 'pos', ...sn }); }, 100); return () => clearInterval(id); }, [duel?.phase]);
  useEffect(() => {
    if (duel?.phase !== 'count') return;
    if (duel.count <= 0) { g.current?.start(); setOver(null); setHud(ZERO); setSt('playing'); setDuel(d => d && { ...d, phase: 'play' }); return; }
    const id = setTimeout(() => setDuel(d => d && { ...d, count: d.count - 1 }), 1000); return () => clearTimeout(id);
  }, [duel?.phase, duel?.count]);
  const beginCount = (seed: number) => { g.current?.setOpponent(null); g.current?.setSeed(seed); setOver(null); setSt('ready'); setDuel(d => d && { ...d, phase: 'count', count: 3, me: null, opp: { d: 0, s: 0, a: true, final: null } }); };
  const wire = (n: DuelNet, role: 'host' | 'guest', code: string) => {
    net.current = n; g.current?.setVehicle('ball'); g.current?.setNoPause(true);
    setDuel({ role, code, linked: false, closed: false, phase: 'lobby', count: 3, me: null, opp: { d: 0, s: 0, a: true, final: null }, muted: false, mic: n.mic });
    n.onOpen = () => setDuel(d => d && { ...d, linked: true });
    n.onClose = () => setDuel(d => d && { ...d, linked: false, closed: true, opp: { ...d.opp, a: false, final: d.opp.final ?? d.opp.s } });
    n.onAudio = st2 => { if (aud.current) { aud.current.srcObject = st2; void aud.current.play().catch(() => undefined); } };
    n.onMsg = m => {
      if (m.t === 'go') beginCount(m.seed);
      else if (m.t === 'pos') { g.current?.setOpponent(m); setDuel(d => d && { ...d, opp: { ...d.opp, d: m.d, s: m.s, a: m.a } }); }
      else setDuel(d => d && { ...d, opp: { d: m.d, s: m.s, a: false, final: m.s } });
    };
  };
  const createRoom = async () => { setBusy(true); setDerr(''); try { const n = new DuelNet(); const code = await n.host(); wire(n, 'host', code); setDuelMenu(false); } catch (e) { setDerr(String((e as Error).message ?? e)); } setBusy(false); };
  const joinRoom = async () => { const c = joinCode.trim().toUpperCase(); if (!/^[A-HJ-NP-Z2-9]{6}$/.test(c)) { setDerr('Enter the 6-character room code'); return; } setBusy(true); setDerr(''); try { const n = new DuelNet(); wire(n, 'guest', c); await n.join(c); setDuelMenu(false); } catch (e) { net.current?.close(); net.current = null; setDuel(null); setDerr(String((e as Error).message ?? e)); } setBusy(false); };
  const startDuel = () => { const seed = Math.floor(Math.random() * 2 ** 30); net.current?.send({ t: 'go', seed }); beginCount(seed); };
  const leaveDuel = () => { net.current?.close(); net.current = null; setDuel(null); setDuelMenu(false); g.current?.setOpponent(null); g.current?.setNoPause(false); g.current?.setSeed(null); g.current?.setVehicle(storeRef.current.vehicle); g.current?.toMenu(); setSt('ready'); setOver(null); history.replaceState(null, '', location.pathname); };
  const invite = duel ? `${location.origin}${location.pathname}#room=${duel.code}` : '';
  const shareInvite = async () => { const text = `Race me in ${BRAND}! Room ${duel?.code}`; try { if (navigator.share) await navigator.share({ text, url: invite }); else { await navigator.clipboard.writeText(`${text} ${invite}`); setShared('Invite copied!'); } } catch { /* cancelled */ } };
  const bothDone = !!duel && duel.me !== null && duel.opp.final !== null;
  const dBest = store.daily.d === dailySeed() ? store.daily.best : 0;
  return <>
    <div id="stage" onPointerDown={down} onPointerMove={move}
      onPointerUp={up} onPointerCancel={stop} onPointerLeave={stop} onLostPointerCapture={stop}><canvas ref={cv} /></div>
    <div className="hud"><span><b>Score {hud.score}</b> · Lv {hud.level} · {hud.dist} m · {hud.orbs} coins · {hud.zone}
      {hud.combo > 1 && <span className="chip rec">Combo ×{Math.min(hud.combo, 4)}</span>}</span>
      <span><span className="rec">Best {store.best}</span> <span className="chip">Keys {store.keys}</span> <button onClick={toggleFpv} aria-label="Toggle camera view">{store.fpv ? 'View: 1st' : 'View: 3rd'}</button> <button onClick={mute} aria-label="Toggle sound">{store.sound ? 'Sound on' : 'Sound off'}</button> {st === 'playing' && !duel && <button onClick={toggle} aria-label="Pause">Pause</button>}</span>
      <span style={{ flexBasis: '100%' }}><span className="chip" style={{ color: '#ffd23f' }}>Carrying ${hud.carried}</span><span className="chip" style={{ color: '#7aa2ff' }}>Banked ${hud.banked}</span>{hud.bombs > 0 && <span className="chip" style={{ color: '#ff6a5a' }}>Bombs {hud.bombs}</span>}{hud.shield > 0 && <span className="chip" style={{ color: '#38e1ff' }}>{'♥'.repeat(hud.shield)} shield</span>}
        {hud.ghost > 0 && <span className="chip" style={{ color: '#b388ff' }}>Ghost {hud.ghost}s</span>}{hud.dbl > 0 && <span className="chip" style={{ color: '#7dff6b' }}>×2 {hud.dbl}s</span>}{hud.calm > 0 && <span className="chip">Calm {hud.calm}s</span>}</span></div>
    {duel && duel.phase === 'play' && <div className="hud" style={{ top: 64 }}><span className="chip" style={{ color: '#ff7ab0' }}>Rival {duel.opp.d} m · {duel.opp.s}{duel.opp.a ? '' : ' (out)'}</span>
      <span><button className="sec" onClick={() => { const m = !duel.muted; net.current?.setMuted(m); setDuel({ ...duel, muted: m }); }} disabled={!duel.mic}>{duel.mic ? (duel.muted ? 'Mic off' : 'Mic on') : 'No mic'}</button></span></div>}
    <audio ref={aud} autoPlay />
    {hud.chase && st === 'playing' && <div className="vig" />}
    {msg && st === 'playing' && <div className="banner" aria-live="polite">{msg}</div>}
    {st === 'playing' && <div className="acts">{([['Jump', 'doJump'], ['Slide', 'doSlide'], ['Punch', 'doPunch'], ['Bomb', 'doBomb']] as const).map(([n, f]) => <button key={n} className="sec" onPointerDown={e => { e.stopPropagation(); g.current?.[f](); }}>{n}</button>)}</div>}
    {err && <div className="ov"><p>Could not start the game: {err}</p></div>}
    {st === 'ready' && !err && !duel && !duelMenu && <div className="ov"><h1>{BRAND}</h1><p>{STORY}</p>
      <p>Cash you carry can be stolen: grab the blue vault to bank it. Jump hurdles and broken bridges, slide under overpasses, punch robbers (cops are off limits!), and throw bombs to clear a traffic jam. Blue = shield, purple = ghost, green = ×2, white = calm, red = bomb.</p>
      <div className="vehs" role="group" aria-label="Vehicle">{VEHICLES.map(v => <button key={v.id} aria-pressed={store.vehicle === v.id} disabled={!unlocked(v, store)} onClick={() => pick(v.id)}>{v.name}{unlocked(v, store) ? ` · ${v.blurb}` : ` · score ${v.unlock} to unlock`}</button>)}</div>
      <div className="vehs"><button className="sec" aria-pressed={!daily} onClick={() => mode(false)}>Free run</button><button className="sec" aria-pressed={daily} onClick={() => mode(true)}>Daily challenge #{dailySeed()}</button></div>
      <p>← → / A D steer · ↑ / W / Space jump · ↓ / S slide · F punch · B bomb · C camera view · Esc pause. Touch: hold left or right half to steer, swipe up = jump, swipe down = slide, double-tap = punch. The buttons work too.</p><div style={{ fontSize: 14 }} aria-label="Daily missions"><b>Today's missions (+2 keys each)</b>{miss.items.map(i => <div key={i.id}>{i.done ? '✓' : '○'} {MISSION_TEXT[i.id]}: {i.progress}/{i.target}</div>)}</div>
      <p className="rec">Best {store.best} · Today's challenge best {dBest} · Plays {store.plays}</p><button className="big" autoFocus onClick={play}>Play</button><button onClick={() => setDuelMenu(true)}>Play 1v1 with a friend</button><Ad /><a href="/privacy.html" style={{ color: '#7aa', fontSize: 13 }}>Privacy &amp; ads</a></div>}
    {st === 'paused' && <div className="ov"><h1>Paused</h1><button className="big" autoFocus onClick={toggle}>Resume</button></div>}
    {st === 'over' && over && !duel && <div className="ov"><h1>Game over</h1>{over.record && <p className="rec">New {over.daily ? 'daily' : 'personal'} best!</p>}{over.unlock && <p className="rec">Unlocked: {over.unlock}!</p>}
      <p>Score {over.score} · Best {over.daily ? dBest : store.best}</p><p className="rec">{over.reason}</p>{missNote && <p className="rec">{missNote}</p>}{over.keysEarned > 0 && <p>+{over.keysEarned} keys earned</p>}<p>Level {over.level} · {over.distance} m · {over.orbs} coins · reached {over.zone}{over.stolen ? ` · robbed of $${over.stolen}` : ''}</p>
      <button className="big" autoFocus onClick={play}>Retry</button><div className="vehs"><button onClick={share}>Share score</button><button className="sec" onClick={() => { g.current?.toMenu(); setSt('ready'); }}>Menu / vehicles</button></div>{over.canRevive && <div className="vehs" role="group" aria-label="Continue options"><button disabled={store.keys < REVIVE_COST} onClick={useKeys}>Continue · {REVIVE_COST} keys (have {store.keys})</button>
        {rewardedAvailable() && <button onClick={watchAd}>Watch ad to continue{realRewardedAvailable() ? '' : ' (demo)'}</button>}{(PAY_LINK || REWARD_DEMO) && <button className="sec" onClick={buyKeys}>{PAY_LINK ? 'Buy keys' : 'Get 5 keys (demo)'}</button>}</div>}
      <p aria-live="polite">{shared}</p><Ad /></div>}
    {duelMenu && !duel && <div className="ov"><h1>1v1 Duel</h1><p>Both players run the same course at the same time. The higher score wins. Voice chat works if you allow the microphone.</p>
      {!NET_OK ? <p className="rec">Online duels need the hosted site (this preview blocks network access).</p> : <>
        <button className="big" disabled={busy} onClick={createRoom}>{busy ? 'Connecting...' : 'Create room'}</button>
        <div className="vehs"><input aria-label="Room code" value={joinCode} maxLength={6} onChange={e => setJoinCode(e.target.value.toUpperCase())} placeholder="ROOM CODE" style={{ font: 'inherit', padding: 10, borderRadius: 8, width: 130, textAlign: 'center' }} /><button disabled={busy} onClick={joinRoom}>Join</button></div></>}
      {derr && <p className="rec" role="alert">{derr}</p>}<button className="sec" onClick={() => { setDuelMenu(false); setDerr(''); }}>Back</button></div>}
    {duel && duel.phase === 'lobby' && <div className="ov"><h1>Room {duel.code}</h1>
      {duel.role === 'host' && <><p>Send this link to your friend:</p><p style={{ wordBreak: 'break-all', fontSize: 13 }}>{invite}</p><button onClick={shareInvite}>Share invite</button></>}
      <p className="rec">{duel.closed ? 'Friend left the room.' : duel.linked ? 'Friend connected!' : duel.role === 'host' ? 'Waiting for your friend...' : 'Connecting...'}</p>
      <p>{duel.mic ? 'Mic ready: you can talk once connected.' : 'No microphone access: you will not be heard.'}</p>
      {duel.role === 'host' && <button className="big" disabled={!duel.linked} onClick={startDuel}>Start duel</button>}{duel.role === 'guest' && duel.linked && <p>Waiting for the host to start...</p>}
      <p aria-live="polite">{shared}</p><button className="sec" onClick={leaveDuel}>Leave</button></div>}
    {duel && duel.phase === 'count' && <div className="ov"><h1 style={{ fontSize: 96 }}>{duel.count > 0 ? duel.count : 'GO!'}</h1><p>Same course for both players. Highest score wins.</p></div>}
    {duel && duel.phase === 'play' && st === 'over' && !bothDone && <div className="ov"><h1>You crashed</h1><p>Your score {duel.me}</p><p className="rec">Rival still running: {duel.opp.d} m · {duel.opp.s}</p><button className="sec" onClick={leaveDuel}>Leave</button></div>}
    {bothDone && duel && (() => { const w = duelWinner(duel.me!, duel.opp.final!); return <div className="ov"><h1>{w === 'me' ? 'You win!' : w === 'opp' ? 'You lose' : 'Draw'}</h1><p>You {duel.me} · Rival {duel.opp.final}</p>{duel.closed && <p>Friend left the room.</p>}
      {duel.role === 'host' && !duel.closed ? <button className="big" onClick={startDuel}>Rematch</button> : !duel.closed && <p>Waiting for the host to start a rematch...</p>}<button className="sec" onClick={leaveDuel}>Leave</button></div>; })()}
    {adLeft !== null && <div className="ov" style={{ zIndex: 5 }}><h1>Ad</h1><p>Demo ad placeholder. A real rewarded ad plays here once ads are enabled.</p><p className="rec">Reward in {adLeft}s</p></div>}
  </>;
}
createRoot(document.getElementById('root')!).render(<StrictMode><App /></StrictMode>);
