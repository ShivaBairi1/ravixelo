import { Capacitor } from '@capacitor/core';
/** True inside the Android (Capacitor) app. AdSense must never run there; AdMob is used instead. */
export const isNative = (): boolean => { try { return Capacitor.isNativePlatform(); } catch { return false; } };
