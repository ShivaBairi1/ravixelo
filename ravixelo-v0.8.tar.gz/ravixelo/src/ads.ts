// One place for all advertising. The game only talks to `ads`; providers are swappable:
//  - Android app  -> AdMob through the custom Capacitor plugin "RavixeloAds" (android/.../AdsPlugin.java), with Google's consent (UMP) form.
//  - Website      -> AdSense (banner + H5 rewarded `adBreak`) from Ad.tsx, only if configured.
//  - Anything else (or unconfigured) -> no ads. Ads must never block or crash the game, so every call swallows errors.
// Ads are only shown on menu / result screens, never during play. Rewarded ads are always optional (player taps a button).
import { registerPlugin } from '@capacitor/core';
import { ADMOB, ADS_TEST, REWARD_DEMO } from './config';
import { isNative } from './platform';
import { realRewardedAvailable, showRewarded as showWebRewarded } from './Ad';
import { interstitialDue, newPace } from './adPolicy';

interface NativeAds {
  initialize(o: { banner: string; interstitial: string; rewarded: string; test: boolean }): Promise<{ canRequestAds: boolean; privacyOptions: boolean }>;
  showBanner(): Promise<void>; hideBanner(): Promise<void>;
  loadInterstitial(): Promise<void>; showInterstitial(): Promise<{ shown: boolean }>;
  loadRewarded(): Promise<void>; showRewarded(): Promise<{ rewarded: boolean }>;
  showPrivacyOptions(): Promise<void>; exitApp(): Promise<void>;
}
const Native = registerPlugin<NativeAds>('RavixeloAds');

export { interstitialDue, newPace, PACE } from './adPolicy';

class Ads {
  private native = isNative(); private started = false; private rewardedOk = false; private interstitialOk = false; private bannerOn = false; private pace = newPace();
  privacyOptions = false;
  /** Native app: ads run only when AdMob unit IDs (or test mode) are configured. */
  get enabled() { return this.native ? !!(ADMOB.banner || ADMOB.interstitial || ADMOB.rewarded) : true; }
  async init(): Promise<void> {
    if (this.started || !this.native || !this.enabled) return; this.started = true;
    try {
      const r = await Native.initialize({ banner: ADMOB.banner, interstitial: ADMOB.interstitial, rewarded: ADMOB.rewarded, test: ADS_TEST });
      this.privacyOptions = r.privacyOptions; if (r.canRequestAds) { void this.preloadRewarded(); void this.preloadInterstitial(); }
    } catch { /* ads unavailable */ }
  }
  private async preloadRewarded() { if (!ADMOB.rewarded) return; try { await Native.loadRewarded(); this.rewardedOk = true; } catch { this.rewardedOk = false; setTimeout(() => void this.preloadRewarded(), 45_000); } }
  private async preloadInterstitial() { if (!ADMOB.interstitial) return; try { await Native.loadInterstitial(); this.interstitialOk = true; } catch { this.interstitialOk = false; setTimeout(() => void this.preloadInterstitial(), 45_000); } }
  rewardedReady(): boolean { return this.native ? this.rewardedOk : realRewardedAvailable() || REWARD_DEMO; }
  /** Resolves true only if the player earned the reward. */
  async showRewarded(): Promise<boolean> {
    try {
      if (!this.native) { if (realRewardedAvailable()) return await showWebRewarded(); if (REWARD_DEMO) return await new Promise<boolean>(r => setTimeout(() => r(true), 3000)); return false; }
      if (!this.rewardedOk) return false; this.rewardedOk = false;
      const r = await Native.showRewarded(); void this.preloadRewarded(); return !!r.rewarded;
    } catch { void this.preloadRewarded(); return false; }
  }
  /** Call once per finished run. Shows an interstitial only when the pacing rules allow it. Resolves when the ad is closed. */
  async afterRun(totalRuns: number): Promise<void> {
    this.pace.runsSince++; if (!this.native || !this.interstitialOk || !interstitialDue(this.pace, Date.now(), totalRuns)) return;
    try { this.interstitialOk = false; const r = await Native.showInterstitial(); if (r.shown) { this.pace = { lastAt: Date.now(), runsSince: 0 }; } } catch { /* ignore */ }
    void this.preloadInterstitial();
  }
  async showBanner() { if (!this.native || !ADMOB.banner || this.bannerOn) return; this.bannerOn = true; try { await Native.showBanner(); } catch { this.bannerOn = false; } }
  async hideBanner() { if (!this.native || !this.bannerOn) return; this.bannerOn = false; try { await Native.hideBanner(); } catch { /* ignore */ } }
  async openPrivacyOptions() { if (this.native) { try { await Native.showPrivacyOptions(); } catch { /* ignore */ } } }
  exitApp() { if (this.native) void Native.exitApp().catch(() => undefined); }
}
export const ads = new Ads();
