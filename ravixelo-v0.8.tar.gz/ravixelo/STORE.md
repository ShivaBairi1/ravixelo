# Google Play launch checklist for Ravixelo: Heist

I cannot publish to Google Play for you: it needs YOUR Play Console account, identity verification, signing key and a human submit. Ready: Android project (`android/`), AdMob integration, icon and feature graphic (`store/`), CI that builds a debug APK and a signed AAB (`.github/workflows/android.yml`). NOT done by me: an APK/AAB was never built or run (no Android SDK or network where this was written). The first CI run is the first real build test.

## Steps
1. Create a Google Play developer account (one-time fee, identity verification). Check Play Console for the current testing rules for new personal accounts (a closed test with a minimum number of testers for a minimum number of days may be required before production).
2. Push the repo to GitHub, host the web version (Vercel) and put a real contact email in `public/privacy.html`. Set the repo variable `PRIVACY_URL` to `https://YOUR-SITE/privacy.html`.
3. Make a signing key (keep it safe, losing it blocks updates): `keytool -genkey -v -keystore ravixelo.jks -alias ravixelo -keyalg RSA -keysize 2048 -validity 10000`. GitHub secrets: SIGNING_KEY_BASE64 (`base64 -w0 ravixelo.jks`), KEY_ALIAS, KEYSTORE_PASSWORD, KEY_PASSWORD. Enrol in Play App Signing.
4. Ads: follow `ADS.md` (AdMob account, app, 3 ad units, secrets). First run the workflow manually (test ads ON) and install the debug APK on a real phone.
5. Tag a release (`git tag v1.0.0 && git push --tags`) -> signed `.aab` artifact.
6. Play Console: create the app, upload the AAB, add `store/icon-512.png`, `store/feature-1024x500.png`, at least 2 landscape phone screenshots (from the running app), descriptions, content rating questionnaire (answer honestly: gun violence), target audience 13+/not for children, Data safety, Ads = Yes, Advertising ID = Yes (ads), privacy policy URL.
7. Confirm the target API level meets the current Play requirement (project targets API 36).

## Listing text (draft)
Title: Ravixelo: Heist
Short: Rob Meridian Trust Bank. Stay silent or go loud, drill the vault, escape.
Full: Plan the perfect robbery in a 3D bank. Sneak past guards or shoot your way through, demand the manager's keycard, drill the vault, grab the cash and reach the getaway van before the police close in. Take down unaware guards silently with the suppressed pistol, spend your earnings on armor, ammo, a faster drill and soft soles, and pick Rookie, Pro or Legend difficulty. Contains cartoon-style gun violence. Contains ads; optional rewarded ads give a continue or a cash bonus.

## Data safety (answer truthfully for the build you ship)
- Stored on device: cash, upgrades, settings. No account.
- Collected/shared via AdMob (Google): device or other IDs (advertising ID), approximate location (IP-based), app interactions/diagnostics as described in Google's AdMob disclosure guide. Purpose: advertising, fraud prevention. Re-check Google's "Provide information for Google Play's Data safety section" page for the exact AdMob list for the SDK version you ship.
- No microphone, location, contacts or storage permissions. The arcade runner/duels are website-only.
- No in-app purchases (selling items would require Google Play Billing + server verification: not built).

## Content / legal checks before release
- The name "Ravixelo" is not trademark-checked. Search app stores and trademark registries first.
- Content rating: shooting at (cartoon-style) guards and police. Do not claim "no violence".
- Bank, brand and level are fictional and original; keep them that way (no real bank logos).
