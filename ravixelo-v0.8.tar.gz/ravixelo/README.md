# Ravixelo (provisional name; not trademark-cleared; edit BRAND in src/config.ts)

Ravixelo: a 3D bank-heist action game (default) plus the original arcade runner (web only, `#runner`). React + TypeScript + Vite + Three.js + Rapier 3D. Static frontend, no backend, no analytics; only localStorage (best score, sound).

## Commands
`npm install` · `npm run dev` · `npm test` · `npm run build` · `npm run preview`

## Controls
A/D or arrows steer; Esc/P pause; Space/Enter start/retry. Touch: hold left/right half of screen.

## Deploy
GitHub: `git init && git add . && git commit -m init`, create a repo, `git remote add origin <url> && git push -u origin main`.
Vercel: import the repo; framework Vite; build `npm run build`; output `dist`.

## Dependencies (versions as installed; verify licenses before release)
| Package | Version | License |
|---|---|---|
| @dimforge/rapier3d-compat | 0.21.0 | Apache-2.0 |
| react | 19.3.1 | MIT |
| react-dom | 19.3.1 | MIT |
| three | 0.186.1 | MIT |
| @types/react | 19.3.0 | MIT |
| @types/react-dom | 19.3.0 | MIT |
| @types/three | 0.186.0 | MIT |
| @vitejs/plugin-react | 6.1.2 | MIT |
| typescript | 7.0.2 | Apache-2.0 |
| vite | 8.3.5 | MIT |
| vitest | 5.0.5 | MIT |

Transitive licenses were NOT audited; run a tool such as `npx license-checker --summary` before release. No third-party art, audio, fonts or models are used (geometry is procedural; sound is WebAudio oscillators). Code was AI-generated: it is not automatically cleared for originality or copyright; review before commercial release.

## Verification status
Executed: tsc (clean), vitest (logic + headless Rapier physics, 19 tests), vite build. In-browser play testing NOT run by the author.
NOT executed: any in-browser test (no browser available): rendering, physics feel, touch/keyboard steering, collisions, performance, mobile, tab switching. Physics values are untuned starting points.

## Known limitations
- Engine (Three/Rapier) code has no automated tests; restart/cleanup of physics bodies is untested at runtime.
- No jump, no particles/impact flashes; sound is minimal (pickup, game over, record).
- Fatal hazard contact uses a distance check against hazard boxes beside the Rapier collider; walls/floor are nonfatal.
- Ball roll is partly driven by setting angular velocity for visual rolling.
- Brand name, accessibility contrast and mobile performance need review.

## Story theme (v0.3)
Rav is a courier on a cash run: coins = pay; oncoming cars/bikes, police roadblocks and patrol officers, robber ambushes (robbers steal half your cash; a second mugging within 6 s ends the run), hurdles and broken bridges (jump), low overpasses (slide), traffic jams (jump or bomb). Punch robbers (F), throw bombs (B) to clear everything 13 m ahead. Five districts cycle: Neon Downtown (0-1.5 km), then every 4.5 km Old Town, Desert Highway, Harbor City, Snow Pass (set in config.ts: firstZone, zoneLen).
Not verified in a browser: chaser/AI feel, bomb radius, oncoming speeds, visuals, mobile performance (~300 draw calls at peak).

## Gameplay (v0.2)
Levels every 400 m: faster speed; L3 slippery track, L5 crosswinds, L7 twitchy steering. Power-ups: shield (extra life, up to 3), ghost (6 s hazard-free), x2 points (10 s), calm (8 s, cancels level penalties). Combo orb chains (up to x4), close-call bonus, level-up bonus. Obstacles: barrier, moving gate, slalom, partial gap. Vehicles: Orb, Bike (unlock at score 400), Car (1200, starts with a shield); they differ in size and handling and use a sphere collider. Daily challenge: same course for everyone per UTC day, separate best. Share button uses the Web Share API or the clipboard.
Limitations: falling off the track is always fatal even with a shield; no online leaderboard; vehicle models are simple procedural shapes.

## Go live (GitHub + Vercel + AdSense)
1. `git init -b main && git add . && git commit -m "Ravixelo v0.2"`; create an empty repo on GitHub; `git remote add origin <url> && git push -u origin main`.
2. Vercel: Add New > Project > import the repo (preset Vite; `vercel.json` is included). Every push to `main` redeploys.
3. AdSense (needs YOUR approved account): add the site in AdSense, wait for approval, create a display ad unit, then in Vercel > Settings > Environment Variables set `VITE_ADSENSE_CLIENT=ca-pub-XXXXXXXXXXXXXXXX` and `VITE_ADSENSE_SLOT=<ad unit id>` and redeploy (this also writes `/ads.txt`). Turn on Google's Privacy & messaging consent message (required for EEA/UK/CH). Add your real contact email to `public/privacy.html`.
Ads appear only on the menu and game-over screens, never during play. Without the variables, no ads load and no ad scripts are requested.

## Touch gestures
Hold left/right half to steer; swipe up = jump; swipe down = slide; double-tap anywhere = punch; on-screen buttons (Jump, Slide, Punch, Bomb) still work. Gesture thresholds: SWIPE_PX in logic.ts (36 px), double-tap window 320 ms / 80 px. A tap briefly steers for the duration of the touch.

## v0.4: character, chaser, camera, continue options
- Character: articulated procedural runner (knees/elbows, run/jump/slide/punch poses). It is NOT a scanned or licensed model; to use a real glTF character, verify its licence first, then swap `rig()` in game.ts.
- Chaser: an inspector always runs behind you (6 m). First crash = stumble (obstacle breaks, brief slowdown, he closes to 2.2 m for 8 s, red screen edge); a second crash in that window = caught. Shields still absorb a hit with no stumble. Falling is fatal. Steering stays analog (not 3 discrete lanes).
- Camera: press C or the View button (3rd/1st person), saved in localStorage.
- Continue (optional, max 2 per run): spend 3 keys (1 key per 10 coins collected, saved locally), or watch a rewarded ad, or buy keys. Retry stays the main button.
- Rewarded ads use Google's H5 Games Ads `adBreak` API, which only works once your AdSense account is approved for it (set VITE_ADSENSE_CLIENT; use VITE_ADBREAK_TEST=1 while testing). Without it the button is hidden. VITE_REWARDED_DEMO=1 shows a 3 s placeholder ad and free demo keys, for previews only. Never enable it in production.
- Buying keys: VITE_PAY_LINK only OPENS your payment link (e.g. a Stripe/Razorpay link). Delivering purchased keys securely needs a server that verifies payments; that is NOT built, so keys are local and not tamper-proof. Do not sell keys until a backend exists.

## v0.5: 3D character and 1v1 duels
- Character: original stylized 3D character built in code from rounded primitives (face, hoodie, cap, backpack, sneakers, soft shadows) with run/jump/slide/punch animation. It is not a scanned or imported model; to import a rigged glTF, check its licence first.
- Duels: Play 1v1 > Create room > send the invite link. Both players run the same seeded course, start together after a 3-2-1 countdown, and the higher score wins (crash = out; the other keeps going). Both see the rival's character live. Host can rematch. Pause and continue/revive are disabled in duels and both use the Runner. Positions are sent 10x per second over WebRTC (PeerJS public broker); data is validated but each client is trusted for its own score, so cheating is possible.
- Voice: browser microphone via WebRTC, mute button in duels. If someone denies the mic they cannot be heard. Behind strict NATs the connection may fail because no TURN server is configured (add one in net.ts for reliability).
- Needs HTTPS (Vercel provides it). Untested with real browsers or networks by the author.
- Extra dependency (verify before release):
| Package | Version | License |
|---|---|---|
| peerjs | 1.5.5 | MIT |
| @msgpack/msgpack | 2.8.0 | ISC |
| eventemitter3 | 4.0.7 | MIT |
| peerjs-js-binarypack | 2.1.0 | MIT |
| webrtc-adapter | 9.0.6 | BSD-3-Clause |
| sdp | 3.2.2 | MIT |

## v0.6: review fixes and Android
See REVIEW.md (rating, problems, uniqueness analysis) and STORE.md (Play Store launch steps). New: bank-it-or-lose-it vaults, daily missions, first-run hints, music, haptics, camera shake, auto low-quality mode. Android: `npm run build && npx cap sync android` then build in Android Studio, or use the GitHub Action. Capacitor packages (@capacitor/core, android, cli 8.5.3) are MIT licensed.

## v0.7: Ravixelo Heist (default mode)
A first/third-person bank-robbery action game. The old arcade runner is still available at `#runner` (e.g. `https://your-site/#runner`).
- World: an ORIGINAL fictional bank ("Meridian Trust"), street, alley, getaway van, built procedurally in `src/heist/level.ts` and `world.ts`. It is not based on any real building or real map data.
- Player: WASD, mouse look (pointer lock), shoot (LMB), aim down sights (RMB), sprint, jump, crouch (C), prone (Z), reload, swap rifle/suppressed pistol, first/third person (V), open doors, hold E to drill the vault, demand the manager's keycard, grab cash bags. Touch: stick, look-drag and buttons.
- Enemies: guards patrol and notice you by sight/noise (stance and weapon noise matter), raise the alarm, police spawn in waves and path through the bank (A* on a grid). Civilians cower. Silent play earns a bonus.
- Graphics: PBR materials with procedural textures, physical sky + environment reflections, sun shadows, bloom, ACES tone mapping, soft shadows, bullet holes, tracers, muzzle flash. High/Low graphics setting (Auto picks Low on weaker devices).
- Honest limits: this is a browser game with procedural, original assets. It does NOT look like BGMI/PUBG/GTA (those use studio-made models and huge budgets). To get closer, license/commission real 3D models, animations and textures (check licences) and replace `chars.ts`/`world.ts` primitives with glTF assets.
- Tests (all headless, no GPU): rules, level reachability (A*), character controller and ray physics vs the real level, and a full-game simulation with a stubbed renderer (keycard, staff door, drill, loot, escape, alarm, police, game over). NOT tested: real rendering, GPU performance, mouse/touch feel, audio, pointer lock, balance.
- Needs no network. Voice/duels exist only in the arcade runner.

## v0.8: review fixes, progression, ads, Android
See `REVIEW.md` (what was wrong and how it was fixed), `ADS.md` (AdMob/AdSense/mediation setup) and `STORE.md` (Play launch).
- New: cash wallet + gear shop (armor, ammo, drill, soft soles), Rookie/Pro/Legend difficulty, silent takedowns with the suppressed pistol, hit markers, vibration, one-time rewarded continue, rewarded payout bonus, paced interstitials, banner on menus, Google consent (UMP).
- Android: landscape, immersive fullscreen, back button = pause/menu/exit, no microphone permission, AdMob plugin (`android/.../AdsPlugin.java`), versionCode from CI.
- Commands: `npm install`, `npm test`, `npm run build`, `npm run android:sync` then build in Android Studio or push a tag / run the "Android build" workflow.
- NOT verified by the author of this change: no `npm install`, vitest, vite build, Gradle build or on-device run was possible (no network). Pure logic tests (rules, save data, ad pacing, navigation) were run with a small shim; the engine/UI/Java code was only typechecked loosely and the Java plugin was compiled against hand-written stubs. Treat the first CI run and a phone test as the real verification.
