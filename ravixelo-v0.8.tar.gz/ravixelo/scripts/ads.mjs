// Writes the ad-verification files that ad networks ask for. Both are optional and only written when the env vars are set.
//  ads.txt      (websites, AdSense):  VITE_ADSENSE_CLIENT=ca-pub-1234567890123456
//  app-ads.txt  (Android app, AdMob): ADMOB_PUBLISHER_ID=pub-1234567890123456   (the part of your AdMob app ID before the "~", without "ca-app-")
// Host app-ads.txt at the ROOT of the developer website you list on your Google Play page.
import { writeFileSync, mkdirSync } from 'node:fs';
const line = id => `google.com, pub-${id}, DIRECT, f08c47fec0942fa0\n`;
const m = /^ca-pub-(\d+)$/.exec(process.env.VITE_ADSENSE_CLIENT ?? '');
const a = /^(?:ca-app-)?pub-(\d+)$/.exec(process.env.ADMOB_PUBLISHER_ID ?? '');
mkdirSync('public', { recursive: true });
if (m) { writeFileSync('public/ads.txt', line(m[1])); console.log('ads.txt written'); } else console.log('AdSense not configured: no web ads, no ads.txt');
if (a) { writeFileSync('public/app-ads.txt', line(a[1])); console.log('app-ads.txt written'); } else console.log('AdMob publisher id not set: no app-ads.txt');
