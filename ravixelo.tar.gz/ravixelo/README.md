# Ravixelo (provisional name; not trademark-cleared; edit BRAND in src/config.ts)

Single-player physics survival arcade game: React + TypeScript + Vite + Three.js + Rapier 3D. Static frontend, no backend, no analytics; only localStorage (best score, sound).

## Commands
`npm install` · `npm run dev` · `npm test` · `npm run build` · `npm run preview`

## Controls
A/D or arrows steer; Esc/P pause; Space/Enter start/retry. Touch: hold left/right half of screen.

## Deploy
GitHub: `git init && git add . && git commit -m init`, create a repo, `git remote add origin <url> && git push -u origin main`.
Vercel: import the repo; framework Vite; build `npm run build`; output `dist`.

## Dependencies (versions as installed; verify licenses before release)
| Package | Version | License |
|---|---|---|
| @dimforge/rapier3d-compat | 0.21.0 | Apache-2.0 |
| react | 19.3.1 | MIT |
| react-dom | 19.3.1 | MIT |
| three | 0.186.1 | MIT |
| @types/react | 19.3.0 | MIT |
| @types/react-dom | 19.3.0 | MIT |
| @types/three | 0.186.0 | MIT |
| @vitejs/plugin-react | 6.1.2 | MIT |
| typescript | 7.0.2 | Apache-2.0 |
| vite | 8.3.5 | MIT |
| vitest | 5.0.5 | MIT |

Transitive licenses were NOT audited; run a tool such as `npx license-checker --summary` before release. No third-party art, audio, fonts or models are used (geometry is procedural; sound is WebAudio oscillators). Code was AI-generated: it is not automatically cleared for originality or copyright; review before commercial release.

## Verification status
Executed: tsc (clean), vitest (logic + headless Rapier physics, 19 tests), vite build. In-browser play testing NOT run by the author.
NOT executed: any in-browser test (no browser available): rendering, physics feel, touch/keyboard steering, collisions, performance, mobile, tab switching. Physics values are untuned starting points.

## Known limitations
- Engine (Three/Rapier) code has no automated tests; restart/cleanup of physics bodies is untested at runtime.
- No jump, no particles/impact flashes; sound is minimal (pickup, game over, record).
- Fatal hazard contact uses a distance check against hazard boxes beside the Rapier collider; walls/floor are nonfatal.
- Ball roll is partly driven by setting angular velocity for visual rolling.
- Brand name, accessibility contrast and mobile performance need review.

## Story theme (v0.3)
Rav is a courier on a cash run: coins = pay; oncoming cars/bikes, police roadblocks and patrol officers, robber ambushes (robbers steal half your cash; a second mugging within 6 s ends the run), hurdles and broken bridges (jump), low overpasses (slide), traffic jams (jump or bomb). Punch robbers (F), throw bombs (B) to clear everything 13 m ahead. Five districts cycle: Neon Downtown (0-1.5 km), then every 4.5 km Old Town, Desert Highway, Harbor City, Snow Pass (set in config.ts: firstZone, zoneLen).
Not verified in a browser: chaser/AI feel, bomb radius, oncoming speeds, visuals, mobile performance (~300 draw calls at peak).

## Gameplay (v0.2)
Levels every 400 m: faster speed; L3 slippery track, L5 crosswinds, L7 twitchy steering. Power-ups: shield (extra life, up to 3), ghost (6 s hazard-free), x2 points (10 s), calm (8 s, cancels level penalties). Combo orb chains (up to x4), close-call bonus, level-up bonus. Obstacles: barrier, moving gate, slalom, partial gap. Vehicles: Orb, Bike (unlock at score 400), Car (1200, starts with a shield); they differ in size and handling and use a sphere collider. Daily challenge: same course for everyone per UTC day, separate best. Share button uses the Web Share API or the clipboard.
Limitations: falling off the track is always fatal even with a shield; no online leaderboard; vehicle models are simple procedural shapes.

## Go live (GitHub + Vercel + AdSense)
1. `git init -b main && git add . && git commit -m "Ravixelo v0.2"`; create an empty repo on GitHub; `git remote add origin <url> && git push -u origin main`.
2. Vercel: Add New > Project > import the repo (preset Vite; `vercel.json` is included). Every push to `main` redeploys.
3. AdSense (needs YOUR approved account): add the site in AdSense, wait for approval, create a display ad unit, then in Vercel > Settings > Environment Variables set `VITE_ADSENSE_CLIENT=ca-pub-XXXXXXXXXXXXXXXX` and `VITE_ADSENSE_SLOT=<ad unit id>` and redeploy (this also writes `/ads.txt`). Turn on Google's Privacy & messaging consent message (required for EEA/UK/CH). Add your real contact email to `public/privacy.html`.
Ads appear only on the menu and game-over screens, never during play. Without the variables, no ads load and no ad scripts are requested.
