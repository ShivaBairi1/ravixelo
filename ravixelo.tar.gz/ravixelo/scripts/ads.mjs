import { writeFileSync, mkdirSync } from 'node:fs';
const m = /^ca-pub-(\d+)$/.exec(process.env.VITE_ADSENSE_CLIENT ?? '');
if (m) { mkdirSync('public', { recursive: true }); writeFileSync('public/ads.txt', `google.com, pub-${m[1]}, DIRECT, f08c47fec0942fa0\n`); console.log('ads.txt written'); }
else console.log('AdSense not configured: no ads, no ads.txt');
