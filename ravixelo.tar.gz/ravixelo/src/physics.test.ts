import { describe, it, expect, beforeAll } from 'vitest';
import RAPIER from '@dimforge/rapier3d-compat';
import { C } from './config';
import { steerVx } from './logic';
beforeAll(async () => { await RAPIER.init(); });
function mk() {
  const w = new RAPIER.World({ x: 0, y: -C.gravity, z: 0 }); w.timestep = C.fixedDt;
  const f = w.createRigidBody(RAPIER.RigidBodyDesc.fixed().setTranslation(0, -.5, -100)); w.createCollider(RAPIER.ColliderDesc.cuboid(5, .5, 100), f);
  const b = w.createRigidBody(RAPIER.RigidBodyDesc.dynamic().setTranslation(0, .6, 0).setCcdEnabled(true)); w.createCollider(RAPIER.ColliderDesc.ball(C.ballR).setRestitution(.4), b);
  return { w, b };
}
describe('physics', () => {
  it('ball settles on the floor', () => { const { w, b } = mk(); for (let i = 0; i < 240; i++) w.step(); expect(b.translation().y).toBeGreaterThan(.3); expect(b.translation().y).toBeLessThan(1); });
  it('contact with a barrier is detected before the ball passes it (max speed)', () => {
    const { w, b } = mk(); const bar = w.createRigidBody(RAPIER.RigidBodyDesc.fixed().setTranslation(0, .75, -30)); w.createCollider(RAPIER.ColliderDesc.cuboid(5, .75, .4), bar);
    let hit = false;
    for (let i = 0; i < 600 && !hit; i++) { b.setLinvel({ x: 0, y: b.linvel().y, z: -C.speedMax }, true); w.step(); const z = b.translation().z; if (Math.abs(z + 30) - .4 < C.ballR + .06) hit = true; expect(z).toBeGreaterThan(-30.4); }
    expect(hit).toBe(true);
  });
});
describe('chasm jump fairness', () => {
  it.each([[10, 1], [10, 4], [17, 1], [17, 4], [14, 3]])('speed %d, takeoff %d units before the edge lands on the far side', (sp, before) => {
    const w = new RAPIER.World({ x: 0, y: -C.gravity, z: 0 }); w.timestep = C.fixedDt;
    for (const [zc, hl] of [[-10, 10], [-52.5, 27.5]] as const) { const f = w.createRigidBody(RAPIER.RigidBodyDesc.fixed().setTranslation(0, -.5, zc)); w.createCollider(RAPIER.ColliderDesc.cuboid(5, .5, hl), f); }
    const b = w.createRigidBody(RAPIER.RigidBodyDesc.dynamic().setTranslation(0, .6, -2).setCcdEnabled(true)); w.createCollider(RAPIER.ColliderDesc.ball(C.ballR).setRestitution(.3).setFriction(1), b);
    let jumped = false;
    for (let i = 0; i < 450; i++) { const z = b.translation().z, grounded = b.translation().y < .62 && Math.abs(b.linvel().y) < .5; let vy = b.linvel().y; if (!jumped && grounded && z < -20 + before) { vy = 5.5; jumped = true; } b.setLinvel({ x: 0, y: vy, z: -sp }, true); w.step(); }
    expect(jumped).toBe(true); expect(b.translation().y).toBeGreaterThan(-1); expect(b.translation().z).toBeLessThan(-27);
  });
});
describe('steering', () => {
  it('decays gradually when released', () => { let v = 8; v = steerVx(v, 0, .1); expect(v).toBeGreaterThan(0); expect(v).toBeLessThan(8); });
  it('reversing reduces drift before reversing', () => { let v = 6; const seq: number[] = []; for (let i = 0; i < 60; i++) { v = steerVx(v, -1, 1 / 60); seq.push(v); } expect(6 - seq[0]).toBeGreaterThan(C.latAcc / 60); expect(seq[60 - 1]).toBeLessThan(0); });
  it('accelerates and clamps', () => { let v = 0; for (let i = 0; i < 600; i++) v = steerVx(v, 1, 1 / 60); expect(v).toBe(C.maxLat); });
});
