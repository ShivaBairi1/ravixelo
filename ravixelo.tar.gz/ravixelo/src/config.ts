export const BRAND = 'Ravixelo'; // provisional, NOT trademark-cleared
export const C = {
  trackW: 10, firstZone: 1500, zoneLen: 4500, levelLen: 400, segLen: 24, ahead: 4, behind: 2, ballR: 0.5, startD: 4,
  speed0: 10, speedMax: 17, latAcc: 36, latDamp: 2.4, reverseBoost: 2.2, maxLat: 9,
  gravity: 9.81, fallY: -8, orbPts: 25, fixedDt: 1 / 120, maxSteps: 12, minFree: 3.2,
};
export type VehicleId = 'ball' | 'bike' | 'car';
export interface Vehicle { id: VehicleId; name: string; r: number; acc: number; maxLat: number; damp: number; unlock: number; shield: number; blurb: string }
export const VEHICLES: Vehicle[] = [
  { id: 'ball', name: 'Runner', r: .5, acc: 36, maxLat: 9, damp: 2.4, unlock: 0, shield: 0, blurb: 'On foot, balanced' },
  { id: 'bike', name: 'Bike', r: .38, acc: 46, maxLat: 10, damp: 2.8, unlock: 400, shield: 0, blurb: 'Slim and agile' },
  { id: 'car', name: 'Car', r: .6, acc: 30, maxLat: 8, damp: 1.8, unlock: 1200, shield: 1, blurb: 'Wide, starts with a shield' },
];
// AdSense is OFF unless these are set at build time (see README). Never shown during gameplay.
export const ADSENSE_CLIENT: string = (import.meta.env.VITE_ADSENSE_CLIENT as string | undefined) ?? '';
export const ADSENSE_SLOT: string = (import.meta.env.VITE_ADSENSE_SLOT as string | undefined) ?? '';
export interface Zone { name: string; sky: number; ground: number; props: number[]; glow: number; kind: 'towers' | 'old' | 'desert' | 'harbor' | 'snow' }
export const ZONES: Zone[] = [
  { name: 'Neon Downtown', sky: 0x0a0f24, ground: 0x070a16, props: [0x1b2a55, 0x2a1b55, 0x0f3d5c], glow: 0x38e1ff, kind: 'towers' },
  { name: 'Old Town', sky: 0x2a1d3a, ground: 0x1d1522, props: [0x8a5a3a, 0xb07a4a, 0x6e4a38], glow: 0xffb347, kind: 'old' },
  { name: 'Desert Highway', sky: 0xe39a58, ground: 0xb86f3a, props: [0xc2703a, 0xa65d2e, 0x7d9a4a], glow: 0xffe066, kind: 'desert' },
  { name: 'Harbor City', sky: 0x1f4f7a, ground: 0x0d3a66, props: [0xd24b3a, 0x2f7fc4, 0xe8b73a], glow: 0xffffff, kind: 'harbor' },
  { name: 'Snow Pass', sky: 0x9fb8d6, ground: 0xdfe9f5, props: [0x1f5f3a, 0x2f7a4a, 0xeef6ff], glow: 0xffffff, kind: 'snow' },
];
export const STORY = 'You are Rav, a courier carrying a bag for a living. Grab coins to get paid, dodge traffic, outrun robbers and the police, and keep moving through new districts.';
