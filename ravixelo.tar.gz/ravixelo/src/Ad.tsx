import { useEffect } from 'react';
import { ADSENSE_CLIENT, ADSENSE_SLOT } from './config';
let loaded = false;
type W = { adsbygoogle?: unknown[] };
/** Shown only on menu / game-over screens, never during play. Renders nothing unless configured. */
export function Ad() {
  const on = /^ca-pub-\d+$/.test(ADSENSE_CLIENT) && !!ADSENSE_SLOT;
  useEffect(() => {
    if (!on) return;
    if (!loaded) { loaded = true; const s = document.createElement('script'); s.async = true; s.crossOrigin = 'anonymous'; s.src = `https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=${ADSENSE_CLIENT}`; document.head.appendChild(s); }
    try { const w = window as unknown as W; (w.adsbygoogle = w.adsbygoogle || []).push({}); } catch { /* ad blocked */ }
  }, [on]);
  if (!on) return null;
  return <ins className="adsbygoogle" style={{ display: 'block', width: '100%', maxWidth: 320, minHeight: 50, marginTop: 8 }} data-ad-client={ADSENSE_CLIENT} data-ad-slot={ADSENSE_SLOT} data-ad-format="horizontal" />;
}
