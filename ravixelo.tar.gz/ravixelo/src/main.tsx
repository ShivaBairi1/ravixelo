import { StrictMode, useEffect, useRef, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { BRAND, STORY, VEHICLES } from './config';
import { Game, Hud, Result } from './game';
import { Ad } from './Ad';
import { GameState, loadStore, saveStore, submitScore, Store, unlocked, dailySeed } from './logic';

const ZERO: Hud = { score: 0, dist: 0, orbs: 0, level: 1, shield: 0, ghost: 0, dbl: 0, calm: 0, combo: 0, bombs: 0, zone: 'Neon Downtown' };
type Over = Result & { record: boolean; unlock: string };
function App() {
  const cv = useRef<HTMLCanvasElement>(null); const g = useRef<Game | null>(null); const tm = useRef(0);
  const [st, setSt] = useState<GameState>('ready'); const [hud, setHud] = useState(ZERO);
  const [store, setStore] = useState<Store>(() => loadStore(localStorage)); const storeRef = useRef(store); storeRef.current = store;
  const [over, setOver] = useState<Over | null>(null); const [err, setErr] = useState(''); const [msg, setMsg] = useState(''); const [daily, setDaily] = useState(false); const [shared, setShared] = useState('');
  const put = (n: Store) => { setStore(n); storeRef.current = n; saveStore(localStorage, n); };
  useEffect(() => {
    let dead = false, game: Game | null = null; const keys = new Set<string>();
    const sync = () => g.current?.setDir((keys.has('r') ? 1 : 0) - (keys.has('l') ? 1 : 0));
    const kd = (e: KeyboardEvent, down: boolean) => {
      const k = e.key.toLowerCase(), m = k === 'arrowleft' || k === 'a' ? 'l' : k === 'arrowright' || k === 'd' ? 'r' : '';
      if (m) { down ? keys.add(m) : keys.delete(m); sync(); e.preventDefault(); }
      if (down && (k === 'arrowup' || k === 'w' || (k === ' ' && g.current?.state === 'playing'))) { g.current?.doJump(); e.preventDefault(); }
      if (down && (k === 'arrowdown' || k === 's')) { g.current?.doSlide(); e.preventDefault(); }
      if (down && (k === 'f' || k === 'j')) g.current?.doPunch();
      if (down && (k === 'b' || k === 'e')) g.current?.doBomb();
      if (down && !e.repeat) {
        if (k === 'escape' || k === 'p') toggle();
        else if ((k === ' ' || k === 'enter') && g.current && ['ready', 'over'].includes(g.current.state)) { e.preventDefault(); play(); }
      }
    };
    const down = (e: KeyboardEvent) => kd(e, true), up = (e: KeyboardEvent) => kd(e, false), blur = () => { keys.clear(); sync(); };
    Game.create(cv.current!, {
      onHud: setHud, onPause: () => setSt('paused'),
      onMsg: t => { setMsg(t); clearTimeout(tm.current); tm.current = window.setTimeout(() => setMsg(''), 2200); },
      onOver: r => {
        const old = storeRef.current, { store: ns, record } = submitScore(old, r.score, r.daily ? r.seed : undefined); if (record) { put(ns); g.current?.sfx(1200, .3); }
        const nu = VEHICLES.filter(v => !unlocked(v, old) && unlocked(v, ns)).map(v => v.name).join(', ');
        setOver({ ...r, record, unlock: nu }); setSt('over'); setMsg('');
      },
    }).then(x => { if (dead) x.dispose(); else { game = x; g.current = x; x.setMuted(!storeRef.current.sound); x.setVehicle(storeRef.current.vehicle); } }).catch(e => setErr(String(e)));
    addEventListener('keydown', down); addEventListener('keyup', up); addEventListener('blur', blur);
    return () => { dead = true; removeEventListener('keydown', down); removeEventListener('keyup', up); removeEventListener('blur', blur); game?.dispose(); g.current = null; };
  }, []);
  const play = () => { put({ ...storeRef.current, plays: storeRef.current.plays + 1 }); g.current?.start(); setOver(null); setHud(ZERO); setSt('playing'); setShared(''); };
  const toggle = () => { const x = g.current; if (!x) return; if (x.state === 'playing') { x.pause(); setSt('paused'); } else if (x.state === 'paused') { x.resume(); setSt('playing'); } };
  const side = (e: React.PointerEvent) => { if (st === 'playing') g.current?.setDir(e.clientX < innerWidth / 2 ? -1 : 1); };
  const stop = () => g.current?.setDir(0);
  const mute = () => { const n = { ...store, sound: !store.sound }; put(n); g.current?.setMuted(!n.sound); };
  const pick = (id: typeof VEHICLES[number]['id']) => { put({ ...store, vehicle: id }); g.current?.setVehicle(id); };
  const mode = (d: boolean) => { setDaily(d); g.current?.setMode(d); };
  const share = async () => {
    if (!over) return; const v = VEHICLES.find(x => x.id === store.vehicle)!.name;
    const text = `I scored ${over.score} (${over.distance} m, reached ${over.zone}; ${over.reason}) in ${BRAND} as the ${v}${over.daily ? ` on today's Daily Challenge #${over.seed}` : ''}. Can you beat me?`;
    try { if (navigator.share) { await navigator.share({ text, url: location.href }); setShared('Shared!'); } else { await navigator.clipboard.writeText(`${text} ${location.href}`); setShared('Copied to clipboard!'); } } catch { setShared('Share cancelled'); }
  };
  const dBest = store.daily.d === dailySeed() ? store.daily.best : 0;
  return <>
    <div id="stage" onPointerDown={e => { (e.target as Element).setPointerCapture?.(e.pointerId); side(e); }} onPointerMove={e => e.buttons && side(e)}
      onPointerUp={stop} onPointerCancel={stop} onPointerLeave={stop} onLostPointerCapture={stop}><canvas ref={cv} /></div>
    <div className="hud"><span><b>Score {hud.score}</b> · Lv {hud.level} · {hud.dist} m · {hud.orbs} coins · {hud.zone}
      {hud.combo > 1 && <span className="chip rec">Combo ×{Math.min(hud.combo, 4)}</span>}</span>
      <span><span className="rec">Best {store.best}</span> <button onClick={mute} aria-label="Toggle sound">{store.sound ? 'Sound on' : 'Sound off'}</button> {st === 'playing' && <button onClick={toggle} aria-label="Pause">Pause</button>}</span>
      <span style={{ flexBasis: '100%' }}>{hud.bombs > 0 && <span className="chip" style={{ color: '#ff6a5a' }}>Bombs {hud.bombs}</span>}{hud.shield > 0 && <span className="chip" style={{ color: '#38e1ff' }}>{'♥'.repeat(hud.shield)} shield</span>}
        {hud.ghost > 0 && <span className="chip" style={{ color: '#b388ff' }}>Ghost {hud.ghost}s</span>}{hud.dbl > 0 && <span className="chip" style={{ color: '#7dff6b' }}>×2 {hud.dbl}s</span>}{hud.calm > 0 && <span className="chip">Calm {hud.calm}s</span>}</span></div>
    {msg && st === 'playing' && <div className="banner" aria-live="polite">{msg}</div>}
    {st === 'playing' && <div className="acts">{([['Jump', 'doJump'], ['Slide', 'doSlide'], ['Punch', 'doPunch'], ['Bomb', 'doBomb']] as const).map(([n, f]) => <button key={n} className="sec" onPointerDown={e => { e.stopPropagation(); g.current?.[f](); }}>{n}</button>)}</div>}
    {err && <div className="ov"><p>Could not start the game: {err}</p></div>}
    {st === 'ready' && !err && <div className="ov"><h1>{BRAND}</h1><p>{STORY}</p>
      <p>Jump hurdles and broken bridges, slide under overpasses, punch robbers (cops are off limits!), and throw bombs to clear a traffic jam. Blue = shield, purple = ghost, green = ×2, white = calm, red = bomb.</p>
      <div className="vehs" role="group" aria-label="Vehicle">{VEHICLES.map(v => <button key={v.id} aria-pressed={store.vehicle === v.id} disabled={!unlocked(v, store)} onClick={() => pick(v.id)}>{v.name}{unlocked(v, store) ? ` · ${v.blurb}` : ` · score ${v.unlock} to unlock`}</button>)}</div>
      <div className="vehs"><button className="sec" aria-pressed={!daily} onClick={() => mode(false)}>Free run</button><button className="sec" aria-pressed={daily} onClick={() => mode(true)}>Daily challenge #{dailySeed()}</button></div>
      <p>← → / A D steer · ↑ / W / Space jump · ↓ / S slide · F punch · B bomb · Esc pause. Touch: hold left or right half, tap the buttons.</p><p className="rec">Best {store.best} · Today's challenge best {dBest} · Plays {store.plays}</p><button className="big" autoFocus onClick={play}>Play</button><Ad /><a href="/privacy.html" style={{ color: '#7aa', fontSize: 13 }}>Privacy &amp; ads</a></div>}
    {st === 'paused' && <div className="ov"><h1>Paused</h1><button className="big" autoFocus onClick={toggle}>Resume</button></div>}
    {st === 'over' && over && <div className="ov"><h1>Game over</h1>{over.record && <p className="rec">New {over.daily ? 'daily' : 'personal'} best!</p>}{over.unlock && <p className="rec">Unlocked: {over.unlock}!</p>}
      <p>Score {over.score} · Best {over.daily ? dBest : store.best}</p><p className="rec">{over.reason}</p><p>Level {over.level} · {over.distance} m · {over.orbs} coins · reached {over.zone}{over.stolen ? ` · robbed of $${over.stolen}` : ''}</p>
      <button className="big" autoFocus onClick={play}>Retry</button><div className="vehs"><button onClick={share}>Share score</button><button className="sec" onClick={() => { g.current?.toMenu(); setSt('ready'); }}>Menu / vehicles</button></div><p aria-live="polite">{shared}</p><Ad /></div>}
  </>;
}
createRoot(document.getElementById('root')!).render(<StrictMode><App /></StrictMode>);
